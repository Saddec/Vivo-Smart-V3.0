const appState = {
  files: [],
  countries: [],
  cities: [],
  playlist: [],
  sessionToken: localStorage.getItem('vivoSessionToken') || '',
  activeTab: 'dashboard',
  prayerUiLoaded: false,
  csvStatusLoaded: false,
  lastUserInteraction: Date.now()
};

const $ = (id) => document.getElementById(id);

let currentDir = '/';
let calendarEditorYear = 0;
let calendarEditorMonth = 0;

function toast(message) {
  let container = $('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.style.cssText = 'position:fixed;bottom:20px;left:50%;transform:translateX(-50%);z-index:9999;display:flex;flex-direction:column;gap:10px;pointer-events:none;';
    document.body.appendChild(container);
    
    // Keyframes are in style.css
  }
  const el = document.createElement('div');
  el.style.cssText = 'background:#2c3e50;color:#fff;padding:12px 24px;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,0.3);font-size:15px;animation:fadein 0.3s, fadeout 0.3s 4.7s forwards; border-left: 4px solid #3498db; text-align:center; direction:rtl;';
  el.innerHTML = message;
  container.appendChild(el);
  setTimeout(() => { if (el.parentNode) el.parentNode.removeChild(el); }, 5000);
}

function formBody(data) {
  const body = new URLSearchParams();
  Object.keys(data).forEach((key) => {
    if (data[key] !== undefined && data[key] !== null) body.append(key, data[key]);
  });
  return body;
}

function safeText(value) {
  return String(value ?? '').replace(/[&<>"']/g, (ch) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[ch]));
}

function safeAttr(value) {
  return safeText(value).replace(/`/g, '&#96;');
}

function apiGet(url, fallback = {}, retries = 3) {
  const headers = {};
  if (appState.sessionToken) {
    headers['X-Session-Token'] = appState.sessionToken;
  }
  return fetch(url, { headers })
    .then((response) => {
      if (!response.ok) throw new Error(`${response.status} ${url}`);
      return response.json();
    })
    .catch((err) => {
      console.warn('GET failed:', url, err);
      if (retries > 0) {
        return new Promise((r) => setTimeout(r, 2000)).then(() => apiGet(url, fallback, retries - 1));
      }
      return fallback;
    });
}

function apiPost(url, data = {}) {
  let body;
  if (data instanceof URLSearchParams) {
    body = new URLSearchParams(data);
    if (appState.sessionToken && !body.has('token')) body.append('token', appState.sessionToken);
  } else {
    const payload = { ...data };
    if (appState.sessionToken && !payload.token) payload.token = appState.sessionToken;
    body = formBody(payload);
  }
  const headers = { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' };
  if (appState.sessionToken) {
    headers['X-Session-Token'] = appState.sessionToken;
  }
  return fetch(url, {
    method: 'POST',
    headers: headers,
    body: body
  }).then((response) => {
    if (response.status === 401) {
      doLogout();
      throw new Error(`unauthorized ${url}`);
    }
    if (!response.ok) throw new Error(`${response.status} ${url}`);
    return response.json().catch(() => ({}));
  });
}

function showTab(tabName) {
  const previousTab = appState.activeTab;
  appState.activeTab = tabName;
  document.querySelectorAll('.tab').forEach((tab) => tab.classList.remove('active'));
  document.querySelectorAll('.sidebar a').forEach((link) => link.classList.remove('active'));

  const tab = $(`tab-${tabName}`);
  if (tab) tab.classList.add('active');

  const nav = document.querySelector(`.sidebar a[href="#${tabName}"]`);
  if (nav) nav.classList.add('active');

  // Close sidebar on mobile after selecting a tab
  if (document.body.classList.contains('is-mobile')) {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    const menuBtnIcon = document.querySelector('#menuToggleBtn i');
    if (sidebar && sidebar.classList.contains('open')) {
      sidebar.classList.remove('open');
      if (overlay) overlay.style.display = 'none';
      if (menuBtnIcon) {
        menuBtnIcon.classList.remove('fa-times');
        menuBtnIcon.classList.add('fa-bars');
      }
    }
  }

  if (tabName === 'files') { loadFileList(); }
  if (tabName === 'scheduler') { loadSchedules(); }
  if (tabName === 'gpio') { loadGpioMappings(); loadGpioSchedules(); }
  if (tabName === 'maghrib') { loadMaghribAlerts(); }
  if (tabName === 'network') { loadWifiStatus(); }
  if (tabName === 'prayer') { loadPrayerTab(previousTab !== 'prayer'); }
  if (tabName === 'settings') { loadStartupSettings(); loadSessionTimeout(); loadManualTimeStatus(); }
  if (tabName === 'eid') { loadEidSchedules(); loadEidTakbeerConfig(); }
  if (tabName === 'presence') { loadPresenceConfig(); refreshPresenceStatus(); }
  if (tabName === 'logs') { fetchLogs(); }

  // Auto-activate first sub-tab when showing a main tab
  const activeTabEl = $(`tab-${tabName}`);
  if (activeTabEl) {
    const firstSubTabBtn = activeTabEl.querySelector('.sub-tabs-nav .sub-tab-btn');
    if (firstSubTabBtn) {
      firstSubTabBtn.click();
    }
  }
}

function showSubTab(parentTabId, subTabId, btn) {
  const parent = document.getElementById(parentTabId);
  if (!parent) return;

  // Hide all sub-tab contents
  parent.querySelectorAll('.sub-tab-content').forEach(el => {
    el.style.display = 'none';
  });

  // Show active sub-tab content
  const activeSub = document.getElementById(subTabId);
  if (activeSub) {
    activeSub.style.display = 'block';
  }

  // Manage active classes on buttons
  parent.querySelectorAll('.sub-tab-btn').forEach(b => {
    b.classList.remove('active');
  });

  let activeBtn = btn;
  if (!activeBtn) {
    activeBtn = parent.querySelector(`.sub-tab-btn[onclick*="${subTabId}"]`);
  }
  if (activeBtn) {
    activeBtn.classList.add('active');
  }
  if (subTabId === 'sub-prayer-csv') {
    loadCsvStatus();
  }
}

function toggleSidebar() {
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('sidebarOverlay');
  const menuBtnIcon = document.querySelector('#menuToggleBtn i');
  if (!sidebar) return;
  
  if (sidebar.classList.contains('open')) {
    sidebar.classList.remove('open');
    if (overlay) overlay.style.display = 'none';
    if (menuBtnIcon) {
      menuBtnIcon.classList.remove('fa-times');
      menuBtnIcon.classList.add('fa-bars');
    }
  } else {
    sidebar.classList.add('open');
    if (overlay) overlay.style.display = 'block';
    if (menuBtnIcon) {
      menuBtnIcon.classList.remove('fa-bars');
      menuBtnIcon.classList.add('fa-times');
    }
  }
}

function doLogin() {
  const password = $('loginPassword')?.value || '';
  apiPost('/api/password/check', { password })
    .then((data) => {
      if (data.ok) {
        document.body.classList.add('logged-in');
        const overlay = $('loginOverlay');
        if (overlay) overlay.style.display = 'none';
        const main = $('mainContent');
        if (main) main.style.display = 'block';
        const err = $('loginError');
        if (err) err.style.display = 'none';
        if (data.token) {
          appState.sessionToken = data.token;
          localStorage.setItem('vivoSessionToken', data.token);
        }
        localStorage.setItem('vivoSessionTime', Date.now().toString());
        appState.lastUserInteraction = Date.now();
        initDashboard();
      } else {
        const err = $('loginError');
        if (err) err.style.display = 'block';
      }
    })
    .catch(() => {
      const err = $('loginError');
      if (err) err.style.display = 'block';
    });
}

function doLogout() {
    localStorage.removeItem('vivoSessionTime');
    localStorage.removeItem('vivoSessionToken');
    appState.sessionToken = '';
    location.reload();
}

function forgotPassword() {
    const code = prompt('أدخل كود الاستعادة (Master Code):');
    if (!code) return;
    
    const newPass = prompt('أدخل كلمة المرور الجديدة:');
    if (!newPass || newPass.length < 4) return toast('كلمة المرور قصيرة جداً أو ملغاة');
    
    apiPost('/api/password/master_reset', { master: code, password: newPass })
        .then((data) => {
            if (data.ok) {
                appState.sessionToken = '';
                localStorage.removeItem('vivoSessionToken');
                toast('تم إعادة تعيين كلمة المرور بنجاح، يرجى تسجيل الدخول مرة أخرى');
            } else {
                toast('كود الاستعادة غير صحيح');
            }
        })
        .catch((err) => toast(`فشل: ${err.message}`));
}

function togglePasswordVisibility(inputId, iconId) {
    const input = $(inputId);
    const icon = $(iconId);
    if (!input || !icon) return;
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
        icon.style.color = '#3498db';
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
        icon.style.color = '#7f8c8d';
    }
}

function systemReboot() {
    if (confirm('هل أنت متأكد من إعادة تشغيل النظام؟')) {
        apiPost('/api/system/reboot').then(() => {
            toast('جاري إعادة التشغيل...');
            setTimeout(() => location.reload(), 5000);
        });
    }
}

function systemFactoryReset() {
    if (confirm('تحذير خطير: سيتم مسح جميع الإعدادات والمواقيت والشبكات. هل أنت متأكد تماماً؟')) {
        apiPost('/api/system/reset').then(() => {
            toast('جاري ضبط المصنع ومسح الإعدادات...');
            setTimeout(() => location.reload(), 8000);
        });
    }
}

function systemShutdown() {
    if (confirm('تحذير: سيتم إغلاق النظام نهائياً ولن يعمل إلا بفصل الكهرباء وإعادتها. هل أنت متأكد؟')) {
        apiPost('/api/system/shutdown').then(() => {
            toast('تم إغلاق النظام بنجاح. افصل الكهرباء لإعادة التشغيل.');
            setTimeout(() => $('mainContent').innerHTML = '<h1 style="text-align:center; margin-top:20vh;">تم إغلاق النظام</h1>', 2000);
        });
    }
}

function initDashboard() {
  const epochSecs = Math.floor(Date.now() / 1000);
  apiPost('/api/time/sync_browser', { timestamp: epochSecs }).then(() => {
    updateClock();
    setTimeout(fetchPrayerTimes, 700);
  });

  const startupJobs = [
    fetchStatus,
    loadCountries,
    loadManualSettings,
    loadDailyOffsetStatus,
    loadSchedules,
    loadMaghribAlerts,
    loadStartupSettings,
    loadSessionTimeout,
    loadWifiStatus,
    loadApConfig,
    loadEidModeStatus,
    loadEidSchedules,
    loadEidTakbeerConfig,
    populateGpioPins,
    loadDDNS
  ];
  startupJobs.forEach((job, index) => setTimeout(job, 150 + (index * 180)));
  setTimeout(loadCsvStatus, 1200);
  setTimeout(loadFileList, 3000);

  // Periodic background time sync every 10 minutes
  if (!window._periodicTimeSyncTimer) {
    window._periodicTimeSyncTimer = setInterval(() => {
      const epochSecs = Math.floor(Date.now() / 1000);
      apiPost('/api/time/sync_browser', { timestamp: epochSecs });
    }, 600000);
  }
}

function format12Hour(time24) {
  if (!time24 || time24 === '--:--' || time24.indexOf(':') === -1) return time24;
  let [h, m] = time24.split(':');
  let hi = parseInt(h, 10);
  const ampm = hi >= 12 ? 'م' : 'ص';
  hi = hi % 12;
  hi = hi ? hi : 12;
  return `${String(hi).padStart(2, '0')}:${m} ${ampm}`;
}

function updateClock(data) {
  if (data && data.time) {
    if ($('timeDisplay') && data.time) $('timeDisplay').textContent = format12Hour(data.time);
    if ($('gregDate')) $('gregDate').textContent = data.greg || '';
    if ($('hijriDate')) $('hijriDate').textContent = data.hijri || '';
    if ($('dayDisplay') && data.greg) {
      try {
        const [year, month, day] = data.greg.split('-').map(Number);
        const dateObj = new Date(year, month - 1, day);
        const weekdaysArabic = ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];
        $('dayDisplay').textContent = weekdaysArabic[dateObj.getDay()];
      } catch (e) {
        console.error("Day calculation error:", e);
      }
    }
  } else {
    apiGet('/api/clock', {}).then((clockData) => {
      updateClock(clockData);
    });
  }
}

function fetchStatus() {
  const isUserActive = (Date.now() - (appState.lastUserInteraction || 0)) < 60000;
  let url = `/api/status?active=${isUserActive ? '1' : '0'}`;
  if (appState.sessionToken) {
    url += `&token=${encodeURIComponent(appState.sessionToken)}`;
  }
  apiGet(url, {}).then((data) => {
    if (appState.sessionToken && data.authenticated === false) {
      doLogout();
      return;
    }
    
    // Update local clock using data directly from status response
    updateClock(data);

    // Auto-sync if device lost its clock (year 1970)
    if (data.greg && data.greg.startsWith('1970')) {
      const nowEpoch = Math.floor(Date.now() / 1000);
      if (!window._lastAutoSync || (Date.now() - window._lastAutoSync > 15000)) {
        window._lastAutoSync = Date.now();
        apiPost('/api/time/sync_browser', { timestamp: nowEpoch }).then(() => {
          setTimeout(fetchPrayerTimes, 600);
        });
      }
    }

    const isAdhan = data.adhan === true;
    const statusCard = $('playbackStatusCard');
    const statusIcon = $('playbackStatusIcon');
    if (statusCard) {
      statusCard.className = 'playback-status-card';
      if (!data.playing) {
        statusCard.classList.add('status-stopped');
      } else {
        const text = data.status_text || '';
        if (isAdhan || text.includes('أذان') || text.includes('الاذان')) {
          statusCard.classList.add('status-adhan');
        } else if (text.includes('إقامة') || text.includes('اقامة') || text.includes('صلاة') || text.includes('تقام')) {
          statusCard.classList.add('status-iqama');
        } else if (text.includes('تكبيرات') || text.includes('التكبيرات') || text.includes('تكبير')) {
          statusCard.classList.add('status-takbeer');
        } else if (text.includes('قائمة') || text.includes('قوائم') || text.includes('تشغيل قائمة')) {
          statusCard.classList.add('status-playlist');
        } else if (text.includes('قبل المغرب') || text.includes('تنبيه قبل المغرب')) {
          statusCard.classList.add('status-maghrib');
        } else if (text.includes('تنبيهات العيد') || text.includes('تنبيه عيد') || (!!data.eidMode && text.includes('تنبيه'))) {
          statusCard.classList.add('status-eid-alert');
        } else if (text.includes('يدوي') || text.startsWith('تشغيل:')) {
          statusCard.classList.add('status-manual');
        } else if (text.includes('مهم') || text.includes('بدء التشغيل')) {
          statusCard.classList.add('status-alert-important');
        } else {
          statusCard.classList.add('status-alert-normal');
        }
      }
    }
    if (statusIcon) {
      const text = data.status_text || '';
      if (!data.playing) {
        statusIcon.innerHTML = '<i class="fas fa-stop"></i>';
      } else if (isAdhan || text.includes('أذان') || text.includes('الاذان')) {
        statusIcon.innerHTML = '<i class="fas fa-mosque"></i>';
      } else if (text.includes('إقامة') || text.includes('اقامة') || text.includes('صلاة') || text.includes('تقام')) {
        statusIcon.innerHTML = '<i class="fas fa-mosque"></i>';
      } else if (text.includes('تكبيرات') || text.includes('التكبيرات') || text.includes('تكبير')) {
        statusIcon.innerHTML = '<i class="fas fa-star-and-crescent"></i>';
      } else {
        statusIcon.innerHTML = '<i class="fas fa-play"></i>';
      }
    }
    if ($('playingStatus')) {
      $('playingStatus').textContent = data.playing ? (data.status_text || `يعمل: ${data.file || ''}`) : 'متوقف';
    }
    if ($('radioNowPlayingText')) {
      $('radioNowPlayingText').textContent = data.playing ? (data.status_text || `يعمل: ${data.file || ''}`) : 'البث متوقف حالياً';
    }
    if ($('volumeSlider') && data.volume !== undefined) {
      $('volumeSlider').value = data.volume;
      if ($('mainVolVal')) $('mainVolVal').textContent = data.volume;
    }
    if ($('radioVolumeSlider') && data.volume !== undefined) {
      $('radioVolumeSlider').value = data.volume;
      if ($('radioVolVal')) $('radioVolVal').textContent = data.volume;
    }
    updateEidModeBanner(!!data.eidMode);
    if ($('playlistVolume') && data.volume !== undefined) {
      $('playlistVolume').value = data.volume;
      if ($('playlistVolVal')) $('playlistVolVal').textContent = data.volume;
    }
    const showControls = data.playing && !isAdhan;
    if ($('stopBtn')) $('stopBtn').style.display = showControls ? 'inline-block' : 'none';
    if ($('dashStopBtn')) $('dashStopBtn').style.display = showControls ? 'inline-block' : 'none';
    if ($('radioStopBtn')) $('radioStopBtn').style.display = showControls ? 'inline-block' : 'none';
    if ($('playerControlsContainer')) {
      const isPlaying = !!data.playing;
      $('playerControlsContainer').style.display = isPlaying ? 'block' : 'none';
      if ($('quickPlayerPlaceholder')) {
        $('quickPlayerPlaceholder').style.display = isPlaying ? 'none' : 'block';
      }
    }
    if ($('dashPlayerControlsContainer')) {
      $('dashPlayerControlsContainer').style.display = data.playing ? 'block' : 'none';
    }
    if ($('playerControls')) {
      $('playerControls').style.display = data.playing && !isAdhan ? 'block' : 'none';
    }
    if ($('dashPlayerControls')) {
      $('dashPlayerControls').style.display = data.playing && !isAdhan ? 'block' : 'none';
    }
    if ($('playPauseBtn')) {
      if (data.state === 1) $('playPauseBtn').innerHTML = '<i class="fas fa-pause"></i> إيقاف مؤقت';
      else if (data.state === 2) $('playPauseBtn').innerHTML = '<i class="fas fa-play"></i> تشغيل';
    }
    if ($('dashPlayPauseBtn')) {
      if (data.state === 1) $('dashPlayPauseBtn').innerHTML = '<i class="fas fa-pause"></i> إيقاف مؤقت';
      else if (data.state === 2) $('dashPlayPauseBtn').innerHTML = '<i class="fas fa-play"></i> تشغيل';
    }

    // Smart Polling: Fetch track progress details only when audio is active
    if (data.playing) {
      fetchTrackInfo();
    } else {
      if ($('trackDuration')) $('trackDuration').textContent = '--:--';
      if ($('trackPosition')) $('trackPosition').textContent = '00:00';
      if ($('trackProgress')) $('trackProgress').value = 0;
      if ($('dashTrackDuration')) $('dashTrackDuration').textContent = '--:--';
      if ($('dashTrackPosition')) $('dashTrackPosition').textContent = '00:00';
      if ($('dashTrackProgress')) $('dashTrackProgress').value = 0;
    }
  });
}

function fetchTrackInfo() {
  apiGet('/api/audio/track_info', {}).then((data) => {
    const durationStr = data.duration ? formatTime(data.duration) : '--:--';
    const positionStr = data.position !== undefined ? formatTime(data.position) : '00:00';
    const pct = (data.duration > 0 && data.position !== undefined) ? Math.min(100, (data.position / data.duration) * 100) : 0;
    
    if ($('trackDuration')) $('trackDuration').textContent = durationStr;
    if ($('trackPosition')) $('trackPosition').textContent = positionStr;
    if ($('trackProgress')) $('trackProgress').value = pct;

    if ($('dashTrackDuration')) $('dashTrackDuration').textContent = durationStr;
    if ($('dashTrackPosition')) $('dashTrackPosition').textContent = positionStr;
    if ($('dashTrackProgress')) $('dashTrackProgress').value = pct;
  });
}

function formatTime(seconds) {
  if (!seconds && seconds !== 0) return '--:--';
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

function setVolume(value) {
  apiPost('/api/audio/volume', { volume: value })
    .then(fetchStatus)
    .catch((err) => {
      if (err.message && err.message.includes('adhan_playing')) {
        toast('لا يمكن تعديل الصوت أثناء الأذان أو الإقامة');
      } else {
        console.error(err);
      }
    });
}

function stopAudio() {
  apiPost('/api/audio/stop')
    .then(() => {
      fetchStatus();
      if ($('playerControlsContainer')) $('playerControlsContainer').style.display = 'none';
      if ($('quickPlayerPlaceholder')) $('quickPlayerPlaceholder').style.display = 'block';
      if ($('dashPlayerControlsContainer')) $('dashPlayerControlsContainer').style.display = 'none';
    })
    .catch((err) => {
      if (err.message && err.message.includes('adhan_playing')) {
        toast('لا يمكن إيقاف التشغيل أثناء الأذان أو الإقامة');
      } else {
        console.error(err);
      }
    });
}

function pauseAudio() {
  apiPost('/api/audio/pause')
    .then(fetchStatus)
    .catch((err) => console.error(err));
}

function resumeAudio() {
  apiPost('/api/audio/resume')
    .then(fetchStatus)
    .catch((err) => console.error(err));
}

function seekAudio(seconds) {
  apiPost('/api/audio/seek', { seconds })
    .catch((err) => console.error(err));
}

function seekForward() {
  apiGet('/api/audio/track_info', {}).then((data) => {
    const pos = data.position || 0;
    seekAudio(pos + 10);
  }).catch(() => {});
}

function seekBackward() {
  apiGet('/api/audio/track_info', {}).then((data) => {
    const pos = data.position || 0;
    seekAudio(Math.max(0, pos - 10));
  }).catch(() => {});
}

function togglePlayPause() {
  apiGet('/api/audio/track_info', {}).then((data) => {
    if (data.adhan) {
      toast('لا يمكن التحكم في التشغيل أثناء الأذان أو الإقامة');
      return;
    }
    if (data.state === 2) { // AUDIO_PAUSED
      resumeAudio();
      if ($('playPauseBtn')) $('playPauseBtn').innerHTML = '<i class="fas fa-pause"></i> إيقاف مؤقت';
      if ($('dashPlayPauseBtn')) $('dashPlayPauseBtn').innerHTML = '<i class="fas fa-pause"></i> إيقاف مؤقت';
    } else if (data.state === 1) { // AUDIO_PLAYING
      pauseAudio();
      if ($('playPauseBtn')) $('playPauseBtn').innerHTML = '<i class="fas fa-play"></i> تشغيل';
      if ($('dashPlayPauseBtn')) $('dashPlayPauseBtn').innerHTML = '<i class="fas fa-play"></i> تشغيل';
    }
  }).catch(() => {});
}

function setTrackProgress(value) {
  if (!value) return;
  apiGet('/api/audio/track_info', {}).then((data) => {
    if (data.duration > 0) {
      const seconds = Math.floor((value / 100) * data.duration);
      seekAudio(seconds);
    }
  }).catch(() => {});
}

function scanWiFi() {
  const btn = document.querySelector('button[onclick="scanWiFi()"]');
  if (btn) btn.disabled = true;
  if ($('wifiList')) $('wifiList').innerHTML = '<p>جاري البحث عن الشبكات...</p>';

  fetch('/api/wifi/scan')
    .then((r) => {
      if (r.status === 202) {
        setTimeout(scanWiFi, 2500);
        return null;
      }
      return r.json();
    })
    .then((data) => {
      if (!data || !data.networks) return;
      const html = data.networks.map((n) =>
        `<div class="file-item" onclick="selectNetwork('${safeAttr(n.ssid)}')"><span>${safeText(n.ssid)}</span><span>${n.rssi} dBm</span></div>`
      ).join('');
      if ($('wifiList')) $('wifiList').innerHTML = html || '<p>لا توجد شبكات</p>';
    })
    .catch((err) => {
      console.error(err);
      if ($('wifiList')) $('wifiList').innerHTML = '<p>تعذر البحث عن الشبكات</p>';
    })
    .finally(() => { if (btn) btn.disabled = false; });
}

function getNetworkForm() {
  return {
    ssid: $('ssid')?.value || '',
    pass: $('wifiPass')?.value || '',
    dhcp: $('dhcpToggle')?.checked ? '1' : '0',
    ip: $('staticIP')?.value || '192.168.1.100',
    gw: $('gateway')?.value || '192.168.1.1',
    mask: $('subnet')?.value || '255.255.255.0',
    dns: $('dns')?.value || '8.8.8.8'
  };
}

function saveNetwork() {
  apiPost('/api/wifi/save', getNetworkForm())
    .then(() => toast('تم حفظ إعدادات الشبكة'))
    .catch((err) => toast(`فشل الحفظ: ${err.message}`));
}

function connectNetwork() {
  const data = getNetworkForm();
  if (!data.ssid) return toast('اختر أو اكتب اسم الشبكة أولاً');
  toast('جاري الاتصال بالشبكة...');

  apiPost('/api/wifi/connect', data)
    .then((result) => {
      if (result.connected) {
        const ip = result.ip || '';
        toast(`تم الاتصال بنجاح. IP: ${ip}`);
        loadWifiStatus();
      } else {
        toast('فشل الاتصال. ستبقى نقطة VivoSmart-Setup متاحة.');
        loadWifiStatus();
      }
    })
    .catch((err) => {
      toast(`فشل الاتصال: ${err.message}`);
      loadWifiStatus();
    });
}

function loadWifiStatus() {
  apiGet('/api/wifi/status', {}).then((data) => {
    if ($('dhcpToggle')) $('dhcpToggle').checked = !!data.dhcp;
    if ($('ssid') && data.savedSsid) $('ssid').value = data.savedSsid;
    if ($('staticIP')) $('staticIP').value = data.staticIp || '192.168.1.100';
    if ($('gateway')) $('gateway').value = data.gateway || '192.168.1.1';
    if ($('subnet')) $('subnet').value = data.subnet || '255.255.255.0';
    if ($('dns')) $('dns').value = data.dns || '8.8.8.8';
    toggleDHCP();

    const icon = $('netIcon');
    const title = $('netTitle');
    const detail = $('netDetail');
    const ssidEl = $('netSsid');
    if (data.connected) {
      if (icon) { icon.className = 'network-icon connected'; icon.innerHTML = '<i class="fas fa-wifi"></i>'; }
      if (title) { title.className = 'network-title connected'; title.textContent = 'متصل'; }
      if (detail) detail.textContent = `IP: ${data.ip || ''}`;
      if (ssidEl) ssidEl.textContent = `الشبكة: ${data.ssid || ''}`;
    } else {
      if (icon) { icon.className = 'network-icon disconnected'; icon.innerHTML = '<i class="fas fa-wifi-slash"></i>'; }
      if (title) { title.className = 'network-title disconnected'; title.textContent = 'غير متصل'; }
      if (detail) detail.textContent = `نقطة الإعداد: ${data.apIp || '192.168.4.1'}`;
      if (ssidEl) ssidEl.textContent = data.savedSsid ? `محفوظة: ${data.savedSsid}` : '';
    }
  });
}

function loadApConfig() {
  apiGet('/api/ap/config', {}).then((data) => {
    if ($('apSsid')) $('apSsid').value = data.ssid || 'VivoSmart-Setup';
    if ($('apPass')) $('apPass').placeholder = data.hasPass ? '•••••••• (محمية بكلمة مرور)' : 'بدون كلمة مرور (شبكة مفتوحة)';
    if ($('apStatusBadge')) {
      $('apStatusBadge').textContent = data.active ? `نشطة (${data.stations || 0} أجهزة متصلة)` : 'متوقفة';
      $('apStatusBadge').style.background = data.active ? '#28a745' : '#6c757d';
    }
  });
}

function saveApConfig() {
  const ssid = ($('apSsid') ? $('apSsid').value.trim() : '');
  const pass = ($('apPass') ? $('apPass').value.trim() : '');
  if (!ssid || ssid.length < 3) {
    toast('اسم نقطة الاتصال يجب ألا يقل عن 3 أحرف', 'error');
    return;
  }
  if (pass && pass.length < 8) {
    toast('كلمة المرور يجب ألا تقل عن 8 أحرف أو اتركها فارغة لشبكة مفتوحة', 'error');
    return;
  }
  apiPost('/api/ap/config', { ssid, pass }).then((res) => {
    if (res && res.ok) {
      toast('تم حفظ إعدادات نقطة الاتصال (Setup AP) بنجاح');
      loadApConfig();
    } else {
      toast('فشل الحفظ: ' + (res.error || 'خطأ غير معروف'), 'error');
    }
  });
}

function selectNetwork(ssid) {
  if ($('ssid')) $('ssid').value = ssid;
}

function toggleDHCP() {
  if ($('staticIPFields')) $('staticIPFields').style.display = $('dhcpToggle')?.checked ? 'none' : 'block';
}

function loadDDNS() {
  apiGet('/api/ddns/config', {}).then((data) => {
    if ($('ddnsToggle')) {
      $('ddnsToggle').checked = data.enabled || false;
      toggleDDNS(false);
    }
    if ($('ddnsProvider') && data.provider) $('ddnsProvider').value = data.provider;
    if ($('ddnsDomain')) $('ddnsDomain').value = data.domain || '';
    if ($('ddnsUser')) $('ddnsUser').value = data.user || '';
    if ($('ddnsPass')) $('ddnsPass').value = data.hasPass ? '********' : '';
    if ($('ddnsUseIpv6')) $('ddnsUseIpv6').checked = data.useIPv6 !== false;
    if ($('ddnsStatusBadge')) {
      $('ddnsStatusBadge').textContent = data.status || (data.enabled ? 'مفعل' : 'غير مفعل');
      $('ddnsStatusBadge').style.background = (data.status && data.status.includes('✅')) ? '#28a745' : (data.enabled ? '#f39c12' : '#6c757d');
    }
    if ($('globalIpv6Banner') && $('globalIpv6Link')) {
      if (data.globalIPv6 && data.globalIPv6.length > 4) {
        const url = `http://[${data.globalIPv6}]/`;
        $('globalIpv6Banner').style.display = 'block';
        $('globalIpv6Link').href = url;
        $('globalIpv6Link').textContent = url;
      } else {
        $('globalIpv6Banner').style.display = 'none';
      }
    }
  });
  loadTelegramConfig();
}

function toggleDDNS(userTriggered = false) {
  if ($('ddnsFields')) $('ddnsFields').style.display = $('ddnsToggle')?.checked ? 'block' : 'none';
}

function saveDDNS() {
  const enabled = $('ddnsToggle')?.checked ? '1' : '0';
  const provider = $('ddnsProvider')?.value || 'noip';
  const domain = $('ddnsDomain')?.value || '';
  const user = $('ddnsUser')?.value || '';
  const pass = $('ddnsPass')?.value || '';
  const useIPv6 = $('ddnsUseIpv6')?.checked ? '1' : '0';
  apiPost('/api/ddns/save', { enabled, provider, domain, user, pass, useIPv6 }).then(() => {
    toast('تم حفظ إعدادات DDNS وجاري التحديث...');
    setTimeout(loadDDNS, 2500);
  });
}

function loadTelegramConfig() {
  apiGet('/api/telegram/config', {}).then((data) => {
    if ($('tgToggle')) {
      $('tgToggle').checked = !!data.enabled;
      toggleTelegramFields();
    }
    if ($('tgToken')) $('tgToken').value = data.hasToken ? '********' : '';
    if ($('tgChatId')) $('tgChatId').value = data.chatId || '';
    if ($('tgStatusBadge')) {
      $('tgStatusBadge').textContent = data.status || (data.enabled ? 'مفعل' : 'غير مفعل');
      $('tgStatusBadge').style.background = (data.status && data.status.includes('✅')) ? '#28a745' : (data.enabled ? '#3498db' : '#6c757d');
    }
  });
}

function toggleTelegramFields() {
  if ($('tgFields')) $('tgFields').style.display = $('tgToggle')?.checked ? 'block' : 'none';
}

function saveTelegramConfig() {
  const enabled = $('tgToggle')?.checked ? '1' : '0';
  const token = $('tgToken')?.value || '';
  const chatId = $('tgChatId')?.value || '';
  apiPost('/api/telegram/save', { enabled, token, chatId }).then(() => {
    toast('تم حفظ إعدادات بوت تيليجرام للتحكم عن بعد');
    setTimeout(loadTelegramConfig, 2000);
  });
}

function defaultPrayerMethod(country) {
  if (country === 'Egypt') return '0';
  if (country === 'Saudi Arabia') return '2';
  return '1';
}

function loadPrayerTab(force = false) {
  if (!appState.prayerUiLoaded || force) {
    appState.prayerUiLoaded = true;
    loadCountries();
    loadManualSettings();
    loadDailyOffsetStatus();
  } else {
    fetchPrayerTimes();
  }
  if (!appState.csvStatusLoaded || force) loadCsvStatus();
}

function loadCountries() {
  apiGet('/api/location/countries', { countries: [] }).then((data) => {
    appState.countries = data.countries || data || [];
    const select = $('countrySelect');
    if (!select) return;
    select.innerHTML = '<option value="">اختر الدولة</option>' +
      appState.countries.map((country) => `<option value="${safeAttr(country)}">${safeText(country)}</option>`).join('');
    
    // Load config after countries are populated
    apiGet('/api/prayer/config', {}).then((cfg) => {
      if (cfg.country) {
        select.value = cfg.country;
        if ($('methodSelect') && cfg.method !== undefined) {
          $('methodSelect').value = cfg.method;
        }
        if ($('offsetHijri') && cfg.hijriOffset !== undefined) {
          $('offsetHijri').value = cfg.hijriOffset;
        }
        if ($('egyptDstToggle') && cfg.egyptDst !== undefined) {
          $('egyptDstToggle').checked = cfg.egyptDst;
        }
        const egyptDstCont = $('egyptDstContainer');
        if (egyptDstCont) {
          egyptDstCont.style.display = (cfg.country === 'Egypt' || cfg.country === 'مصر') ? 'flex' : 'none';
        }
        // Fetch cities for this country and set the selected city
        apiGet(`/api/location/cities?country=${encodeURIComponent(cfg.country)}`, { cities: [] }).then((cData) => {
          appState.cities = cData.cities || cData || [];
          const cSelect = $('citySelect');
          if (cSelect) {
            cSelect.innerHTML = '<option value="">اختر المدينة</option>' +
              appState.cities.map((city) => `<option value="${safeAttr(city)}">${safeText(city)}</option>`).join('');
            if (cfg.city) cSelect.value = cfg.city;
          }
          fetchPrayerTimes(); // Automatically calculate and display
        });
      }
    });
  });
}

function onCountryChange() {
  const country = $('countrySelect')?.value || '';
  const egyptDstCont = $('egyptDstContainer');
  if (egyptDstCont) {
    egyptDstCont.style.display = (country === 'Egypt' || country === 'مصر') ? 'flex' : 'none';
  }
  if ($('citySelect')) $('citySelect').innerHTML = '<option value="">اختر المدينة</option>';
  if ($('methodSelect') && country) $('methodSelect').value = defaultPrayerMethod(country);
  if (!country) return;
  apiGet(`/api/location/cities?country=${encodeURIComponent(country)}`, { cities: [] }).then((data) => {
    appState.cities = data.cities || data || [];
    const select = $('citySelect');
    if (!select) return;
    select.innerHTML = '<option value="">اختر المدينة</option>' +
      appState.cities.map((city) => `<option value="${safeAttr(city)}">${safeText(city)}</option>`).join('');
  });
}

function fetchPrayerTimes() {
  const countrySelect = $('countrySelect');
  const citySelect = $('citySelect');
  const country = countrySelect?.value || '';
  const city = citySelect?.value || '';
  const method = $('methodSelect')?.value || '0';
  const egyptDst = $('egyptDstToggle')?.checked ? 1 : 0;
  const query = country && city ? 
    `?country=${encodeURIComponent(country)}&city=${encodeURIComponent(city)}&method=${method}&egyptDst=${egyptDst}` : 
    `?method=${method}&egyptDst=${egyptDst}`;

  if (country && city && $('locationDisplay')) {
    const cName = countrySelect.options[countrySelect.selectedIndex]?.text || country;
    const ciName = citySelect.options[citySelect.selectedIndex]?.text || city;
    $('locationDisplay').innerHTML = `<i class="fas fa-map-marker-alt"></i> ${safeText(cName)} - ${safeText(ciName)}`;
  }

  apiGet(`/api/prayer/times${query}`, { ok: false }).then((data) => {
    if (data.ok === false) {
      toast('تعذر حساب المواقيت: اختر دولة ومدينة صحيحتين');
      return;
    }
    if ($('fajrTime')) $('fajrTime').textContent = format12Hour(data.fajr);
    if ($('dhuhrTime')) $('dhuhrTime').textContent = format12Hour(data.dhuhr);
    if ($('asrTime')) $('asrTime').textContent = format12Hour(data.asr);
    if ($('maghribTime')) $('maghribTime').textContent = format12Hour(data.maghrib);
    if ($('ishaTime')) $('ishaTime').textContent = format12Hour(data.isha);

    const badge = $('prayerSourceBadge');
    if (badge && data.source) {
      badge.textContent = data.source;
      badge.style.display = 'inline-block';
      badge.className = 'prayer-source-badge';
      if (data.source.includes('انترنت')) badge.classList.add('source-internet');
      else if (data.source.includes('روزمانة')) badge.classList.add('source-calendar');
      else if (data.source.includes('يدوي')) badge.classList.add('source-manual');
      else badge.classList.add('source-local');
    } else if (badge) {
      badge.style.display = 'none';
    }
    
    if ($('nextPrayer') && data.next) {
       const parts = data.next.split(' ');
       if(parts.length >= 2) {
           $('nextPrayer').textContent = `الصلاة القادمة: ${parts[0]} ${format12Hour(parts[1])}`;
       } else {
           $('nextPrayer').textContent = `الصلاة القادمة: ${data.next}`;
       }
    } else if ($('nextPrayer')) {
       $('nextPrayer').textContent = '';
    }
    // Highlight next prayer in dashboard
    const nextText = data.next || '';
    ['fajr','dhuhr','asr','maghrib','isha'].forEach(name => {
      const el = $(`prayer-${name}`);
      if (el) el.classList.remove('prayer-next');
    });
    if (nextText) {
      const nextName = nextText.split(' ')[0] || '';
      const map = {'الفجر':'fajr','الظهر':'dhuhr','العصر':'asr','المغرب':'maghrib','العشاء':'isha'};
      const id = map[nextName];
      if (id) {
        const el = $(`prayer-${id}`);
        if (el) el.classList.add('prayer-next');
      }
    }
    updateClock();
  });
}

function saveOffsets() {
  apiPost('/api/prayer/offsets', {
    fajr: $('offsetFajr')?.value || 0,
    dhuhr: $('offsetDhuhr')?.value || 0,
    asr: $('offsetAsr')?.value || 0,
    maghrib: $('offsetMaghrib')?.value || 0,
    isha: $('offsetIsha')?.value || 0,
    hijriOffset: $('offsetHijri')?.value || 0
  }).then(() => {
    toast('تم حفظ الإزاحات');
    fetchPrayerTimes();
    updateClock();
  }).catch((err) => toast(`فشل الحفظ: ${err.message}`));
}

function loadDailyOffsetStatus() {
  const dateParam = $('dailyOffsetDate')?.value || '';
  const query = dateParam ? `?date=${encodeURIComponent(dateParam)}` : '';
  apiGet(`/api/prayer/daily_offset${query}`, { ok: false }).then((data) => {
    if (!data.ok) return;
    if ($('dailyOffsetDate')) $('dailyOffsetDate').value = data.date || '';
    if ($('dailyOffsetFajr')) $('dailyOffsetFajr').value = data.fajr || 0;
    if ($('dailyOffsetDhuhr')) $('dailyOffsetDhuhr').value = data.dhuhr || 0;
    if ($('dailyOffsetAsr')) $('dailyOffsetAsr').value = data.asr || 0;
    if ($('dailyOffsetMaghrib')) $('dailyOffsetMaghrib').value = data.maghrib || 0;
    if ($('dailyOffsetIsha')) $('dailyOffsetIsha').value = data.isha || 0;
    if ($('dailyOffsetStatus')) {
      $('dailyOffsetStatus').textContent = data.exists ? `يوجد تصحيح محفوظ لهذا اليوم: ${data.date}` : `لا يوجد تصحيح محفوظ لهذا اليوم: ${data.date}`;
    }
  });
}

function saveDailyOffset() {
  apiPost('/api/prayer/daily_offset', {
    date: $('dailyOffsetDate')?.value || '',
    fajr: $('dailyOffsetFajr')?.value || 0,
    dhuhr: $('dailyOffsetDhuhr')?.value || 0,
    asr: $('dailyOffsetAsr')?.value || 0,
    maghrib: $('dailyOffsetMaghrib')?.value || 0,
    isha: $('dailyOffsetIsha')?.value || 0
  }).then(() => {
    toast('تم حفظ تصحيح هذا اليوم فقط');
    loadDailyOffsetStatus();
    fetchPrayerTimes();
  }).catch((err) => toast(`فشل الحفظ: ${err.message}`));
}

function deleteDailyOffset() {
  apiPost('/api/prayer/daily_offset/delete', {
    date: $('dailyOffsetDate')?.value || ''
  }).then(() => {
    toast('تم حذف تصحيح هذا اليوم');
    loadDailyOffsetStatus();
    fetchPrayerTimes();
  }).catch((err) => toast(`فشل الحذف: ${err.message}`));
}

function loadManualSettings() {
  apiGet('/api/prayer/manual/status', {}).then((data) => {
    if ($('manualModeToggle')) $('manualModeToggle').checked = !!data.enabled;
    ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'].forEach((name) => {
      const key = name.toLowerCase();
      if ($(`man${name}`) && data[key]) $(`man${name}`).value = data[key];
    });
  });
}

function toggleManualMode() {
  saveManualPrayerTimes();
}

function saveManualPrayerTimes() {
  apiPost('/api/prayer/manual/save', {
    enabled: $('manualModeToggle')?.checked ? '1' : '0',
    fajr: $('manFajr')?.value || '',
    dhuhr: $('manDhuhr')?.value || '',
    asr: $('manAsr')?.value || '',
    maghrib: $('manMaghrib')?.value || '',
    isha: $('manIsha')?.value || ''
  }).then(() => {
    toast('تم حفظ المواقيت اليدوية');
    fetchPrayerTimes();
    updateClock();
  }).catch((err) => toast(`فشل الحفظ: ${err.message}`));
}

function loadFileList() {
  apiGet('/api/files/list', { files: [] }).then((data) => {
    renderSdStatus(data.sd || {});
    renderI2SStatus(data.i2s || {});
    appState.files = data.files || [];
    renderFileManager();
    populateFileSelects();
    loadAdhanSettings();
  });
}

function renderFileManager() {
    const folderSelect = $('uploadFolderSelect');
    if (folderSelect) {
        folderSelect.innerHTML = '<option value="/">الرئيسي (Root)</option>' + 
            appState.files.filter(f => f.isDirectory).map(f => `<option value="/${safeAttr(f.name)}">/${safeText(f.name)}</option>`).join('');
        folderSelect.value = currentDir;
    }

    let fileHtml = '';
    if (currentDir !== '/') {
        let parentDir = currentDir.substring(0, currentDir.lastIndexOf('/'));
        if (parentDir === '') parentDir = '/';
        fileHtml += `<div class="file-item" style="background:rgba(255,255,255,0.1); cursor:pointer; justify-content:center;" onclick="currentDir='${parentDir}'; renderFileManager();">
                        <span style="font-weight:bold; color:#f1c40f;"><i class="fas fa-arrow-up"></i> الرجوع للمجلد السابق (${parentDir})</span>
                     </div>`;
    }

    const currentFiles = [];
    appState.files.forEach(f => {
        let path = '/' + f.name;
        let dirPrefix = currentDir === '/' ? '/' : currentDir + '/';
        if (path.startsWith(dirPrefix)) {
            let remainder = path.substring(dirPrefix.length);
            if (!remainder.includes('/')) {
                currentFiles.push({ ...f, shortName: remainder, fullPath: f.name });
            }
        }
    });

    fileHtml += currentFiles.map((f) => {
      const name = safeText(f.shortName);
      if (f.isDirectory) {
          return `<div class="file-item" style="background:rgba(46, 204, 113, 0.1);">
                    <span style="flex-grow:1; cursor:pointer; font-weight:bold; color:#2ecc71;" onclick="currentDir='${currentDir === '/' ? '/' : currentDir + '/'}${name}'; renderFileManager();"><i class="fas fa-folder"></i> ${name}</span>
                    <button class="btn" style="background:#f39c12; margin-left: 5px;" onclick="renameFile('${safeAttr(f.fullPath)}')">تسمية</button>
                    <button class="btn btn-danger" onclick="deleteFile('${safeAttr(f.fullPath)}')">حذف</button>
                  </div>`;
      } else {
          const size = `${((f.size || 0) / 1024 / 1024).toFixed(2)} MB`;
          return `<div class="file-item">
                    <span style="flex-grow:1; cursor:pointer;" onclick="previewFile('${safeAttr(f.fullPath)}')"><i class="fas fa-file-audio"></i> ${name}</span>
                    <span style="margin-left: 10px;">${size}</span>
                    <button class="btn" style="background:#f39c12; margin-left: 5px;" onclick="renameFile('${safeAttr(f.fullPath)}')">تسمية</button>
                    <button class="btn btn-danger" onclick="deleteFile('${safeAttr(f.fullPath)}')">حذف</button>
                  </div>`;
      }
    }).join('');

    if ($('fileList')) $('fileList').innerHTML = fileHtml || '<p style="text-align:center; opacity:0.7;">المجلد فارغ</p>';
}

function toggleFileList() {
    const container = $('fileListContainer');
    const btn = $('btnToggleFiles');
    if (!container || !btn) return;
    if (container.style.display === 'none') {
        container.style.display = 'block';
        btn.innerHTML = '<i class="fas fa-eye-slash"></i> إخفاء الملفات';
    } else {
        container.style.display = 'none';
        btn.innerHTML = '<i class="fas fa-eye"></i> عرض الملفات';
    }
}

function renameFile(oldName) {
    const newName = prompt(`تغيير اسم: ${oldName}\nأدخل الاسم الجديد:`, oldName);
    if (!newName || newName === oldName) return;
    
    apiPost('/api/files/rename', { old: oldName, new: newName })
        .then(() => loadFileList())
        .catch(err => toast(`فشل إعادة التسمية: ${err.message}`));
}

function renderSdStatus(sd) {
  if (!$('sdStatus')) return;
  if (!sd.connected) {
    $('sdStatus').innerHTML = '<div class="file-item"><span>غير متصلة أو غير قابلة للقراءة</span><span>تحقق من التوصيل والفورمات FAT32</span></div>';
    return;
  }

  $('sdStatus').innerHTML = [
    `<div class="file-item"><span>الحالة</span><span>متصلة وتعمل</span></div>`,
    `<div class="file-item"><span>النوع</span><span>${safeText(sd.cardType || 'UNKNOWN')}</span></div>`,
    `<div class="file-item"><span>الحجم</span><span>${sd.usedMB || 0} MB مستخدم / ${sd.totalMB || 0} MB</span></div>`
  ].join('');
}

function renderI2SStatus(i2s) {
  if (!$('i2sStatus')) return;
  if (i2s.ready) {
    $('i2sStatus').innerHTML = '<div class="file-item" style="border-left: 4px solid #2ecc71;"><span>الحالة</span><span style="color:#2ecc71; font-weight:bold;">متصل ويعمل <i class="fas fa-check-circle"></i></span></div>';
  } else {
    $('i2sStatus').innerHTML = '<div class="file-item" style="border-left: 4px solid #e74c3c;"><span>الحالة</span><span style="color:#e74c3c; font-weight:bold;">خطأ في التهيئة <i class="fas fa-times-circle"></i></span></div>';
  }
}

function populateFileSelects() {
  const audioFiles = appState.files.filter((f) =>
    !f.isDirectory &&
    !String(f.name || '').startsWith('prayer_csv/') &&
    /\.(mp3|wav)$/i.test(f.name || '')
  );
  const options = audioFiles
    .map((f) => `<option value="${safeAttr(f.name)}">${safeText(f.name)}</option>`)
    .join('');
  const optionsWithNone = '<option value="">بدون صوت</option>' + options;

  [
    'fajrAdhanFileSelect', 'adhanFileSelect', 'iqamaFileSelect', 'singleAlertFile',
    'eidTakbeerFile', 'playlistFileSelect', 'startupFileSelect', 'presenceAudioFile', 'presenceDevAudioFile'
  ].forEach((id) => { if ($(id)) $(id).innerHTML = options; });

  [
    'gpioSchedAlertFile', 'gpioInputFile'
  ].forEach((id) => { if ($(id)) $(id).innerHTML = optionsWithNone; });

  if ($('playlistFilesChecklist')) {
    $('playlistFilesChecklist').innerHTML = audioFiles
      .map((f) => `
        <label style="display:flex; align-items:center; gap:8px; margin-bottom:6px; cursor:pointer;">
          <input type="checkbox" class="playlist-file-cb" value="${safeAttr(f.name)}">
          <span>${safeText(f.name)}</span>
        </label>
      `).join('');
  }
  if ($('eidScheduleFilesChecklist')) {
    $('eidScheduleFilesChecklist').innerHTML = audioFiles
      .map((f) => `
        <label style="display:flex; align-items:center; gap:8px; margin-bottom:6px; cursor:pointer;">
          <input type="checkbox" class="eid-file-cb" value="${safeAttr(f.name)}">
          <span>${safeText(f.name)}</span>
        </label>
      `).join('');
  }
  loadEidModeStatus();
}

function uploadFile() {
  const input = $('fileInput');
  if (!input?.files?.length) return toast('اختر ملفاً أولاً');
  
  const file = input.files[0];
  const folder = $('uploadFolderSelect')?.value || '/';

  const progressBar = $('uploadProgressBar');
  const statusDiv = $('uploadStatus');
  
  if (progressBar) {
      progressBar.style.display = 'block';
      progressBar.value = 0;
  }
  if (statusDiv) {
      statusDiv.style.color = 'inherit';
      statusDiv.textContent = 'جاري الرفع... 0%';
  }

  // 64KB chunk size for rock-solid stability on ESP32 SPI SD card
  const chunkSize = 64 * 1024;
  let offset = 0;
  const startTime = Date.now();
  let retryCount = 0;
  const maxRetries = 3;

  const sendChunk = () => {
      const end = Math.min(offset + chunkSize, file.size);
      const chunk = file.slice(offset, end);
      const finalChunk = end >= file.size ? '1' : '0';
      const url = `/api/files/upload_chunk?name=${encodeURIComponent(file.name)}&folder=${encodeURIComponent(folder)}&offset=${offset}&total=${file.size}&final=${finalChunk}`;
      const xhr = new XMLHttpRequest();
      xhr.open('POST', url, true);
      xhr.timeout = 30000; // 30s timeout per chunk
      xhr.setRequestHeader('Content-Type', 'application/octet-stream');

      xhr.ontimeout = function() {
          handleFailure('انتهت مهلة اتصال الشريحة، إعادة المحاولة...');
      };

      xhr.upload.onprogress = function(e) {
          const loaded = offset + (e.lengthComputable ? e.loaded : 0);
          const percentComplete = Math.min(100, Math.round((loaded / file.size) * 100));
          if (progressBar) progressBar.value = percentComplete;
          
          const elapsed = (Date.now() - startTime) / 1000;
          let speedText = '';
          if (elapsed > 0.5) {
              const speedBytesPerSec = loaded / elapsed;
              if (speedBytesPerSec > 1024 * 1024) {
                  speedText = ` (${(speedBytesPerSec / (1024 * 1024)).toFixed(1)} MB/s)`;
              } else {
                  speedText = ` (${(speedBytesPerSec / 1024).toFixed(1)} KB/s)`;
              }
          }
          if (statusDiv) {
              statusDiv.style.color = '';
              statusDiv.textContent = `جاري الرفع... ${percentComplete}%${speedText}`;
          }
      };

      const handleFailure = (errMessage) => {
          if (retryCount < maxRetries) {
              retryCount++;
              if (statusDiv) {
                  statusDiv.style.color = '#f39c12';
                  statusDiv.textContent = `فشل مؤقت، إعادة المحاولة ${retryCount}/${maxRetries}...`;
              }
              setTimeout(sendChunk, 1000);
          } else {
              if (statusDiv) {
                  statusDiv.style.color = '#e74c3c';
                  statusDiv.textContent = errMessage;
              }
              if (progressBar) progressBar.style.display = 'none';
          }
      };

      xhr.onload = function() {
          if (xhr.status !== 200) {
              let detail = xhr.status;
              try {
                  const res = JSON.parse(xhr.responseText);
                  if (res && res.error) detail += ' (' + res.error + ')';
              } catch(e) {}
              handleFailure('فشل الرفع. خطأ من السيرفر: ' + detail);
              return;
          }

          retryCount = 0; // Reset retry count on success
          offset = end;
          const percentComplete = Math.min(100, Math.round((offset / file.size) * 100));
          if (progressBar) progressBar.value = percentComplete;

          if (offset < file.size) {
              sendChunk();
          } else {
              if (statusDiv) {
                  statusDiv.style.color = '#2ecc71';
                  statusDiv.textContent = `تم الرفع كاملاً (${(file.size / (1024 * 1024)).toFixed(2)} MB)`;
              }
              input.value = '';
              loadFileList();
              setTimeout(() => { if (progressBar) progressBar.style.display = 'none'; }, 5000);
          }
      };

      xhr.onerror = function() {
          handleFailure('حدث خطأ في الاتصال أثناء الرفع.');
      };

      xhr.send(chunk);
  };

  sendChunk();
}

function deleteFile(name) {
  if (!confirm(`حذف ${name}؟`)) return;
  apiPost('/api/files/delete', { name }).then(loadFileList).catch((err) => toast(`فشل الحذف: ${err.message}`));
}

function createFolder() {
  const name = $('newFolderName')?.value || '';
  if (!name) return toast('اكتب اسم المجلد');
  apiPost('/api/files/mkdir', { name }).then(loadFileList).catch((err) => toast(`فشل إنشاء المجلد: ${err.message}`));
}

function previewFile(name) {
  if (!/\.(mp3|wav)$/i.test(name)) return;
  if ($('previewCard')) $('previewCard').style.display = 'block';
  if ($('previewName')) $('previewName').textContent = name;
  const encodedPath = name.split('/').map(encodeURIComponent).join('/');
  if ($('audioPlayer')) $('audioPlayer').src = `/sd/${encodedPath}`;
}

function closePreview() {
  if ($('previewCard')) $('previewCard').style.display = 'none';
  if ($('audioPlayer')) $('audioPlayer').pause();
}

function saveAdhanAssignments() {
  const payload = {
    fajr: $('fajrAdhanFileSelect')?.value || '',
    adhan: $('adhanFileSelect')?.value || '',
    iqama: $('iqamaFileSelect')?.value || ''
  };
  for (let i = 0; i < 5; i++) {
    payload[`iqama_en_${i}`] = !!$(`iqama_en_${i}`)?.checked;
    payload[`iqama_del_${i}`] = $(`iqama_del_${i}`)?.value || '10';
  }
  apiPost('/api/adhan/files', payload)
    .then(() => toast('تم حفظ ملفات الأذان وتفضيلات الإقامة'))
    .catch((err) => toast(`فشل الحفظ: ${err.message}`));
}

function loadAdhanSettings() {
  apiGet('/api/adhan/files', {}).then((data) => {
    if (data.fajr && $('fajrAdhanFileSelect')) $('fajrAdhanFileSelect').value = data.fajr;
    if (data.adhan && $('adhanFileSelect')) $('adhanFileSelect').value = data.adhan;
    if (data.iqama && $('iqamaFileSelect')) $('iqamaFileSelect').value = data.iqama;
    for (let i = 0; i < 5; i++) {
      const enCb = $(`iqama_en_${i}`);
      const delInput = $(`iqama_del_${i}`);
      if (enCb) enCb.checked = !!data[`iqama_en_${i}`];
      if (delInput) delInput.value = data[`iqama_del_${i}`] !== undefined ? data[`iqama_del_${i}`] : 10;
    }
  }).catch((err) => console.error('Failed to load adhan settings:', err));
}

let editingSingleAlertIndex = -1;
let editingPlaylistSchedIndex = -1;
let editingGpioSchedIndex = -1;
let editingInputPin = null;
let editingInputOutputPin = null;

function toggleScheduleFields(prefix = 'singleAlert') {
  const type = $(`${prefix}Type`)?.value || 'daily';
  let html = '';
  if (type === 'weekly') {
    html = '<label>اختر الأيام</label><div id="' + prefix + 'WeeklyDays">' +
      dayNames.map((d, i) => `<label style="display:inline-flex;align-items:center;gap:4px;margin:4px 8px 4px 0;font-size:var(--fs-small)"><input type="checkbox" class="${prefix}-weekly-day-cb" value="${i}"> ${d}</label>`
    ).join('') + '</div>';
  } else if (type === 'monthly') {
    html = '<label>اليوم من الشهر</label><input type="number" id="' + prefix + 'Day" min="1" max="31" value="1">';
  } else if (type === 'specific') {
    html = '<label>التاريخ</label><input type="date" id="' + prefix + 'Date">';
  } else if (type === 'yearly') {
    html = '<label>التاريخ السنوي (السنة غير مهمة)</label><input type="date" id="' + prefix + 'Date">';
  } else if (type === 'prayer_relative') {
    html = '<label>الصلاة</label><select id="' + prefix + 'Prayer"><option value="0">الفجر</option><option value="1">الظهر</option><option value="2">العصر</option><option value="3">المغرب</option><option value="4">العشاء</option></select>' +
      '<label>الإزاحة بالدقائق (سالب أو موجب)</label><input type="number" id="' + prefix + 'Offset" value="0">' +
      '<label>أيام التشغيل (اختياري - اتركه فارغاً للتشغيل يومياً)</label><div id="' + prefix + 'WeeklyDays">' +
      dayNames.map((d, i) => `<label style="display:inline-flex;align-items:center;gap:4px;margin:4px 8px 4px 0;font-size:var(--fs-small)"><input type="checkbox" class="${prefix}-weekly-day-cb" value="${i}"> ${d}</label>`
    ).join('') + '</div>';
  }
  const extraFields = $(`${prefix}ExtraFields`);
  if (extraFields) extraFields.innerHTML = html;

  const timeContainer = $(`${prefix}TimeContainer`);
  if (timeContainer) {
    timeContainer.style.display = type === 'prayer_relative' ? 'none' : 'block';
  }
  if (prefix === 'singleAlert') {
    updateRadioPrayerOverrideVisibility();
  }
}

function toggleLoopFields(prefix = 'singleAlert') {
  const loopFields = $(`${prefix}LoopFields`);
  const loopToggle = $(`${prefix}LoopToggle`);
  if (loopFields && loopToggle) {
    loopFields.style.display = loopToggle.value === 'yes' ? 'block' : 'none';
  }
}

function toggleAlertEndTimeField(prefix) {
  const container = $(`${prefix}EndTimeContainer`);
  if (container) {
    container.style.display = 'block';
  }
}

function toggleSkipBoth(checked) {
  if ($('singleAlertSkipAdhan')) $('singleAlertSkipAdhan').checked = checked;
  if ($('singleAlertSkipIqama')) $('singleAlertSkipIqama').checked = checked;
}

function updateSkipBothCheckbox() {
  const adhan = $('singleAlertSkipAdhan')?.checked;
  const iqama = $('singleAlertSkipIqama')?.checked;
  if ($('singleAlertSkipBoth')) {
    $('singleAlertSkipBoth').checked = adhan && iqama;
  }
}

function toggleAlertGpioFields(prefix) {
  const active = $(`${prefix}GpioActive`)?.checked;
  const fields = $(`${prefix}GpioFields`);
  if (fields) {
    fields.style.display = active ? 'block' : 'none';
  }
}

function toggleAlertGpioDurationFields(prefix) {
  const mode = $(`${prefix}GpioDurationMode`)?.value;
  const container = $(`${prefix}GpioDurationContainer`);
  if (container) {
    container.style.display = mode === 'custom' ? 'block' : 'none';
  }
}

function toggleGpioAudioModeFields(prefix) {
  const mode = $(`${prefix}AudioMode`)?.value;
  const container = $(`${prefix}RepeatCountContainer`);
  if (container) {
    container.style.display = mode === 'repeat' ? 'block' : 'none';
  }
}

function toggleGpioFileSelected(prefix) {
  const fileSelect = (prefix === 'gpioInput') ? $('gpioInputFile') : $('gpioSchedAlertFile');
  const fileVal = fileSelect?.value || '';
  const fields = $(`${prefix}AudioFields`);
  if (fields) {
    fields.style.display = fileVal ? 'block' : 'none';
  }
}

function getSelectedDaysBitmask(prefix) {
  const cbs = document.querySelectorAll(`.${prefix}-weekly-day-cb:checked`);
  if (cbs.length === 0) return -1;
  let mask = 0;
  cbs.forEach(cb => { mask |= (1 << parseInt(cb.value)); });
  // Add 128 to represent it as a bitmask to the backend, to distinguish from legacy single day index (0-6)
  return 128 | mask;
}

function formatDays(mask) {
  if (mask < 0) return '';
  if (mask >= 128) {
    const actualMask = mask & 0x7F;
    const days = [];
    for (let i = 0; i < 7; i++) {
      if (actualMask & (1 << i)) days.push(dayNames[i]);
    }
    return days.join('، ');
  }
  if (mask >= 0 && mask <= 6) return dayNames[mask];
  // In case of non-prefixed bitmask (legacy backup)
  const days = [];
  for (let i = 0; i < 7; i++) {
    if (mask & (1 << i)) days.push(dayNames[i]);
  }
  return days.join('، ');
}

function saveSingleAlert() {
  const name = $('singleAlertName')?.value || '';
  const isRadioSource = document.querySelector('input[name="singleAlertSourceType"]:checked')?.value === 'radio';
  const file = isRadioSource ? ($('singleAlertRadioFile')?.value || '') : ($('singleAlertFile')?.value || '');
  if (!file) return toast(isRadioSource ? 'يجب اختيار إذاعة' : 'يجب اختيار ملف صوّتي');

  const [hour = '0', minute = '0'] = ($('singleAlertTime')?.value || '00:00').split(':');
  const type = $('singleAlertType')?.value || 'daily';
  let dayOfWeek = -1, dayOfMonth = -1;
  if (type === 'weekly' || type === 'prayer_relative') dayOfWeek = getSelectedDaysBitmask('singleAlert');
  if (type === 'monthly') dayOfMonth = $('singleAlertDay')?.value || '-1';
  const modeVal = $('singleAlertEidOnly')?.value || '0';
  const eidOnly = modeVal === '1' ? '1' : '0';
  const bothModes = modeVal === '2' ? '1' : '0';
  
  const data = {
    name,
    file,
    type,
    hour,
    minute,
    dayOfWeek,
    dayOfMonth,
    specificDate: $('singleAlertDate')?.value || '',
    volume: $('singleAlertVolume')?.value || 20,
    loop: $('singleAlertLoopToggle')?.value === 'yes' ? $('singleAlertLoopDuration')?.value || 0 : 0,
    prayerIndex: $('singleAlertPrayer')?.value || 0,
    offsetSeconds: Number($('singleAlertOffset')?.value || 0) * 60,
    eidOnly: eidOnly,
    bothModes: bothModes,
    index: editingSingleAlertIndex,
    repeatInterval: Number($('singleAlertRepeatInterval')?.value || 0),
    endHour: $('singleAlertEndTime')?.value ? Number($('singleAlertEndTime').value.split(':')[0]) : -1,
    endMinute: $('singleAlertEndTime')?.value ? Number($('singleAlertEndTime').value.split(':')[1]) : -1,
    gpioActive: $('singleAlertGpioActive')?.checked ? 1 : 0,
    gpioPin: $('singleAlertGpioPin')?.value || 0,
    gpioMode: $('singleAlertGpioMode')?.value || 'continuous',
    gpioDurationMode: $('singleAlertGpioDurationMode')?.value || 'audio_duration',
    gpioDurationSec: Number($('singleAlertGpioDurationSec')?.value || 5),
    important: $('singleAlertImportant')?.checked ? 1 : 0,
    skipAdhan: (isRadioSource && type === 'prayer_relative' && $('singleAlertSkipAdhan')?.checked) ? 1 : 0,
    skipIqama: (isRadioSource && type === 'prayer_relative' && $('singleAlertSkipIqama')?.checked) ? 1 : 0
  };
  if (editingSingleAlertIndex >= 0 && appState.alerts[editingSingleAlertIndex]) {
    data.enabled = appState.alerts[editingSingleAlertIndex].enabled !== false ? 1 : 0;
  }

  apiPost('/api/scheduler/add', data).then(() => {
    toast(editingSingleAlertIndex >= 0 ? 'تم تعديل التنبيه بنجاح' : 'تم إضافة التنبيه بنجاح');
    cancelEditSingleAlert();
    const isEidOnly = data.eidOnly === '1' || data.eidOnly === 1 || data.eidOnly === true || data.eidOnly === 'true';
    if (isEidOnly) {
      showTab('eid');
      showSubTab('tab-eid', 'sub-eid-alerts');
      loadEidSchedules();
    } else if (isRadioSource) {
      showTab('scheduler');
      showSubTab('tab-scheduler', 'sub-sched-list');
      loadSchedules();
      if (data.bothModes) loadEidSchedules();
    } else {
      showTab('scheduler');
      showSubTab('tab-scheduler', 'sub-sched-list');
      loadSchedules();
      if (data.bothModes) loadEidSchedules();
    }
  }).catch((err) => toast(`فشل الحفظ: ${err.message}`));
}

function cancelEditSingleAlert() {
  editingSingleAlertIndex = -1;
  if ($('singleAlertEidOnly')) $('singleAlertEidOnly').value = '0';
  if ($('singleAlertSkipAdhan')) $('singleAlertSkipAdhan').checked = false;
  if ($('singleAlertSkipIqama')) $('singleAlertSkipIqama').checked = false;
  if ($('singleAlertSkipBoth')) $('singleAlertSkipBoth').checked = false;
  if ($('singleAlertName')) $('singleAlertName').value = '';
  if ($('singleAlertFile')) $('singleAlertFile').selectedIndex = 0;
  if ($('singleAlertRadioFile')) $('singleAlertRadioFile').selectedIndex = 0;
  const localSourceRadio = document.querySelector('input[name="singleAlertSourceType"][value="local"]');
  if (localSourceRadio) {
    localSourceRadio.checked = true;
    toggleAlertSourceType();
  }
  if ($('singleAlertType')) {
    $('singleAlertType').value = 'daily';
    toggleScheduleFields('singleAlert');
  }
  if ($('singleAlertTime')) $('singleAlertTime').value = '00:00';
  if ($('singleAlertVolume')) {
    $('singleAlertVolume').value = 20;
    if ($('singleAlertVolumeValue')) $('singleAlertVolumeValue').textContent = '20';
  }
  if ($('singleAlertLoopToggle')) {
    $('singleAlertLoopToggle').value = 'no';
    toggleLoopFields('singleAlert');
  }
  if ($('singleAlertLoopDuration')) $('singleAlertLoopDuration').value = 0;
  if ($('singleAlertRepeatInterval')) $('singleAlertRepeatInterval').value = 0;
  if ($('singleAlertGpioActive')) {
    $('singleAlertGpioActive').checked = false;
    toggleAlertGpioFields('singleAlert');
  }
  if ($('singleAlertGpioPin')) $('singleAlertGpioPin').value = 3;
  if ($('singleAlertGpioMode')) $('singleAlertGpioMode').value = 'continuous';
  if ($('singleAlertGpioDurationMode')) {
    $('singleAlertGpioDurationMode').value = 'audio_duration';
    toggleAlertGpioDurationFields('singleAlert');
  }
  if ($('singleAlertGpioDurationSec')) $('singleAlertGpioDurationSec').value = 5;
  if ($('singleAlertImportant')) $('singleAlertImportant').checked = true;

  if ($('singleAlertSaveBtn')) $('singleAlertSaveBtn').innerHTML = '<i class="fas fa-save"></i> حفظ التنبيه';
  if ($('singleAlertCancelEditBtn')) $('singleAlertCancelEditBtn').style.display = 'none';
}

function editSingleAlert(index) {
  const alert = appState.alerts[index];
  if (!alert) return;
  
  editingSingleAlertIndex = index;
  showSubTab('tab-scheduler', 'sub-sched-add');
  
  if ($('singleAlertEidOnly')) {
    if (alert.bothModes === true || alert.bothModes === 1 || alert.bothModes === '1' || alert.bothModes === 'true') {
      $('singleAlertEidOnly').value = '2';
    } else {
      $('singleAlertEidOnly').value = (alert.eidOnly === true || alert.eidOnly === 1 || alert.eidOnly === '1' || alert.eidOnly === 'true') ? '1' : '0';
    }
  }
  if ($('singleAlertName')) $('singleAlertName').value = alert.name || '';
  
  const isRadioSource = alert.file && (alert.file.startsWith('http://') || alert.file.startsWith('https://'));
  const radioEl = document.querySelector(`input[name="singleAlertSourceType"][value="${isRadioSource ? 'radio' : 'local'}"]`);
  if (radioEl) {
    radioEl.checked = true;
    toggleAlertSourceType();
  }

  if (isRadioSource) {
    if ($('singleAlertRadioFile')) $('singleAlertRadioFile').value = alert.file || '';
  } else {
    if ($('singleAlertFile')) $('singleAlertFile').value = alert.file || '';
  }
  if ($('singleAlertType')) {
    $('singleAlertType').value = alert.type || 'daily';
    toggleScheduleFields('singleAlert');
  }
  
  if ($('singleAlertTime')) {
    $('singleAlertTime').value = `${String(alert.hour).padStart(2, '0')}:${String(alert.minute).padStart(2, '0')}`;
  }
  
  if ($('singleAlertVolume')) {
    $('singleAlertVolume').value = alert.volume !== undefined ? alert.volume : 20;
    if ($('singleAlertVolumeValue')) $('singleAlertVolumeValue').textContent = alert.volume !== undefined ? alert.volume : 20;
  }
  
  if ($('singleAlertLoopToggle')) {
    $('singleAlertLoopToggle').value = (alert.loop && alert.loop > 0) ? 'yes' : 'no';
    toggleLoopFields('singleAlert');
  }
  if ($('singleAlertLoopDuration') && alert.loop) {
    $('singleAlertLoopDuration').value = alert.loop;
  }
  
  if ($('singleAlertRepeatInterval')) {
    $('singleAlertRepeatInterval').value = alert.repeatInterval !== undefined ? alert.repeatInterval : 0;
    toggleAlertEndTimeField('singleAlert');
  }
  if ($('singleAlertEndTime') && alert.endHour !== undefined && alert.endHour >= 0) {
    const eh = String(alert.endHour).padStart(2, '0');
    const em = String(alert.endMinute).padStart(2, '0');
    $('singleAlertEndTime').value = eh + ':' + em;
  } else if ($('singleAlertEndTime')) {
    $('singleAlertEndTime').value = '';
  }
  if ($('singleAlertGpioActive')) {
    $('singleAlertGpioActive').checked = alert.gpioActive === true || alert.gpioActive === 1;
    toggleAlertGpioFields('singleAlert');
  }
  if ($('singleAlertImportant')) {
    $('singleAlertImportant').checked = (alert.important !== false && alert.important !== 0);
  }
  if ($('singleAlertGpioPin') && alert.gpioPin !== undefined) $('singleAlertGpioPin').value = alert.gpioPin;
  if ($('singleAlertGpioMode') && alert.gpioMode !== undefined) $('singleAlertGpioMode').value = alert.gpioMode;
  if ($('singleAlertGpioDurationMode') && alert.gpioDurationMode !== undefined) {
    $('singleAlertGpioDurationMode').value = alert.gpioDurationMode;
    toggleAlertGpioDurationFields('singleAlert');
  }
  if ($('singleAlertGpioDurationSec') && alert.gpioDurationSec !== undefined) $('singleAlertGpioDurationSec').value = alert.gpioDurationSec;
  
  if ((alert.type === 'weekly' || alert.type === 'prayer_relative') && alert.dayOfWeek >= 0) {
    const mask = alert.dayOfWeek;
    document.querySelectorAll('.singleAlert-weekly-day-cb').forEach(cb => {
      const dayVal = parseInt(cb.value);
      if (mask >= 128) {
        cb.checked = !!((mask & 0x7F) & (1 << dayVal));
      } else {
        cb.checked = (dayVal === mask);
      }
    });
  } else if (alert.type === 'monthly' && $('singleAlertDay')) {
    $('singleAlertDay').value = alert.dayOfMonth;
  } else if (alert.type === 'specific' && $('singleAlertDate')) {
    $('singleAlertDate').value = alert.specificDate || '';
  } else if (alert.type === 'prayer_relative') {
    if ($('singleAlertPrayer')) $('singleAlertPrayer').value = alert.prayerIndex !== undefined ? alert.prayerIndex : 0;
    if ($('singleAlertOffset')) $('singleAlertOffset').value = alert.offsetSeconds !== undefined ? Math.round(alert.offsetSeconds / 60) : 0;
  }
  
  if ($('singleAlertSkipAdhan')) $('singleAlertSkipAdhan').checked = alert.skipAdhan === true || alert.skipAdhan === 1;
  if ($('singleAlertSkipIqama')) $('singleAlertSkipIqama').checked = alert.skipIqama === true || alert.skipIqama === 1;
  updateSkipBothCheckbox();
  
  // Call this to update the visibility of override container based on current settings
  updateRadioPrayerOverrideVisibility();

  if ($('singleAlertSaveBtn')) $('singleAlertSaveBtn').innerHTML = '<i class="fas fa-save"></i> تعديل التنبيه';
  if ($('singleAlertCancelEditBtn')) $('singleAlertCancelEditBtn').style.display = 'block';
}

function savePlaylistSched() {
  const name = $('playlistSchedName')?.value || '';
  const checkboxes = document.querySelectorAll('.playlist-file-cb:checked');
  if (checkboxes.length === 0) {
    return toast('يجب اختيار ملف واحد على الأقل للقائمة');
  }
  const files = Array.from(checkboxes).map(cb => cb.value).join(',');
  
  const [hour = '0', minute = '0'] = ($('playlistSchedTime')?.value || '00:00').split(':');
  const type = $('playlistSchedType')?.value || 'daily';
  let dayOfWeek = -1, dayOfMonth = -1;
  if (type === 'weekly' || type === 'prayer_relative') dayOfWeek = getSelectedDaysBitmask('playlistSched');
  if (type === 'monthly') dayOfMonth = $('playlistSchedDay')?.value || '-1';
  
  const data = {
    name,
    file: files,
    type,
    hour,
    minute,
    dayOfWeek,
    dayOfMonth,
    specificDate: $('playlistSchedDate')?.value || '',
    volume: $('playlistSchedVolume')?.value || 20,
    loop: $('playlistSchedLoopToggle')?.value === 'yes' ? $('playlistSchedLoopDuration')?.value || 0 : 0,
    prayerIndex: $('playlistSchedPrayer')?.value || 0,
    offsetSeconds: Number($('playlistSchedOffset')?.value || 0) * 60,
    eidOnly: '0',
    index: editingPlaylistSchedIndex,
    repeatInterval: Number($('playlistSchedRepeatInterval')?.value || 0),
    endHour: $('playlistSchedEndTime')?.value ? Number($('playlistSchedEndTime').value.split(':')[0]) : -1,
    endMinute: $('playlistSchedEndTime')?.value ? Number($('playlistSchedEndTime').value.split(':')[1]) : -1,
    gpioActive: $('playlistSchedGpioActive')?.checked ? 1 : 0,
    gpioPin: $('playlistSchedGpioPin')?.value || 0,
    gpioMode: $('playlistSchedGpioMode')?.value || 'continuous',
    gpioDurationMode: $('playlistSchedGpioDurationMode')?.value || 'audio_duration',
    gpioDurationSec: Number($('playlistSchedGpioDurationSec')?.value || 5),
    important: $('playlistSchedImportant')?.checked ? 1 : 0
  };
  if (editingPlaylistSchedIndex >= 0 && appState.alerts[editingPlaylistSchedIndex]) {
    data.enabled = appState.alerts[editingPlaylistSchedIndex].enabled !== false ? 1 : 0;
  }

  apiPost('/api/scheduler/add', data).then(() => {
    toast(editingPlaylistSchedIndex >= 0 ? 'تم تعديل القائمة المجدولة بنجاح' : 'تم إضافة القائمة للجدولة بنجاح');
    cancelEditPlaylistSched();
    loadSchedules();
  }).catch((err) => toast(`فشل الحفظ: ${err.message}`));
}

function cancelEditPlaylistSched() {
  editingPlaylistSchedIndex = -1;
  if ($('playlistSchedName')) $('playlistSchedName').value = '';
  document.querySelectorAll('.playlist-file-cb').forEach(cb => cb.checked = false);
  if ($('playlistSchedType')) {
    $('playlistSchedType').value = 'daily';
    toggleScheduleFields('playlistSched');
  }
  if ($('playlistSchedTime')) $('playlistSchedTime').value = '00:00';
  if ($('playlistSchedVolume')) {
    $('playlistSchedVolume').value = 20;
    if ($('playlistSchedVolumeValue')) $('playlistSchedVolumeValue').textContent = '20';
  }
  if ($('playlistSchedLoopToggle')) {
    $('playlistSchedLoopToggle').value = 'no';
    toggleLoopFields('playlistSched');
  }
  if ($('playlistSchedLoopDuration')) $('playlistSchedLoopDuration').value = 0;
  if ($('playlistSchedRepeatInterval')) $('playlistSchedRepeatInterval').value = 0;
  if ($('playlistSchedGpioActive')) {
    $('playlistSchedGpioActive').checked = false;
    toggleAlertGpioFields('playlistSched');
  }
  if ($('playlistSchedGpioPin')) $('playlistSchedGpioPin').value = 3;
  if ($('playlistSchedGpioMode')) $('playlistSchedGpioMode').value = 'continuous';
  if ($('playlistSchedGpioDurationMode')) {
    $('playlistSchedGpioDurationMode').value = 'audio_duration';
    toggleAlertGpioDurationFields('playlistSched');
  }
  if ($('playlistSchedGpioDurationSec')) $('playlistSchedGpioDurationSec').value = 5;
  if ($('playlistSchedImportant')) $('playlistSchedImportant').checked = true;

  if ($('playlistSchedSaveBtn')) $('playlistSchedSaveBtn').innerHTML = '<i class="fas fa-plus-circle"></i> إضافة القائمة للجدولة';
  if ($('playlistSchedCancelEditBtn')) $('playlistSchedCancelEditBtn').style.display = 'none';
}

function editPlaylistSched(index) {
  const alert = appState.alerts[index];
  if (!alert) return;
  
  editingPlaylistSchedIndex = index;
  showSubTab('tab-player', 'sub-player-sched');
  
  if ($('playlistSchedName')) $('playlistSchedName').value = alert.name || '';
  
  document.querySelectorAll('.playlist-file-cb').forEach(cb => cb.checked = false);
  
  const filesList = (alert.file || '').split(',');
  filesList.forEach(file => {
    const cb = document.querySelector(`.playlist-file-cb[value="${CSS.escape(file)}"]`);
    if (cb) cb.checked = true;
  });
  
  if ($('playlistSchedType')) {
    $('playlistSchedType').value = alert.type || 'daily';
    toggleScheduleFields('playlistSched');
  }
  
  if ($('playlistSchedTime')) {
    $('playlistSchedTime').value = `${String(alert.hour).padStart(2, '0')}:${String(alert.minute).padStart(2, '0')}`;
  }
  
  if ($('playlistSchedVolume')) {
    $('playlistSchedVolume').value = alert.volume !== undefined ? alert.volume : 20;
    if ($('playlistSchedVolumeValue')) $('playlistSchedVolumeValue').textContent = alert.volume !== undefined ? alert.volume : 20;
  }
  
  if ($('playlistSchedLoopToggle')) {
    $('playlistSchedLoopToggle').value = (alert.loop && alert.loop > 0) ? 'yes' : 'no';
    toggleLoopFields('playlistSched');
  }
  if ($('playlistSchedLoopDuration') && alert.loop) {
    $('playlistSchedLoopDuration').value = alert.loop;
  }
  
  if ($('playlistSchedRepeatInterval')) {
    $('playlistSchedRepeatInterval').value = alert.repeatInterval !== undefined ? alert.repeatInterval : 0;
    toggleAlertEndTimeField('playlistSched');
  }
  if ($('playlistSchedEndTime') && alert.endHour !== undefined && alert.endHour >= 0) {
    const eh = String(alert.endHour).padStart(2, '0');
    const em = String(alert.endMinute).padStart(2, '0');
    $('playlistSchedEndTime').value = eh + ':' + em;
  } else if ($('playlistSchedEndTime')) {
    $('playlistSchedEndTime').value = '';
  }
  if ($('playlistSchedGpioActive')) {
    $('playlistSchedGpioActive').checked = alert.gpioActive === true || alert.gpioActive === 1;
    toggleAlertGpioFields('playlistSched');
  }
  if ($('playlistSchedImportant')) {
    $('playlistSchedImportant').checked = (alert.important !== false && alert.important !== 0);
  }
  if ($('playlistSchedGpioPin') && alert.gpioPin !== undefined) $('playlistSchedGpioPin').value = alert.gpioPin;
  if ($('playlistSchedGpioMode') && alert.gpioMode !== undefined) $('playlistSchedGpioMode').value = alert.gpioMode;
  if ($('playlistSchedGpioDurationMode') && alert.gpioDurationMode !== undefined) {
    $('playlistSchedGpioDurationMode').value = alert.gpioDurationMode;
    toggleAlertGpioDurationFields('playlistSched');
  }
  if ($('playlistSchedGpioDurationSec') && alert.gpioDurationSec !== undefined) $('playlistSchedGpioDurationSec').value = alert.gpioDurationSec;
  
  if ((alert.type === 'weekly' || alert.type === 'prayer_relative') && alert.dayOfWeek >= 0) {
    const mask = alert.dayOfWeek;
    document.querySelectorAll('.playlistSched-weekly-day-cb').forEach(cb => {
      const dayVal = parseInt(cb.value);
      if (mask >= 128) {
        cb.checked = !!((mask & 0x7F) & (1 << dayVal));
      } else {
        cb.checked = (dayVal === mask);
      }
    });
  } else if (alert.type === 'monthly' && $('playlistSchedDay')) {
    $('playlistSchedDay').value = alert.dayOfMonth;
  } else if (alert.type === 'specific' && $('playlistSchedDate')) {
    $('playlistSchedDate').value = alert.specificDate || '';
  } else if (alert.type === 'prayer_relative') {
    if ($('playlistSchedPrayer')) $('playlistSchedPrayer').value = alert.prayerIndex !== undefined ? alert.prayerIndex : 0;
    if ($('playlistSchedOffset')) $('playlistSchedOffset').value = alert.offsetSeconds !== undefined ? Math.round(alert.offsetSeconds / 60) : 0;
  }
  
  if ($('playlistSchedSaveBtn')) $('playlistSchedSaveBtn').innerHTML = '<i class="fas fa-save"></i> تعديل القائمة للجدولة';
  if ($('playlistSchedCancelEditBtn')) $('playlistSchedCancelEditBtn').style.display = 'block';
}

function loadSchedules() {
  apiGet('/api/scheduler/list', []).then((data) => {
    const alerts = Array.isArray(data) ? data : (data.alerts || []);
    appState.alerts = alerts;
    
    const singleAlerts = [];
    const playlistSchedules = [];
    const radioAlerts = [];
    
    alerts.forEach((alert, index) => {
      alert.originalIndex = index;
      if (alert.eidOnly && (alert.eidOnly === '1' || alert.eidOnly === 1 || alert.eidOnly === true || alert.eidOnly === 'true')) {
        return; // Skip Eid-only alerts for the regular scheduler view
      }
      if (alert.file && alert.file.includes(',')) {
        playlistSchedules.push(alert);
      } else if (alert.file && (alert.file.startsWith('http://') || alert.file.startsWith('https://'))) {
        radioAlerts.push(alert);
      } else {
        singleAlerts.push(alert);
      }
    });

    if ($('singleAlertsList')) {
      $('singleAlertsList').innerHTML = singleAlerts.map((a) => {
        let info = `<span class="prayer-source-badge source-local" style="margin-left: 5px;"><i class="fas fa-file-audio"></i> ملف محلي</span><strong>${safeText(a.name || 'بدون اسم')}</strong>`;
        info += `<br><span style="font-size:0.9em;opacity:0.8;">📄 ${safeText(a.file)}</span>`;
        info += `<br><span style="font-size:0.9em;opacity:0.8;">🕒 ${safeText(a.type)}`;
        if (a.type === 'weekly' && a.dayOfWeek !== undefined) info += ` (${formatDays(a.dayOfWeek)})`;
        if (a.type === 'monthly') info += ` (يوم ${a.dayOfMonth})`;
        if (a.type === 'specific') info += ` (${safeText(a.specificDate)})`;
        if (a.type === 'prayer_relative') {
          const prayerNames = ['الفجر', 'الظهر', 'العصر', 'المغرب', 'العشاء'];
          info += ` (صلاة ${prayerNames[a.prayerIndex] || a.prayerIndex}، إزاحة ${Math.round(a.offsetSeconds / 60)} دقيقة`;
          if (a.dayOfWeek !== undefined && a.dayOfWeek >= 0) {
            info += `، أيام: ${formatDays(a.dayOfWeek)}`;
          }
          info += `)`;
        }
        if (a.type !== 'prayer_relative' || a.repeatInterval <= 0) {
          info += ` الساعة ${String(a.hour).padStart(2, '0')}:${String(a.minute).padStart(2, '0')}`;
        }
        info += ` | 🔊 ${a.volume}`;
        if (a.loop && a.loop > 0) info += ` (تكرار ${a.loop} ق)`;
        if (a.repeatInterval && a.repeatInterval > 0) {
          info += ` | 🔁 كل ${a.repeatInterval} دقيقة`;
          if (a.endHour !== undefined && a.endHour >= 0) {
            const eh = String(a.endHour).padStart(2, '0');
            const em = String(a.endMinute).padStart(2, '0');
            info += ` (حتى ${eh}:${em})`;
          }
        }
        const impText = (a.important === false || a.important === 0) ? 'غير مهم' : 'مهم';
        info += ` | ⚠️ ${impText}`;
        if (a.gpioActive) {
          const modeArabic = a.gpioMode === 'flasher' ? 'متقطع فلاشر' : a.gpioMode === 'pulse' ? 'نبضة' : 'مستمر';
          const durArabic = a.gpioDurationMode === 'custom' ? `لوقت ${a.gpioDurationSec}ث` : 'لحين انتهاء الصوت';
          info += ` | 🔌 مخرج ${a.gpioPin} (${modeArabic} - ${durArabic})`;
        }
        if (a.enabled === false) {
          info += ` | <span style="color:#ff6b6b; font-weight:bold;">🚫 موقف</span>`;
        }
        info += '</span>';
        
        const toggleBtnClass = a.enabled !== false ? 'btn-secondary' : 'btn-play';
        const toggleBtnText = a.enabled !== false ? '<i class="fas fa-pause"></i> إيقاف' : '<i class="fas fa-play"></i> تشغيل';
        const itemOpacity = a.enabled !== false ? '' : 'opacity: 0.6;';
        
        return `<li class="file-item" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:10px; border-right: 4px solid #9b59b6; padding-right: 10px; ${itemOpacity}">
          <span>${info}</span>
          <div style="display:flex; gap:8px;">
            <button class="btn ${toggleBtnClass}" onclick="toggleSchedule(${a.originalIndex}, ${a.enabled === false})" style="padding:4px 8px; font-size:12px; margin:0;">${toggleBtnText}</button>
            <button class="btn btn-secondary" onclick="editSingleAlert(${a.originalIndex})" style="padding:4px 8px; font-size:12px; margin:0;"><i class="fas fa-edit"></i> تعديل</button>
            <button class="btn btn-danger" onclick="deleteSchedule(${a.originalIndex})" style="padding:4px 8px; font-size:12px; margin:0;"><i class="fas fa-trash"></i> حذف</button>
          </div>
        </li>`;
      }).join('');
    }

    if ($('radioAlertsList')) {
      $('radioAlertsList').innerHTML = radioAlerts.map((a) => {
        let info = `<span class="prayer-source-badge source-internet" style="margin-left: 5px;"><i class="fas fa-broadcast-tower"></i> بث راديو</span><strong>${safeText(a.name || 'بدون اسم')}</strong>`;
        info += `<br><span style="font-size:0.9em;opacity:0.8;">📻 ${safeText(a.file)}</span>`;
        info += `<br><span style="font-size:0.9em;opacity:0.8;">🕒 ${safeText(a.type)}`;
        if (a.type === 'weekly' && a.dayOfWeek !== undefined) info += ` (${formatDays(a.dayOfWeek)})`;
        if (a.type === 'monthly') info += ` (يوم ${a.dayOfMonth})`;
        if (a.type === 'specific') info += ` (${safeText(a.specificDate)})`;
        if (a.type === 'prayer_relative') {
          const prayerNames = ['الفجر', 'الظهر', 'العصر', 'المغرب', 'العشاء'];
          info += ` (صلاة ${prayerNames[a.prayerIndex] || a.prayerIndex}، إزاحة ${Math.round(a.offsetSeconds / 60)} دقيقة`;
          if (a.dayOfWeek !== undefined && a.dayOfWeek >= 0) {
            info += `، أيام: ${formatDays(a.dayOfWeek)}`;
          }
          if (a.skipAdhan) info += `، 🔕 تخطي الأذان`;
          if (a.skipIqama) info += `، 🔕 تخطي الإقامة`;
          info += `)`;
        }
        if (a.type !== 'prayer_relative' || a.repeatInterval <= 0) {
          info += ` الساعة ${String(a.hour).padStart(2, '0')}:${String(a.minute).padStart(2, '0')}`;
        }
        info += ` | 🔊 ${a.volume}`;
        if (a.loop && a.loop > 0) info += ` (مدة التشغيل ${a.loop} ق)`;
        if (a.repeatInterval && a.repeatInterval > 0) {
          info += ` | 🔁 كل ${a.repeatInterval} دقيقة`;
          if (a.endHour !== undefined && a.endHour >= 0) {
            const eh = String(a.endHour).padStart(2, '0');
            const em = String(a.endMinute).padStart(2, '0');
            info += ` (حتى ${eh}:${em})`;
          }
        }
        const impText = (a.important === false || a.important === 0) ? 'غير مهم' : 'مهم';
        info += ` | ⚠️ ${impText}`;
        if (a.gpioActive) {
          const modeArabic = a.gpioMode === 'flasher' ? 'متقطع فلاشر' : a.gpioMode === 'pulse' ? 'نبضة' : 'مستمر';
          const durArabic = a.gpioDurationMode === 'custom' ? `لوقت ${a.gpioDurationSec}ث` : 'لحين انتهاء الصوت';
          info += ` | 🔌 مخرج ${a.gpioPin} (${modeArabic} - ${durArabic})`;
        }
        if (a.enabled === false) {
          info += ` | <span style="color:#ff6b6b; font-weight:bold;">🚫 موقف</span>`;
        }
        info += '</span>';
        
        const toggleBtnClass = a.enabled !== false ? 'btn-secondary' : 'btn-play';
        const toggleBtnText = a.enabled !== false ? '<i class="fas fa-pause"></i> إيقاف' : '<i class="fas fa-play"></i> تشغيل';
        const itemOpacity = a.enabled !== false ? '' : 'opacity: 0.6;';
        
        return `<li class="file-item" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:10px; border-right: 4px solid #00ffcc; padding-right: 10px; ${itemOpacity}">
          <span>${info}</span>
          <div style="display:flex; gap:8px;">
            <button class="btn ${toggleBtnClass}" onclick="toggleSchedule(${a.originalIndex}, ${a.enabled === false})" style="padding:4px 8px; font-size:12px; margin:0;">${toggleBtnText}</button>
            <button class="btn btn-secondary" onclick="editSingleAlert(${a.originalIndex})" style="padding:4px 8px; font-size:12px; margin:0;"><i class="fas fa-edit"></i> تعديل</button>
            <button class="btn btn-danger" onclick="deleteSchedule(${a.originalIndex})" style="padding:4px 8px; font-size:12px; margin:0;"><i class="fas fa-trash"></i> حذف</button>
          </div>
        </li>`;
      }).join('');
    }

    if ($('playlistSchedulesList')) {
      $('playlistSchedulesList').innerHTML = playlistSchedules.map((a) => {
        let info = `<strong>${safeText(a.name || 'بدون اسم')}</strong>`;
        const count = a.file ? a.file.split(',').length : 0;
        info += `<br><span style="font-size:0.9em;opacity:0.8;">🎵 قائمة تشغيل (${count} ملفات)</span>`;
        info += `<br><span style="font-size:0.9em;opacity:0.8;">🕒 ${safeText(a.type)}`;
        if (a.type === 'weekly' && a.dayOfWeek !== undefined) info += ` (${formatDays(a.dayOfWeek)})`;
        if (a.type === 'monthly') info += ` (يوم ${a.dayOfMonth})`;
        if (a.type === 'specific') info += ` (${safeText(a.specificDate)})`;
        if (a.type === 'prayer_relative') {
          const prayerNames = ['الفجر', 'الظهر', 'العصر', 'المغرب', 'العشاء'];
          info += ` (صلاة ${prayerNames[a.prayerIndex] || a.prayerIndex}، إزاحة ${Math.round(a.offsetSeconds / 60)} دقيقة`;
          if (a.dayOfWeek !== undefined && a.dayOfWeek >= 0) {
            info += `، أيام: ${formatDays(a.dayOfWeek)}`;
          }
          info += `)`;
        }
        if (a.type !== 'prayer_relative' || a.repeatInterval <= 0) {
          info += ` الساعة ${String(a.hour).padStart(2, '0')}:${String(a.minute).padStart(2, '0')}`;
        }
        info += ` | 🔊 ${a.volume}`;
        if (a.loop && a.loop > 0) info += ` (تكرار ${a.loop} ق)`;
        if (a.repeatInterval && a.repeatInterval > 0) {
          info += ` | 🔁 كل ${a.repeatInterval} دقيقة`;
          if (a.endHour !== undefined && a.endHour >= 0) {
            const eh = String(a.endHour).padStart(2, '0');
            const em = String(a.endMinute).padStart(2, '0');
            info += ` (حتى ${eh}:${em})`;
          }
        }
        const impText = (a.important === false || a.important === 0) ? 'غير مهم' : 'مهم';
        info += ` | ⚠️ ${impText}`;
        if (a.gpioActive) {
          const modeArabic = a.gpioMode === 'flasher' ? 'متقطع فلاشر' : a.gpioMode === 'pulse' ? 'نبضة' : 'مستمر';
          const durArabic = a.gpioDurationMode === 'custom' ? `لوقت ${a.gpioDurationSec}ث` : 'لحين انتهاء الصوت';
          info += ` | 🔌 مخرج ${a.gpioPin} (${modeArabic} - ${durArabic})`;
        }
        if (a.enabled === false) {
          info += ` | <span style="color:#ff6b6b; font-weight:bold;">🚫 موقف</span>`;
        }
        info += '</span>';
        
        const toggleBtnClass = a.enabled !== false ? 'btn-secondary' : 'btn-play';
        const toggleBtnText = a.enabled !== false ? '<i class="fas fa-pause"></i> إيقاف' : '<i class="fas fa-play"></i> تشغيل';
        const itemOpacity = a.enabled !== false ? '' : 'opacity: 0.6;';
        
        return `<li class="file-item" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:10px; ${itemOpacity}">
          <span>${info}</span>
          <div style="display:flex; gap:8px;">
            <button class="btn ${toggleBtnClass}" onclick="toggleSchedule(${a.originalIndex}, ${a.enabled === false})" style="padding:4px 8px; font-size:12px; margin:0;">${toggleBtnText}</button>
            <button class="btn btn-secondary" onclick="editPlaylistSched(${a.originalIndex})" style="padding:4px 8px; font-size:12px; margin:0;"><i class="fas fa-edit"></i> تعديل</button>
            <button class="btn btn-danger" onclick="deleteSchedule(${a.originalIndex})" style="padding:4px 8px; font-size:12px; margin:0;"><i class="fas fa-trash"></i> حذف</button>
          </div>
        </li>`;
      }).join('');
    }
  }).catch((err) => console.error('Failed to load schedules:', err));
}

function deleteSchedule(index) {
  if (!confirm('هل أنت متأكد من حذف هذا التنبيه؟')) return;
  apiPost(`/api/scheduler/delete?index=${index}`, { index }).then(() => {
    cancelEditSingleAlert();
    cancelEditPlaylistSched();
    loadSchedules();
  }).catch((err) => toast(`فشل الحذف: ${err.message}`));
}

function toggleSchedule(index, enable, isEid = false) {
  apiPost('/api/scheduler/toggle', { index, enabled: enable ? 1 : 0 }).then(() => {
    toast(enable ? 'تم تشغيل التنبيه' : 'تم إيقاف التنبيه');
    if (isEid) {
      loadEidSchedules();
    } else {
      loadSchedules();
    }
  }).catch((err) => toast(`فشل تعديل حالة التنبيه: ${err.message}`));
}

function populateGpioPins() {
  // Excluded: SD SPI (10-CS,11-MOSI,12-SCK,13-MISO) and I2S (16-BCLK,17-LRCK,18-DOUT)
  const allPins = [3, 4, 5, 6, 7, 8, 9, 14, 15, 19, 47];
  const bestInputs = [8, 9, 14, 47];
  const bestOutputs = [4, 5, 6, 7, 15];

  // Calculate which pins are in use
  const usedInputPins = new Set();
  const usedOutputPins = new Set();

  if (appState.gpioMappings && appState.gpioMappings.inputs) {
    appState.gpioMappings.inputs.forEach(inp => {
      if (editingInputPin === null || Number(inp.pin) !== Number(editingInputPin)) {
        usedInputPins.add(Number(inp.pin));
      }
      if (inp.outputPin && Number(inp.outputPin) !== 0) {
        if (editingInputPin === null || Number(inp.pin) !== Number(editingInputPin)) {
          usedOutputPins.add(Number(inp.outputPin));
        }
      }
    });
  }

  if (appState.gpioMappings && appState.gpioMappings.outputs) {
    appState.gpioMappings.outputs.forEach(out => {
      usedOutputPins.add(Number(out.pin));
    });
  }

  if (appState.gpioSchedules) {
    appState.gpioSchedules.forEach((s, idx) => {
      if (editingGpioSchedIndex === -1 || idx !== editingGpioSchedIndex) {
        usedOutputPins.add(Number(s.pin));
      }
    });
  }

  // Build options for input pins - only bestInputs pins shown
  function buildInputOptions(currentSelectedValue) {
    const available = allPins.filter(p => bestInputs.includes(p) && (!usedInputPins.has(p) || Number(p) === Number(currentSelectedValue)));
    let html = '';
    available.forEach(p => {
      const selected = (Number(p) === Number(currentSelectedValue)) ? ' selected' : '';
      html += `<option value="${p}"${selected}>${p} (أفضل للمدخلات)</option>`;
    });
    if (!html) html = '<option value="">لا توجد دبابيس متاحة</option>';
    return html;
  }

  // Build options for output pins - only bestOutputs pins shown
  function buildOutputOptions(currentSelectedValue, includeNoneOption = false) {
    const available = allPins.filter(p => bestOutputs.includes(p) && (!usedOutputPins.has(p) || Number(p) === Number(currentSelectedValue)));
    let html = includeNoneOption ? '<option value="0">لا يوجد</option>' : '';
    available.forEach(p => {
      const selected = (Number(p) === Number(currentSelectedValue)) ? ' selected' : '';
      html += `<option value="${p}"${selected}>${p} (أفضل للمخرجات)</option>`;
    });
    if (!html && !includeNoneOption) html = '<option value="">لا توجد دبابيس متاحة</option>';
    return html;
  }

  if ($('gpioInputPin')) {
    const currVal = $('gpioInputPin').value;
    $('gpioInputPin').innerHTML = buildInputOptions(currVal);
  }

  if ($('gpioInputOutputPin')) {
    const currVal = $('gpioInputOutputPin').value;
    $('gpioInputOutputPin').innerHTML = buildOutputOptions(currVal, true);
  }

  if ($('outputPin')) {
    const currVal = $('outputPin').value;
    $('outputPin').innerHTML = buildOutputOptions(currVal, false);
  }

  if ($('gpioSchedPin')) {
    const currVal = $('gpioSchedPin').value;
    $('gpioSchedPin').innerHTML = buildOutputOptions(currVal, false);
  }
}

function saveOutputMapping() {
  const pinVal = $('outputPin')?.value;
  if (!pinVal || pinVal === '') return toast('اختر دبوساً صالحاً');
  apiPost('/api/gpio/output', {
    pin: pinVal,
    alert: $('outputAlert')?.value || '',
    duration: $('outputDuration')?.value || 5
  }).then(() => {
    toast('تم حفظ المخرج');
    loadGpioMappings();
  }).catch((err) => toast(`فشل الحفظ: ${err.message}`));
}

function saveSmartInput() {
  const name = $('gpioInputName')?.value || '';
  const pin = $('gpioInputPin')?.value || '0';
  const file = $('gpioInputFile')?.value || '';
  const playDuration = $('gpioInputPlayDuration')?.value || 0;
  const repeatCount = $('gpioInputRepeatCount')?.value || 0;
  const outputPin = $('gpioInputOutputPin')?.value || '0';
  const volume = parseInt($('gpioInputVolume')?.value || '20');
  
  const mode = $('gpioInputOutputMode')?.value || '0';
  let outputDuration = 0;
  if (mode === 'pulse') {
    outputDuration = parseInt($('gpioInputOutputDuration')?.value || '5');
  } else if (mode === '-1') {
    outputDuration = -1;
  }
  
  let deletePromise = Promise.resolve();
  if (editingInputPin !== null && Number(editingInputPin) !== Number(pin)) {
    deletePromise = apiPost(`/api/gpio/input/delete?pin=${editingInputPin}`, { pin: editingInputPin });
  }

  deletePromise.then(() => {
    return apiPost('/api/gpio/input', {
      name,
      pin,
      file,
      playDuration,
      repeatCount,
      outputPin,
      outputDuration,
      volume
    });
  }).then(() => {
    toast('تم حفظ المدخل الذكي');
    cancelEditGpioInput();
    loadGpioMappings();
  }).catch((err) => toast(`فشل الحفظ: ${err.message}`));
}

function editGpioInput(pin) {
  const mapping = appState.gpioMappings?.inputs?.find(inp => inp.pin === pin);
  if (!mapping) return;
  
  editingInputPin = mapping.pin;
  showSubTab('tab-gpio', 'sub-gpio-inputs');
  editingInputOutputPin = mapping.outputPin !== undefined ? mapping.outputPin : '0';
  
  populateGpioPins();
  
  if ($('gpioInputName')) $('gpioInputName').value = mapping.name || '';
  if ($('gpioInputPin')) $('gpioInputPin').value = mapping.pin;
  if ($('gpioInputFile')) $('gpioInputFile').value = mapping.file || '';
  if ($('gpioInputPlayDuration')) $('gpioInputPlayDuration').value = mapping.playDuration !== undefined ? mapping.playDuration : 0;
  if ($('gpioInputRepeatCount')) $('gpioInputRepeatCount').value = mapping.repeatCount !== undefined ? mapping.repeatCount : 0;
  if ($('gpioInputOutputPin')) $('gpioInputOutputPin').value = mapping.outputPin !== undefined ? mapping.outputPin : '0';
  if ($('gpioInputVolume')) {
    const vol = mapping.volume !== undefined ? mapping.volume : 20;
    $('gpioInputVolume').value = vol;
    if ($('gpioInputVolVal')) $('gpioInputVolVal').textContent = vol;
  }
  
  if ($('gpioInputOutputMode')) {
    const dur = mapping.outputDuration !== undefined ? mapping.outputDuration : 0;
    if (dur > 0) {
      $('gpioInputOutputMode').value = 'pulse';
      if ($('gpioInputOutputDuration')) $('gpioInputOutputDuration').value = dur;
    } else if (dur === -1) {
      $('gpioInputOutputMode').value = '-1';
    } else {
      $('gpioInputOutputMode').value = '0';
    }
    toggleGpioOutputModeFields();
  }
  
  if ($('gpioInputSaveBtn')) $('gpioInputSaveBtn').innerHTML = '<i class="fas fa-save"></i> تعديل المدخل الذكي';
  if ($('gpioInputCancelBtn')) $('gpioInputCancelBtn').style.display = 'inline-block';
}

function cancelEditGpioInput() {
  editingInputPin = null;
  editingInputOutputPin = null;
  if ($('gpioInputName')) $('gpioInputName').value = '';
  if ($('gpioInputFile')) $('gpioInputFile').selectedIndex = 0;
  if ($('gpioInputPlayDuration')) $('gpioInputPlayDuration').value = 0;
  if ($('gpioInputRepeatCount')) $('gpioInputRepeatCount').value = 0;
  if ($('gpioInputOutputPin')) $('gpioInputOutputPin').value = '0';
  if ($('gpioInputOutputMode')) {
    $('gpioInputOutputMode').value = '0';
    toggleGpioOutputModeFields();
  }
  if ($('gpioInputVolume')) {
    $('gpioInputVolume').value = 20;
    if ($('gpioInputVolVal')) $('gpioInputVolVal').textContent = 20;
  }
  if ($('gpioInputSaveBtn')) $('gpioInputSaveBtn').innerHTML = '<i class="fas fa-save"></i> حفظ المدخل الذكي';
  if ($('gpioInputCancelBtn')) $('gpioInputCancelBtn').style.display = 'none';
  populateGpioPins();
}

function deleteGpioInput(pin) {
  if (!confirm('هل أنت متأكد من حذف هذا المدخل؟')) return;
  apiPost(`/api/gpio/input/delete?pin=${pin}`, { pin }).then(() => {
    cancelEditGpioInput();
    loadGpioMappings();
  }).catch((err) => toast(`فشل الحذف: ${err.message}`));
}

function toggleGpioOutputModeFields() {
  const mode = $('gpioInputOutputMode')?.value;
  const container = $('gpioInputPulseContainer');
  if (container) {
    container.style.display = mode === 'pulse' ? 'block' : 'none';
  }
}

function loadGpioMappings() {
  apiGet('/api/gpio/mappings', {}).then((data) => {
    appState.gpioMappings = data;
    const inputs = data.inputs || [];
    if (!$('gpioInputsList')) return;
    if (inputs.length === 0) {
      $('gpioInputsList').innerHTML = '<p style="text-align:center; opacity:0.7;">لا توجد مدخلات مضافة بعد</p>';
      populateGpioPins();
      return;
    }
    $('gpioInputsList').innerHTML = inputs.map((inp) => {
      let info = `<strong>دبوس ${inp.pin}</strong>`;
      if (inp.name) info += ` (${safeText(inp.name)})`;
      if (inp.file) info += ` 🎵 ${safeText(inp.file)}`;
      if (inp.playDuration > 0 || inp.repeatCount > 0) info += ` (مدة ${inp.playDuration}ث، تكرار ${inp.repeatCount})`;
      if (inp.outputPin && Number(inp.outputPin) !== 0) {
        info += ` 🔌 مخرج ${inp.outputPin}`;
        if (inp.outputDuration > 0) info += ` (نبضة ${inp.outputDuration}ث)`;
        else if (inp.outputDuration === -1) info += ` (تبديل)`;
        else info += ` (مستمر)`;
      }
      const pinVal = Number(inp.pin);
      return `<li class="file-item" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:10px;">
        <span>${info}</span>
        <div style="display:flex; gap:8px;">
          <button class="btn btn-secondary" onclick="editGpioInput(${pinVal})" style="padding:4px 8px; font-size:12px;"><i class="fas fa-edit"></i> تعديل</button>
          <button class="btn btn-danger" onclick="deleteGpioInput(${pinVal})" style="padding:4px 8px; font-size:12px;"><i class="fas fa-trash"></i> حذف</button>
        </div>
      </li>`;
    }).join('');
    populateGpioPins();
  }).catch((err) => console.error('Failed to load GPIO mappings:', err));
}

function saveGpioSched() {
  const name = $('gpioSchedName')?.value || '';
  const pin = $('gpioSchedPin')?.value || '';
  if (!pin || pin === '') return toast('يجب اختيار دبوس (Pin) صالح');
  
  const [startHour = '0', startMin = '0'] = ($('gpioSchedStart')?.value || '00:00').split(':');
  const [endHour = '0', endMin = '0'] = ($('gpioSchedEnd')?.value || '00:00').split(':');
  const type = $('gpioSchedType')?.value || 'daily';
  
  let dayOfWeek = -1, dayOfMonth = -1;
  if (type === 'weekly') dayOfWeek = getSelectedDaysBitmask('gpioSched');
  if (type === 'monthly') dayOfMonth = $('gpioSchedDay')?.value || '-1';
  
  const alertFile = $('gpioSchedAlertFile')?.value || '';
  const audioMode = $('gpioSchedAudioMode')?.value || 'original';
  const repeatCount = (audioMode === 'repeat' && alertFile) ? parseInt($('gpioSchedRepeatCount')?.value || '1') : 0;
  const volume = parseInt($('gpioSchedVolume')?.value || '20');
  
  const data = {
    name,
    pin,
    state: $('gpioSchedState')?.value || '1',
    type,
    startHour,
    startMin,
    endHour,
    endMin,
    dayOfWeek,
    dayOfMonth,
    specificDate: $('gpioSchedDate')?.value || '',
    alertFile,
    repeatCount,
    volume,
    index: editingGpioSchedIndex
  };

  apiPost('/api/gpio/schedule/add', data).then(() => {
    toast(editingGpioSchedIndex >= 0 ? 'تم تعديل جدولة المخرج بنجاح' : 'تم إضافة جدولة المخرج بنجاح');
    cancelEditGpioSched();
    loadGpioSchedules();
  }).catch((err) => toast(`فشل الحفظ: ${err.message}`));
}

function cancelEditGpioSched() {
  editingGpioSchedIndex = -1;
  if ($('gpioSchedName')) $('gpioSchedName').value = '';
  if ($('gpioSchedPin')) $('gpioSchedPin').selectedIndex = 0;
  if ($('gpioSchedState')) $('gpioSchedState').value = '1';
  if ($('gpioSchedType')) {
    $('gpioSchedType').value = 'daily';
    toggleScheduleFields('gpioSched');
  }
  if ($('gpioSchedStart')) $('gpioSchedStart').value = '00:00';
  if ($('gpioSchedEnd')) $('gpioSchedEnd').value = '00:00';
  if ($('gpioSchedAlertFile')) {
    $('gpioSchedAlertFile').value = '';
    toggleGpioFileSelected('gpioSched');
  }
  if ($('gpioSchedAudioMode')) {
    $('gpioSchedAudioMode').value = 'original';
    toggleGpioAudioModeFields('gpioSched');
  }
  if ($('gpioSchedRepeatCount')) $('gpioSchedRepeatCount').value = 1;
  if ($('gpioSchedSaveBtn')) $('gpioSchedSaveBtn').innerHTML = '<i class="fas fa-save"></i> حفظ جدولة GPIO';
  if ($('gpioSchedCancelEditBtn')) $('gpioSchedCancelEditBtn').style.display = 'none';
}

function editGpioSched(index) {
  const sched = appState.gpioSchedules[index];
  if (!sched) return;
  
  editingGpioSchedIndex = index;
  showSubTab('tab-gpio', 'sub-gpio-schedules');
  
  if ($('gpioSchedName')) $('gpioSchedName').value = sched.name || '';
  if ($('gpioSchedPin')) $('gpioSchedPin').value = sched.pin;
  if ($('gpioSchedState')) $('gpioSchedState').value = sched.state ? '1' : '0';
  if ($('gpioSchedType')) {
    $('gpioSchedType').value = sched.type || 'daily';
    toggleScheduleFields('gpioSched');
  }
  
  if ($('gpioSchedStart')) {
    $('gpioSchedStart').value = `${String(sched.startHour).padStart(2, '0')}:${String(sched.startMin).padStart(2, '0')}`;
  }
  if ($('gpioSchedEnd')) {
    $('gpioSchedEnd').value = `${String(sched.endHour).padStart(2, '0')}:${String(sched.endMin).padStart(2, '0')}`;
  }
  if ($('gpioSchedAlertFile')) {
    $('gpioSchedAlertFile').value = sched.alertFile || '';
    toggleGpioFileSelected('gpioSched');
  }
  if ($('gpioSchedAudioMode')) {
    const isRepeat = (sched.repeatCount && sched.repeatCount > 0);
    $('gpioSchedAudioMode').value = isRepeat ? 'repeat' : 'original';
    toggleGpioAudioModeFields('gpioSched');
  }
  if ($('gpioSchedRepeatCount')) {
    $('gpioSchedRepeatCount').value = (sched.repeatCount && sched.repeatCount > 0) ? sched.repeatCount : 1;
  }
  if ($('gpioSchedVolume')) {
    const vol = sched.volume !== undefined ? sched.volume : 20;
    $('gpioSchedVolume').value = vol;
    if ($('gpioSchedVolVal')) $('gpioSchedVolVal').textContent = vol;
  }
  
  if (sched.type === 'weekly' && sched.dayOfWeek >= 0) {
    const mask = sched.dayOfWeek;
    document.querySelectorAll('.gpioSched-weekly-day-cb').forEach(cb => {
      const dayVal = parseInt(cb.value);
      if (mask >= 128) {
        cb.checked = !!((mask & 0x7F) & (1 << dayVal));
      } else {
        cb.checked = (dayVal === mask);
      }
    });
  } else if (sched.type === 'monthly' && $('gpioSchedDay')) {
    $('gpioSchedDay').value = sched.dayOfMonth;
  } else if ((sched.type === 'specific' || sched.type === 'yearly') && $('gpioSchedDate')) {
    $('gpioSchedDate').value = sched.specificDate || '';
  }
  
  if ($('gpioSchedSaveBtn')) $('gpioSchedSaveBtn').innerHTML = '<i class="fas fa-save"></i> تعديل جدولة GPIO';
  if ($('gpioSchedCancelEditBtn')) $('gpioSchedCancelEditBtn').style.display = 'block';
}

function loadGpioSchedules() {
  apiGet('/api/gpio/schedule/list', []).then((data) => {
    const schedules = Array.isArray(data) ? data : [];
    appState.gpioSchedules = schedules;
    if (!$('gpioSchedulesList')) return;
    $('gpioSchedulesList').innerHTML = schedules.map((s, i) => {
      let info = `<strong>${safeText(s.name || 'جدولة مخرج')}</strong> (دبوس ${s.pin})`;
      info += `<br><span style="font-size:0.9em;opacity:0.8;">⚡ الحالة: ${s.state ? 'تشغيل' : 'إيقاف'} | 🕒 ${safeText(s.type)}`;
      if (s.type === 'weekly' && s.dayOfWeek !== undefined) info += ` (${formatDays(s.dayOfWeek)})`;
      if (s.type === 'monthly') info += ` (يوم ${s.dayOfMonth})`;
      if (s.type === 'specific') info += ` (${safeText(s.specificDate)})`;
      if (s.type === 'yearly') info += ` (سنوياً في ${safeText(s.specificDate ? s.specificDate.substring(5) : '')})`;
      info += ` | الوقت: ${String(s.startHour).padStart(2, '0')}:${String(s.startMin).padStart(2, '0')} إلى ${String(s.endHour).padStart(2, '0')}:${String(s.endMin).padStart(2, '0')}`;
      if (s.alertFile) {
        info += ` | 🔊 صوت: ${safeText(s.alertFile)}`;
        if (s.repeatCount && s.repeatCount > 0) {
          info += ` (تكرار: ${s.repeatCount} مرات)`;
        } else {
          info += ` (المدة الأصلية)`;
        }
      }
      info += '</span>';
      
      return `<li class="file-item" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:10px;">
        <span>${info}</span>
        <div style="display:flex; gap:8px;">
          <button class="btn btn-secondary" onclick="editGpioSched(${i})" style="padding:4px 8px; font-size:12px;"><i class="fas fa-edit"></i> تعديل</button>
          <button class="btn btn-danger" onclick="deleteGpioSched(${i})" style="padding:4px 8px; font-size:12px;"><i class="fas fa-trash"></i> حذف</button>
        </div>
      </li>`;
    }).join('');
    populateGpioPins();
  }).catch((err) => console.error('Failed to load GPIO schedules:', err));
}

function deleteGpioSched(index) {
  if (!confirm('هل أنت متأكد من حذف هذه الجدولة؟')) return;
  apiPost(`/api/gpio/schedule/delete?index=${index}`, { index }).then(() => {
    cancelEditGpioSched();
    loadGpioSchedules();
  }).catch((err) => toast(`فشل الحذف: ${err.message}`));
}

function toggleEidMode() {
  const manualEn = $('eidModeToggle')?.checked ? '1' : '0';
  const autoEn = $('eidAutoToggle') ? ($('eidAutoToggle').checked ? '1' : '0') : '1';
  apiPost('/api/eid/mode', { enabled: manualEn, autoEnabled: autoEn })
    .then(() => {
      loadEidModeStatus();
      toast('تم تحديث إعدادات وضع العيد');
    }).catch((err) => toast(`فشل التحديث: ${err.message}`));
}

function updateEidModeBanner(enabled) {
  if ($('eidModeBanner')) $('eidModeBanner').style.display = enabled ? 'flex' : 'none';
}

function loadEidModeStatus() {
  apiGet('/api/eid/status', {}).then((data) => {
    const effectiveEnabled = !!data.enabled;
    const manualEnabled = data.manualEnabled !== undefined ? !!data.manualEnabled : effectiveEnabled;
    const autoEnabled = data.autoEnabled !== undefined ? !!data.autoEnabled : true;
    const autoDayActive = !!data.autoDayActive;
    const autoReason = data.autoReason || '';

    if ($('eidModeToggle')) $('eidModeToggle').checked = manualEnabled;
    if ($('eidAutoToggle')) $('eidAutoToggle').checked = autoEnabled;
    if ($('eidAutoStatusBadge')) {
      if (manualEnabled) {
        $('eidAutoStatusBadge').innerHTML = '🟢 <strong>وضع العيد مفعل حالياً (تفعيل يدوي)</strong>';
        $('eidAutoStatusBadge').style.color = '#2ecc71';
      } else if (autoEnabled && autoDayActive) {
        $('eidAutoStatusBadge').innerHTML = `🟢 <strong>وضع العيد مفعل أوتوماتيكياً اليوم: ${safeText(autoReason)}</strong>`;
        $('eidAutoStatusBadge').style.color = '#2ecc71';
      } else if (autoEnabled) {
        $('eidAutoStatusBadge').innerHTML = '🕒 <strong>التفعيل الأوتوماتيكي جاهز:</strong> سيعمل تلقائياً عند دخول عيد الفطر (1–3 شوال) أو عيد الأضحى (9–13 ذو الحجة)';
        $('eidAutoStatusBadge').style.color = '#f1c40f';
      } else {
        $('eidAutoStatusBadge').innerHTML = '⚪ وضع العيد متوقف (التفعيل اليدوي والأوتوماتيكي غير مفعلين)';
        $('eidAutoStatusBadge').style.color = 'rgba(255,255,255,0.6)';
      }
    }
    if ($('eidTakbeerFile') && data.takbeerFile) $('eidTakbeerFile').value = data.takbeerFile;
    if ($('eidTakbeerVolume') && data.takbeerVolume !== undefined) {
      $('eidTakbeerVolume').value = data.takbeerVolume;
      if ($('eidTakbeerVolumeValue')) $('eidTakbeerVolumeValue').textContent = data.takbeerVolume;
    }
    updateEidModeBanner(effectiveEnabled);
  });
}

function triggerTakbeer() {
  apiPost('/api/audio/play', {
    file: $('eidTakbeerFile')?.value || '',
    priority: 1,
    volume: $('eidTakbeerVolume')?.value || 15
  })
    .catch((err) => toast(`فشل التشغيل: ${err.message}`));
}

function saveEidFile() {
  apiPost('/api/eid/file', {
    file: $('eidTakbeerFile')?.value || '',
    volume: $('eidTakbeerVolume')?.value || 15
  })
    .then(() => toast('تم حفظ ملف التكبيرات')).catch((err) => toast(`فشل الحفظ: ${err.message}`));
}

function playSingleFile() {
  const file = $('playlistFileSelect')?.value || '';
  if (!file) return toast('اختر ملفاً أولاً');
  const volume = $('playlistVolume')?.value || 15;
  apiPost('/api/audio/play', { file: file, priority: 0, volume: volume })
    .then(() => {
      if ($('playerControlsContainer')) $('playerControlsContainer').style.display = 'block';
      if ($('quickPlayerPlaceholder')) $('quickPlayerPlaceholder').style.display = 'none';
      if ($('dashPlayerControlsContainer')) $('dashPlayerControlsContainer').style.display = 'block';
    })
    .catch((err) => toast(`فشل التشغيل: ${err.message}`));
}

function addToPlaylist() {
  const file = $('playlistFileSelect')?.value || '';
  if (!file) return;
  appState.playlist.push(file);
  renderPlaylist();
}

function renderPlaylist() {
  if (!$('playlist')) return;
  $('playlist').innerHTML = appState.playlist.map((file, i) =>
    `<div class="file-item"><span>${safeText(file)}</span><button class="btn btn-danger" onclick="removeFromPlaylist(${i})">حذف</button></div>`
  ).join('');
}

function removeFromPlaylist(index) {
  appState.playlist.splice(index, 1);
  renderPlaylist();
}

function playPlaylist() {
  apiPost('/api/audio/playlist', {
    files: appState.playlist.join(','),
    volume: $('playlistVolume')?.value || 15,
    respectAdhan: $('playlistAdhanRespect')?.checked ? '1' : '0'
  }).then(() => {
    if ($('playerControlsContainer')) $('playerControlsContainer').style.display = 'block';
    if ($('quickPlayerPlaceholder')) $('quickPlayerPlaceholder').style.display = 'none';
    if ($('dashPlayerControlsContainer')) $('dashPlayerControlsContainer').style.display = 'block';
  }).catch((err) => toast(`فشل التشغيل: ${err.message}`));
}

function stopPlaylist() {
  stopAudio();
}

function clearPlaylist() {
  appState.playlist = [];
  renderPlaylist();
}

function saveMaghribOffset() {
  saveMaghribGeneralSettings();
}

function saveMaghribGeneralSettings() {
  const offset = parseInt($('maghribOffset')?.value || '1', 10);
  const skipAdhan = $('maghribSkipAdhan')?.checked || false;
  const skipIqama = $('maghribSkipIqama')?.checked || false;
  
  const payload = {
    offset: offset,
    skipAdhan: skipAdhan,
    skipIqama: skipIqama
  };
  apiPost('/api/maghrib/alert/save', { json: JSON.stringify(payload) })
    .then(() => toast('تم حفظ إعدادات المغرب العامة بنجاح'))
    .catch((err) => toast(`فشل الحفظ: ${err.message}`));
}

function getAvailableRadiosList() {
  return (Array.isArray(allRadiosList) && allRadiosList.length > 0)
    ? allRadiosList
    : (defaultOfflineRadios[radioLanguage] || defaultOfflineRadios.ar || []);
}

function toggleMaghribType(index) {
  const isRadio = $(`maghribType_${index}`)?.value === '1';
  const fileContainer = $(`maghribFileRow_${index}`);
  const radioContainer = $(`maghribRadioRow_${index}`);
  if (fileContainer) fileContainer.style.display = isRadio ? 'none' : 'block';
  if (radioContainer) radioContainer.style.display = isRadio ? 'block' : 'none';
}

function testMaghribItem(index) {
  const isRadio = $(`maghribType_${index}`)?.value === '1';
  const file = isRadio ? $(`maghribRadio_${index}`)?.value : $(`maghribFile_${index}`)?.value;
  if (!file) {
    toast(isRadio ? 'يرجى اختيار إذاعة أولاً' : 'يرجى اختيار ملف صوتي أولاً');
    return;
  }
  const volume = $(`maghribVolume_${index}`)?.value || 15;
  const loop = $(`maghribLoop_${index}`)?.value || 0;
  const name = isRadio ? ($(`maghribRadio_${index}`)?.options?.[$(`maghribRadio_${index}`).selectedIndex]?.textContent || 'إذاعة المغرب') : file;
  
  apiPost('/api/audio/play', { file: file, name: name, volume: volume, priority: 1, loopDuration: parseInt(loop) * 60 })
    .then(() => toast(`جاري تجربة: ${name}`))
    .catch((err) => toast(`فشل التجربة: ${err.message}`));
}

function loadMaghribAlerts() {
  apiGet('/api/maghrib/alerts', {}).then((data) => {
    const isRootObj = data && typeof data === 'object' && !Array.isArray(data);
    const alerts = isRootObj ? (data.alerts || []) : (Array.isArray(data) ? data : []);
    
    if ($('maghribOffset') && isRootObj && data.offset !== undefined) {
      $('maghribOffset').value = data.offset;
    }
    if ($('maghribSkipAdhan') && isRootObj) {
      $('maghribSkipAdhan').checked = !!data.skipAdhan;
    }
    if ($('maghribSkipIqama') && isRootObj) {
      $('maghribSkipIqama').checked = !!data.skipIqama;
    }

    const radios = getAvailableRadiosList();
    const audioFiles = (appState.files || []).filter(f => !f.isDirectory && !String(f.name || '').startsWith('prayer_csv/') && /\.(mp3|wav)$/i.test(f.name || ''));

    if (!$('maghribAlerts')) return;

    $('maghribAlerts').innerHTML = dayNames.map((d, i) => {
      const a = alerts[i] || { type: 0, file: '', enabled: false, volume: 15, loop: 0 };
      const isRadio = (a.type === 1) || (a.file && (a.file.startsWith('http://') || a.file.startsWith('https://')));

      const fileOptions = audioFiles.map(f => `<option value="${safeAttr(f.name)}" ${f.name === a.file ? 'selected' : ''}>${safeText(f.name)}</option>`).join('');
      const radioOptions = radios.map(r => `<option value="${safeAttr(r.url)}" ${r.url === a.file ? 'selected' : ''}>${safeText(r.name)}</option>`).join('');

      return `
        <div class="eid-alert-row" style="background:rgba(255,255,255,0.04); padding:16px; border-radius:12px; border:1px solid rgba(255,255,255,0.08); display:flex; flex-direction:column; gap:12px;">
          <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(255,255,255,0.08); padding-bottom:10px;">
            <div style="display:flex; align-items:center; gap:8px;">
              <span class="day-label" style="font-size:15px; font-weight:bold; color:#f1c40f;"><i class="fas fa-calendar-day"></i> يوم ${d}</span>
            </div>
            <div style="display:flex; align-items:center; gap:8px;">
              <span style="font-size:12px; color:rgba(255,255,255,0.7);">تفعيل التنبيه</span>
              <label class="switch" style="margin:0;">
                <input type="checkbox" id="maghribEnabled_${i}" ${a.enabled ? 'checked' : ''}>
                <span class="slider"></span>
              </label>
            </div>
          </div>

          <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(200px, 1fr)); gap:12px;">
            <div>
              <label style="font-size:12px; color:rgba(255,255,255,0.8); display:block; margin-bottom:4px;">نوع المصدر</label>
              <select id="maghribType_${i}" onchange="toggleMaghribType(${i})" style="margin:0; width:100%; height:40px;">
                <option value="0" ${!isRadio ? 'selected' : ''}>📁 ملف صوتي من الذاكرة (SD)</option>
                <option value="1" ${isRadio ? 'selected' : ''}>📻 إذاعة بث مباشر (Online Radio)</option>
              </select>
            </div>

            <div id="maghribFileRow_${i}" style="${isRadio ? 'display:none;' : ''}">
              <label style="font-size:12px; color:rgba(255,255,255,0.8); display:block; margin-bottom:4px;">الملف الصوتي</label>
              <select id="maghribFile_${i}" style="margin:0; width:100%; height:40px;">
                ${fileOptions || '<option value="">لا توجد ملفات صوتية</option>'}
              </select>
            </div>

            <div id="maghribRadioRow_${i}" style="${!isRadio ? 'display:none;' : ''}">
              <label style="font-size:12px; color:rgba(255,255,255,0.8); display:block; margin-bottom:4px;">قناة الإذاعة</label>
              <select id="maghribRadio_${i}" style="margin:0; width:100%; height:40px;">
                ${radioOptions || '<option value="">لا توجد قنوات إذاعية محملة</option>'}
              </select>
            </div>
          </div>

          <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:12px; align-items:center; background:rgba(0,0,0,0.15); padding:10px 14px; border-radius:8px;">
            <div>
              <label style="font-size:12px; color:rgba(255,255,255,0.7); display:block; margin-bottom:4px;">مدة التشغيل (بالدقائق)</label>
              <input type="number" id="maghribLoop_${i}" value="${a.loop || 0}" min="0" max="180" placeholder="0 = حتى الأذان" style="margin:0; width:100%; height:38px;">
              <small style="font-size:11px; opacity:0.6;">0 تعني الاستمرار حتى وقت الأذان</small>
            </div>

            <div>
              <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                <label style="font-size:12px; color:rgba(255,255,255,0.7); margin:0;">مستوى الصوت</label>
                <span id="magVolVal_${i}" style="font-weight:bold; color:#00f2fe; font-size:13px;">${a.volume || 15}</span>
              </div>
              <input type="range" id="maghribVolume_${i}" value="${a.volume || 15}" min="0" max="30" oninput="$('magVolVal_${i}').textContent=this.value" style="width:100%; margin:0;">
            </div>

            <div style="display:flex; gap:8px; justify-content:flex-end;">
              <button type="button" class="pres-action-btn pres-btn-play" onclick="testMaghribItem(${i})" title="تجربة تشغيل هذا التنبيه">
                <i class="fas fa-play"></i> تجربة
              </button>
              <button type="button" class="pres-action-btn pres-btn-delete" onclick="stopAudio()" title="إيقاف الصوت">
                <i class="fas fa-stop"></i> إيقاف
              </button>
            </div>
          </div>
        </div>
      `;
    }).join('');
  }).catch((err) => {
    toast(`فشل تحميل تنبيهات المغرب: ${err.message}`);
  });
}

function saveMaghribAlerts() {
  const payload = {
    offset: parseInt($('maghribOffset')?.value || '1', 10),
    skipAdhan: $('maghribSkipAdhan')?.checked || false,
    skipIqama: $('maghribSkipIqama')?.checked || false,
    alerts: dayNames.map((_, i) => {
      const isRadio = $(`maghribType_${i}`)?.value === '1';
      const file = isRadio ? ($(`maghribRadio_${i}`)?.value || '') : ($(`maghribFile_${i}`)?.value || '');
      return {
        day: i,
        type: isRadio ? 1 : 0,
        file: file,
        enabled: $(`maghribEnabled_${i}`)?.checked || false,
        volume: parseInt($(`maghribVolume_${i}`)?.value || '15', 10),
        loop: parseInt($(`maghribLoop_${i}`)?.value || '0', 10)
      };
    })
  };

  apiPost('/api/maghrib/alert/save', { json: JSON.stringify(payload) })
    .then(() => toast('تم حفظ كافة تنبيهات وإذاعات المغرب بنجاح'))
    .catch((err) => toast(`فشل الحفظ: ${err.message}`));
}

function startOTA() {
  const input = $('otaFile');
  const btn = $('otaBtn');
  const container = $('otaProgressContainer');
  const bar = $('otaProgressBar');
  const status = $('otaStatusText');

  if (!input?.files?.length) return toast('اختر ملف التحديث');
  
  const file = input.files[0];
  const body = new FormData();
  body.append('update', file);
  if (appState.sessionToken) body.append('token', appState.sessionToken);

  const otaUrl = appState.sessionToken ? `/api/ota?token=${encodeURIComponent(appState.sessionToken)}` : '/api/ota';

  if (btn) btn.disabled = true;
  if (container) container.style.display = 'block';
  if (status) {
    status.style.display = 'block';
    status.innerHTML = 'جاري بدء التحديث...';
  }
  if (bar) bar.style.width = '0%';

  const xhr = new XMLHttpRequest();
  xhr.open('POST', otaUrl, true);

  xhr.upload.onprogress = function(e) {
    if (e.lengthComputable) {
      const pct = Math.round((e.loaded / e.total) * 100);
      if (bar) bar.style.width = `${pct}%`;
      if (status) status.innerHTML = `جاري رفع التحديث: ${pct}%`;
    }
  };

  xhr.onload = function() {
    if (xhr.status === 200) {
      if (bar) bar.style.width = '100%';
      if (status) status.innerHTML = 'تم رفع التحديث بنجاح! جاري إعادة تشغيل الجهاز...';
      toast('تم رفع التحديث بنجاح! سيعاد تشغيل الجهاز بعد قليل.');
      setTimeout(() => {
        location.reload();
      }, 5000);
    } else if (xhr.status === 401) {
      doLogout();
      toast('غير مصرح لك بالوصول، يرجى تسجيل الدخول مجدداً.');
      resetOtaUI();
    } else {
      toast('فشل التحديث: حدث خطأ أثناء الرفع.');
      resetOtaUI();
    }
  };

  xhr.onerror = function() {
    toast('فشل التحديث: خطأ في الاتصال بالشبكة.');
    resetOtaUI();
  };

  xhr.send(body);

  function resetOtaUI() {
    if (btn) btn.disabled = false;
    if (container) container.style.display = 'none';
    if (status) status.style.display = 'none';
    if (input) input.value = '';
  }
}

function uploadCSV() {
  const input = $('csvFileInput');
  if (!input?.files?.length) return toast('اختر ملف CSV');
  const body = new FormData();
  body.append('month', $('csvMonthSelect')?.value || '1');
  body.append('file', input.files[0]);
  fetch(`/api/csv/upload?month=${encodeURIComponent($('csvMonthSelect')?.value || '1')}`, { method: 'POST', body })
    .then((r) => {
      if (!r.ok) throw new Error('csv upload failed');
      toast('تم رفع ملف CSV');
      loadCsvStatus();
    })
    .catch((err) => toast(`فشل الرفع: ${err.message}`));
}

function toggleCSVMode() {
  apiPost('/api/csv/toggle', { enabled: $('csvModeToggle')?.checked ? '1' : '0' })
    .then(loadCsvStatus).catch((err) => toast(`فشل التحديث: ${err.message}`));
}

function toggleCalendarOnly() {
  apiPost('/api/calendar/only', { enabled: $('calendarOnlyToggle')?.checked ? '1' : '0' })
    .then(loadCsvStatus).catch((err) => toast(`فشل التحديث: ${err.message}`));
}

function toggleCalendarFallback() {
  apiPost('/api/calendar/fallback', { enabled: $('calendarFallbackToggle')?.checked ? '1' : '0' })
    .then(loadCsvStatus).catch((err) => toast(`فشل التحديث: ${err.message}`));
}

let calendarDownloadActive = false;
let calendarMissingMonths = [];

function monthLabel(month) {
  const names = ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
  return names[month - 1] || String(month);
}

function selectCalendarYear(year) {
  if ($('calendarYearInput')) {
    $('calendarYearInput').value = year;
  }
  loadCsvStatus(year);
}

function renderCalendarMonths(year, available, missing, savedYears = []) {
  if (!$('calendarMonthsView')) return;
  const yearsHtml = Array.isArray(savedYears) && savedYears.length
    ? `<div style="margin-bottom:10px; padding:10px 12px; border-radius:8px; background:rgba(52, 152, 219, 0.12); border:1px solid rgba(52, 152, 219, 0.35);">` +
      `<div style="font-weight:bold; color:#3498db; margin-bottom:6px;"><i class="fas fa-sd-card"></i> السنوات المحفوظة حالياً على بطاقة SD (اضغط على السنة لعرضها):</div>` +
      savedYears.map((item) => {
        const isCurrent = Number(item.year) === Number(year);
        const bg = isCurrent ? 'background:#2ecc71;color:#000;font-weight:bold;border:2px solid #fff;' : '';
        return `<button class="btn" style="padding:5px 12px; margin:3px; ${bg}" onclick="selectCalendarYear(${Number(item.year)})"><i class="fas fa-check-circle"></i> رزنامة ${safeText(item.year)} (${Number(item.months)}/12 شهر)</button>`;
      }).join(' ') +
      `</div>`
    : `<div style="margin-bottom:8px; color:#f39c12;">لا توجد سنوات محفوظة على SD حالياً</div>`;
  const availableText = available.length ? available.map((m) =>
    `<button class="btn" style="padding:6px 10px; margin:3px;" onclick="openCalendarMonth(${year}, ${m})">${safeText(monthLabel(m))}</button>`
  ).join('') : 'لا يوجد';
  const missingText = missing.length ? missing.map(monthLabel).join('، ') : 'لا يوجد (مكتملة 12/12)';
  $('calendarMonthsView').innerHTML =
    yearsHtml +
    `<div>الموجود على SD لسنة ${year}: <span style="color:#2ecc71">${availableText}</span></div>` +
    `<div>الناقص لسنة ${year}: <span style="color:${missing.length ? '#e74c3c' : '#2ecc71'}">${safeText(missingText)}</span></div>`;
}

function openCalendarMonth(year, month) {
  apiGet(`/api/calendar/month?year=${encodeURIComponent(year)}&month=${encodeURIComponent(month)}`, { ok: false }, 0)
    .then((data) => {
      if (!data.ok) return toast('تعذر فتح ملف الشهر');
      calendarEditorYear = year;
      calendarEditorMonth = month;
      if ($('calendarMonthEditor')) $('calendarMonthEditor').style.display = 'block';
      if ($('calendarMonthEditorTitle')) $('calendarMonthEditorTitle').textContent = `محتوى ${monthLabel(month)} ${year}`;
      if ($('calendarMonthCsv')) $('calendarMonthCsv').value = data.csv || '';
    });
}

function saveCalendarMonthCsv() {
  if (!calendarEditorYear || !calendarEditorMonth) return toast('اختر شهر أولاً');
  apiPost('/api/calendar/month', {
    year: calendarEditorYear,
    month: calendarEditorMonth,
    csv: $('calendarMonthCsv')?.value || ''
  }).then(() => {
    toast('تم حفظ تعديل الشهر');
    loadCsvStatus();
    fetchPrayerTimes();
  }).catch((err) => toast(`فشل حفظ الشهر: ${err.message}`));
}

function closeCalendarMonthEditor() {
  if ($('calendarMonthEditor')) $('calendarMonthEditor').style.display = 'none';
  calendarEditorYear = 0;
  calendarEditorMonth = 0;
}

function downloadCalendarMonths(months, force = false) {
  const year = parseInt($('calendarYearInput')?.value, 10) || new Date().getFullYear();
  if (year < 2000 || year > 2100) return toast('أدخل سنة صحيحة بين 2000 و 2100');
  const country = $('countrySelect')?.value || '';
  const city = $('citySelect')?.value || '';
  const method = $('methodSelect')?.value ?? defaultPrayerMethod(country || 'Egypt');
  if (calendarDownloadActive) return toast('يوجد تحميل رزنامة قيد التنفيذ');
  if (!months.length) return toast('لا توجد شهور ناقصة للتحميل');
  calendarDownloadActive = true;
  let saved = 0;
  let skipped = 0;
  const failed = [];
  if ($('calendarStatus')) $('calendarStatus').textContent = `جاري تحميل رزنامة سنة ${year} إلى SD... 0/${months.length}`;

  const waitCalendarJob = (month) => new Promise((resolve) => {
    const poll = () => {
      apiGet('/api/calendar/download_status', { ok: false }, 0)
        .then((status) => {
          if (!status.done) {
            setTimeout(poll, 600);
            return;
          }
          if (status.success) saved++;
          else failed.push(`${month}${status.error ? ':' + status.error : ''}`);
          if ($('calendarStatus')) $('calendarStatus').textContent = `جاري تحميل سنة ${year}... شهر ${month} (تم ${saved})`;
          resolve();
        })
        .catch(() => {
          failed.push(`${month}:status_failed`);
          resolve();
        });
    };
    poll();
  });

  const downloadMonth = (month, index) => apiPost('/api/calendar/download_month', { year, month, country, city, method, force: force ? '1' : '0' })
    .then((data) => {
      if (data.skipped) {
        skipped++;
        if ($('calendarStatus')) $('calendarStatus').textContent = `تخطي ${monthLabel(month)} (${year}) لأنه موجود (${index + 1}/${months.length})`;
        return;
      }
      if (!data.ok) {
        failed.push(`${month}${data.error ? ':' + data.error : ''}`);
        return;
      }
      return waitCalendarJob(month);
    })
    .catch((err) => {
      failed.push(`${month}:${err.message}`);
      if ($('calendarStatus')) $('calendarStatus').textContent = `فشل شهر ${month}: ${err.message}`;
    });

  let chain = Promise.resolve();
  months.forEach((month, index) => {
    chain = chain.then(() => downloadMonth(month, index));
  });
  chain.then(() => {
    calendarDownloadActive = false;
    if (failed.length === 0) {
      toast(`اكتمل تحميل رزنامة سنة ${year}`);
      if ($('calendarStatus')) $('calendarStatus').textContent = `اكتمل لسنة ${year}: تم حفظ ${saved} شهر، تخطي ${skipped}`;
    } else {
      toast(`اكتمل جزئياً: تم ${saved} وفشل ${failed.length}`);
      if ($('calendarStatus')) $('calendarStatus').textContent = `اكتمل جزئياً لسنة ${year}. تم ${saved}، تخطي ${skipped}. فشل: ${failed.join(', ')}`;
    }
    loadCsvStatus(year);
  });
}

function downloadYearCalendar() {
  downloadCalendarMonths([1,2,3,4,5,6,7,8,9,10,11,12], true);
}

function downloadMissingCalendarMonths() {
  const year = parseInt($('calendarYearInput')?.value, 10) || new Date().getFullYear();
  apiGet(`/api/csv/status?year=${encodeURIComponent(year)}`, null, 0)
    .then((data) => {
      if (data && Array.isArray(data.missingCalendarMonths)) {
        calendarMissingMonths = data.missingCalendarMonths;
        renderCalendarMonths(year, data.calendarMonths || [], calendarMissingMonths);
      }
      downloadCalendarMonths(calendarMissingMonths.slice(), false);
    })
    .catch(() => {
      downloadCalendarMonths(calendarMissingMonths.slice(), false);
    });
}

function deleteYearCalendar() {
  if (calendarDownloadActive) return toast('أوقف/انتظر انتهاء التحميل الحالي أولاً');
  const year = $('calendarYearInput')?.value || new Date().getFullYear();
  if (!confirm(`حذف رزنامة سنة ${year} من SD؟`)) return;
  apiPost('/api/calendar/delete_year', { year })
    .then((data) => {
      if (!data.ok) throw new Error(data.error || 'delete failed');
      toast('تم حذف رزنامة السنة من SD');
      if ($('calendarStatus')) $('calendarStatus').textContent = `تم حذف رزنامة ${year}`;
      loadCsvStatus();
    })
    .catch((err) => toast(`فشل الحذف: ${err.message}`));
}

function loadCsvStatus(explicitYear) {
  const inputEl = $('calendarYearInput');
  const selectedYear = explicitYear || inputEl?.value || '';
  const query = selectedYear ? `?year=${encodeURIComponent(selectedYear)}` : '';
  apiGet(`/api/csv/status${query}`, {}, 2).then((data) => {
    if ($('csvModeToggle')) $('csvModeToggle').checked = !!data.enabled;
    if ($('calendarOnlyToggle')) $('calendarOnlyToggle').checked = !!data.calendarOnly;
    if ($('calendarFallbackToggle')) $('calendarFallbackToggle').checked = data.calendarFallback !== false;
    const activeYear = data.calendarYear || selectedYear || new Date().getFullYear();
    if (inputEl && activeYear) inputEl.value = activeYear;
    if (data.deferred) {
      appState.csvStatusLoaded = false;
      setTimeout(() => loadCsvStatus(explicitYear), 1500);
      return;
    }
    appState.csvStatusLoaded = true;
    const statusEl = $('calendarStatus');
    if (statusEl) {
      const months = data.calendarMonths || [];
      const savedYears = Array.isArray(data.savedYears) ? data.savedYears : [];
      calendarMissingMonths = data.missingCalendarMonths || [];
      const savedSummary = savedYears.length
        ? ` | السنوات المتوفرة على SD: ${savedYears.map((y) => `${y.year} (${y.months}/12)`).join(' ، ')}`
        : '';
      if (months.length > 0) {
        statusEl.style.background = 'rgba(46, 204, 113, 0.15)';
        statusEl.style.borderColor = 'rgba(46, 204, 113, 0.45)';
        statusEl.style.color = '#2ecc71';
        statusEl.textContent = `✅ رزنامة ${activeYear} موجودة على بطاقة SD (${months.length}/12 شهر)` + savedSummary;
      } else {
        statusEl.style.background = 'rgba(243, 156, 18, 0.15)';
        statusEl.style.borderColor = 'rgba(243, 156, 18, 0.45)';
        statusEl.style.color = '#f39c12';
        statusEl.textContent = `⚠️ لا توجد رزنامة محفوظة لسنة ${activeYear} على SD` + savedSummary;
      }
      renderCalendarMonths(activeYear, months, calendarMissingMonths, savedYears);
    }
  });
}

const dayNames = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

const prayerNames = ['الفجر', 'الظهر', 'العصر', 'المغرب', 'العشاء'];

function toggleEidScheduleFields() {
  const type = $('eidScheduleType')?.value || 'daily';
  let html = '';
  if (type === 'weekly') html = '<label>اختر الأيام</label><div id="eidWeeklyDays">' +
    dayNames.map((d, i) => `<label style="display:inline-flex;align-items:center;gap:4px;margin:4px 8px 4px 0;font-size:var(--fs-small)"><input type="checkbox" class="eid-weekly-day-cb" value="${i}"> ${d}</label>`
  ).join('') + '</div>';
  if (type === 'monthly') html = '<label>اليوم من الشهر</label><input type="number" id="eidScheduleDay" min="1" max="31" value="1">';
  if (type === 'specific') html = '<label>التاريخ</label><input type="date" id="eidScheduleDate">';
  if (type === 'prayer_relative') {
    html = '<label>الصلاة</label><select id="eidSchedulePrayer"><option value="0">الفجر</option><option value="1">الظهر</option><option value="2">العصر</option><option value="3">المغرب</option><option value="4">العشاء</option></select>' +
      '<label>الإزاحة بالدقائق</label><input type="number" id="eidScheduleOffset" value="0">' +
      '<label>قبل/بعد</label><select id="eidScheduleBeforeAfter"><option value="before">قبل الصلاة</option><option value="after">بعد الصلاة</option></select>' +
      '<label>أيام التشغيل (اختياري - اتركه فارغاً للتشغيل يومياً)</label><div id="eidWeeklyDays">' +
      dayNames.map((d, i) => `<label style="display:inline-flex;align-items:center;gap:4px;margin:4px 8px 4px 0;font-size:var(--fs-small)"><input type="checkbox" class="eid-weekly-day-cb" value="${i}"> ${d}</label>`
    ).join('') + '</div>';
  }
  if ($('eidScheduleExtraFields')) $('eidScheduleExtraFields').innerHTML = html;

  const timeContainer = $('eidScheduleTimeContainer');
  if (timeContainer) {
    timeContainer.style.display = type === 'prayer_relative' ? 'none' : 'block';
  }
}

function toggleEidLoopFields() {
  if ($('eidLoopFields')) $('eidLoopFields').style.display = $('eidScheduleLoopToggle')?.value === 'yes' ? 'block' : 'none';
}

let editingEidAlertIndex = -1;

function cancelEditEidSchedule() {
  editingEidAlertIndex = -1;
  if ($('eidScheduleName')) $('eidScheduleName').value = '';
  document.querySelectorAll('.eid-file-cb').forEach(cb => cb.checked = false);
  if ($('eidScheduleType')) {
    $('eidScheduleType').value = 'daily';
    toggleEidScheduleFields();
  }
  if ($('eidScheduleTime')) $('eidScheduleTime').value = '00:00';
  if ($('eidScheduleRepeatInterval')) $('eidScheduleRepeatInterval').value = 0;
  if ($('eidScheduleEndTime')) $('eidScheduleEndTime').value = '';
  toggleAlertEndTimeField('eidSchedule');
  if ($('eidScheduleVolume')) {
    $('eidScheduleVolume').value = 20;
    if ($('eidScheduleVolumeValue')) $('eidScheduleVolumeValue').textContent = 20;
  }
  if ($('eidScheduleLoopToggle')) {
    $('eidScheduleLoopToggle').value = 'no';
    toggleEidLoopFields();
  }
  if ($('eidScheduleLoopDuration')) $('eidScheduleLoopDuration').value = 0;
  
  if ($('eidScheduleSaveBtn')) {
    $('eidScheduleSaveBtn').innerHTML = '<i class="fas fa-save"></i> إضافة تنبيه عيد';
  }
  if ($('eidScheduleCancelEditBtn')) {
    $('eidScheduleCancelEditBtn').style.display = 'none';
  }
}

function editEidSchedule(index) {
  const alert = appState.alerts[index];
  if (!alert) return;
  
  editingEidAlertIndex = index;
  showSubTab('tab-eid', 'sub-eid-alerts');
  
  if ($('eidScheduleName')) $('eidScheduleName').value = alert.name || '';
  
  const files = (alert.file || '').split(',');
  document.querySelectorAll('.eid-file-cb').forEach(cb => {
    cb.checked = files.includes(cb.value);
  });
  
  if ($('eidScheduleType')) {
    $('eidScheduleType').value = alert.type || 'daily';
    toggleEidScheduleFields();
  }
  
  if (alert.type === 'prayer_relative') {
    if ($('eidSchedulePrayer')) $('eidSchedulePrayer').value = alert.prayerIndex || 0;
    if ($('eidScheduleOffset')) $('eidScheduleOffset').value = Math.abs(alert.offsetSeconds / 60);
    if ($('eidScheduleBeforeAfter')) $('eidScheduleBeforeAfter').value = alert.offsetSeconds < 0 ? 'before' : 'after';
  } else {
    if ($('eidScheduleTime')) {
      $('eidScheduleTime').value = `${String(alert.hour).padStart(2, '0')}:${String(alert.minute).padStart(2, '0')}`;
    }
  }
  
  if ((alert.type === 'weekly' || alert.type === 'prayer_relative') && alert.dayOfWeek >= 0) {
    document.querySelectorAll('.eid-weekly-day-cb').forEach(cb => {
      cb.checked = (alert.dayOfWeek & (1 << parseInt(cb.value))) !== 0;
    });
  } else if (alert.type === 'monthly') {
    if ($('eidScheduleDay')) $('eidScheduleDay').value = alert.dayOfMonth;
  } else if (alert.type === 'specific') {
    if ($('eidScheduleDate')) $('eidScheduleDate').value = alert.specificDate || '';
  }
  
  if ($('eidScheduleRepeatInterval')) {
    $('eidScheduleRepeatInterval').value = alert.repeatInterval !== undefined ? alert.repeatInterval : 0;
    toggleAlertEndTimeField('eidSchedule');
  }
  if ($('eidScheduleEndTime') && alert.endHour !== undefined && alert.endHour >= 0) {
    const eh = String(alert.endHour).padStart(2, '0');
    const em = String(alert.endMinute).padStart(2, '0');
    $('eidScheduleEndTime').value = eh + ':' + em;
  } else {
    if ($('eidScheduleEndTime')) $('eidScheduleEndTime').value = '';
  }
  
  if ($('eidScheduleVolume')) {
    $('eidScheduleVolume').value = alert.volume !== undefined ? alert.volume : 20;
    if ($('eidScheduleVolumeValue')) $('eidScheduleVolumeValue').textContent = alert.volume !== undefined ? alert.volume : 20;
  }
  
  if ($('eidScheduleLoopToggle')) {
    $('eidScheduleLoopToggle').value = (alert.loop && alert.loop > 0) ? 'yes' : 'no';
    toggleEidLoopFields();
  }
  if ($('eidScheduleLoopDuration') && alert.loop) {
    $('eidScheduleLoopDuration').value = alert.loop;
  }
  
  if ($('eidScheduleSaveBtn')) {
    $('eidScheduleSaveBtn').innerHTML = '<i class="fas fa-save"></i> حفظ التعديلات';
  }
  if ($('eidScheduleCancelEditBtn')) {
    $('eidScheduleCancelEditBtn').style.display = 'block';
  }
}

function addEidSchedule() {
  const checkboxes = document.querySelectorAll('.eid-file-cb:checked');
  if (checkboxes.length === 0) return toast('اختر ملفاً واحداً على الأقل');
  const fileList = Array.from(checkboxes).map(cb => cb.value).join(',');

  const name = $('eidScheduleName')?.value || '';
  const [hour = '0', minute = '0'] = ($('eidScheduleTime')?.value || '00:00').split(':');
  const type = $('eidScheduleType')?.value || 'daily';
  let dayOfWeek = -1, dayOfMonth = -1;
  if (type === 'weekly' || type === 'prayer_relative') {
    const cbs = document.querySelectorAll('.eid-weekly-day-cb:checked');
    if (cbs.length > 0) {
      dayOfWeek = 0;
      cbs.forEach(cb => { dayOfWeek |= (1 << parseInt(cb.value)); });
    } else if (type === 'weekly') {
      return toast('اختر يوماً واحداً على الأقل');
    }
  }
  if (type === 'monthly') dayOfMonth = $('eidScheduleDay')?.value || '-1';
  let offsetSeconds = Number($('eidScheduleOffset')?.value || 0) * 60;
  if ($('eidScheduleBeforeAfter')?.value === 'before') offsetSeconds = -Math.abs(offsetSeconds);

  const repeatInterval = Number($('eidScheduleRepeatInterval')?.value || 0);
  const endHour = $('eidScheduleEndTime')?.value ? Number($('eidScheduleEndTime').value.split(':')[0]) : -1;
  const endMinute = $('eidScheduleEndTime')?.value ? Number($('eidScheduleEndTime').value.split(':')[1]) : -1;

  const data = {
    name,
    file: fileList,
    type,
    hour,
    minute,
    dayOfWeek,
    dayOfMonth,
    specificDate: $('eidScheduleDate')?.value || '',
    volume: $('eidScheduleVolume')?.value || 20,
    loop: $('eidScheduleLoopToggle')?.value === 'yes' ? Number($('eidScheduleLoopDuration')?.value || 0) : 0,
    prayerIndex: $('eidSchedulePrayer')?.value || 0,
    offsetSeconds,
    eidOnly: '1',
    important: 1,
    repeatInterval,
    endHour,
    endMinute,
    index: editingEidAlertIndex
  };
  if (editingEidAlertIndex >= 0 && appState.alerts[editingEidAlertIndex]) {
    data.enabled = appState.alerts[editingEidAlertIndex].enabled !== false ? 1 : 0;
  }

  apiPost('/api/scheduler/add', data).then(() => {
    toast(editingEidAlertIndex >= 0 ? 'تم تعديل تنبيه العيد' : 'تم إضافة تنبيه العيد');
    cancelEditEidSchedule();
    loadEidSchedules();
  }).catch((err) => toast(`فشل الحفظ: ${err.message}`));
}

function loadEidSchedules() {
  apiGet('/api/scheduler/list', []).then((data) => {
    const alerts = Array.isArray(data) ? data : (data.alerts || []);
    appState.alerts = alerts;
    alerts.forEach((alert, index) => {
      alert.originalIndex = index;
    });
    
    const eidAlerts = alerts.filter(a =>
      (a.eidOnly && (a.eidOnly === '1' || a.eidOnly === 1 || a.eidOnly === true || a.eidOnly === 'true')) ||
      (a.bothModes && (a.bothModes === '1' || a.bothModes === 1 || a.bothModes === true || a.bothModes === 'true'))
    );
    const eidLocalAlerts = [];
    const eidRadioAlerts = [];
    
    eidAlerts.forEach(alert => {
      if (alert.file && (alert.file.startsWith('http://') || alert.file.startsWith('https://'))) {
        eidRadioAlerts.push(alert);
      } else {
        eidLocalAlerts.push(alert);
      }
    });

    if ($('eidScheduleList')) {
      $('eidScheduleList').innerHTML = eidLocalAlerts.length
        ? eidLocalAlerts.map((a) => {
            const realIndex = a.originalIndex;
            let namePrefix = a.name ? `<strong>${safeText(a.name)}</strong>: ` : '';
            let info = `${namePrefix}${safeText(a.file)} - ${safeText(a.type)}`;
            if (a.type === 'weekly' && a.dayOfWeek > 0) info += ` (${formatDays(a.dayOfWeek)})`;
            if (a.type === 'prayer_relative') {
              const pn = prayerNames[a.prayerIndex] || '';
              info += ` ${pn} ${a.offsetSeconds >= 0 ? 'بعد' : 'قبل'} (${Math.abs(a.offsetSeconds/60)}د)`;
            } else {
              info += ` ${String(a.hour).padStart(2, '0')}:${String(a.minute).padStart(2, '0')}`;
            }
            if (a.repeatInterval > 0) {
              info += ` (تكرار كل ${a.repeatInterval}د`;
              if (a.endHour >= 0 && a.endMinute >= 0) {
                info += ` حتى ${String(a.endHour).padStart(2, '0')}:${String(a.endMinute).padStart(2, '0')}`;
              }
              info += `)`;
            }
            info += ` - صوت: ${a.volume || 20}`;
            if (a.loop > 0) info += ` (تكرار ${a.loop}د)`;
            if (a.enabled === false) {
              info += ` | <span style="color:#ff6b6b; font-weight:bold;">🚫 موقف</span>`;
            }
            const toggleBtnClass = a.enabled !== false ? 'btn-secondary' : 'btn-play';
            const toggleBtnText = a.enabled !== false ? '<i class="fas fa-pause"></i> إيقاف' : '<i class="fas fa-play"></i> تشغيل';
            const itemOpacity = a.enabled !== false ? '' : 'opacity: 0.6;';
            return `<li class="file-item" style="display:flex; justify-content:space-between; align-items:center; ${itemOpacity}">
              <span>${info}</span>
              <div style="display:flex; gap:5px;">
                <button class="btn ${toggleBtnClass}" onclick="toggleSchedule(${realIndex}, ${a.enabled === false}, true)" style="padding:4px 8px; font-size:12px; margin:0;">${toggleBtnText}</button>
                <button class="btn btn-secondary" onclick="editEidSchedule(${realIndex})" style="padding:4px 8px; font-size:12px; margin:0;"><i class="fas fa-edit"></i> تعديل</button>
                <button class="btn btn-danger" onclick="deleteEidSchedule(${realIndex})" style="padding:4px 8px; font-size:12px; margin:0;">حذف</button>
              </div>
            </li>`;
          }).join('')
        : '<p style="text-align:center;opacity:0.7">لا توجد تنبيهات ملفات عيد. أضف تنبيهاً أعلاه.</p>';
    }

    if ($('eidRadioScheduleList')) {
      $('eidRadioScheduleList').innerHTML = eidRadioAlerts.length
        ? eidRadioAlerts.map((a) => {
            const realIndex = a.originalIndex;
            let namePrefix = a.name ? `<strong>${safeText(a.name)}</strong>: ` : '';
            let info = `${namePrefix}${safeText(a.file)} - ${safeText(a.type)}`;
            if (a.type === 'weekly' && a.dayOfWeek > 0) info += ` (${formatDays(a.dayOfWeek)})`;
            if (a.type === 'prayer_relative') {
              const pn = prayerNames[a.prayerIndex] || '';
              info += ` ${pn} ${a.offsetSeconds >= 0 ? 'بعد' : 'قبل'} (${Math.abs(a.offsetSeconds/60)}د)`;
              if (a.skipAdhan) info += `، 🔕 تخطي الأذان`;
              if (a.skipIqama) info += `، 🔕 تخطي الإقامة`;
            } else {
              info += ` ${String(a.hour).padStart(2, '0')}:${String(a.minute).padStart(2, '0')}`;
            }
            if (a.repeatInterval > 0) {
              info += ` (تكرار كل ${a.repeatInterval}د`;
              if (a.endHour >= 0 && a.endMinute >= 0) {
                info += ` حتى ${String(a.endHour).padStart(2, '0')}:${String(a.endMinute).padStart(2, '0')}`;
              }
              info += `)`;
            }
            info += ` - صوت: ${a.volume || 20}`;
            if (a.loop > 0) info += ` (تكرار ${a.loop}د)`;
            if (a.enabled === false) {
              info += ` | <span style="color:#ff6b6b; font-weight:bold;">🚫 موقف</span>`;
            }
            const toggleBtnClass = a.enabled !== false ? 'btn-secondary' : 'btn-play';
            const toggleBtnText = a.enabled !== false ? '<i class="fas fa-pause"></i> إيقاف' : '<i class="fas fa-play"></i> تشغيل';
            const itemOpacity = a.enabled !== false ? '' : 'opacity: 0.6;';
            return `<li class="file-item" style="display:flex; justify-content:space-between; align-items:center; ${itemOpacity}">
              <span>${info}</span>
              <div style="display:flex; gap:5px;">
                <button class="btn ${toggleBtnClass}" onclick="toggleSchedule(${realIndex}, ${a.enabled === false}, true)" style="padding:4px 8px; font-size:12px; margin:0;">${toggleBtnText}</button>
                <button class="btn btn-secondary" onclick="editSingleAlert(${realIndex})" style="padding:4px 8px; font-size:12px; margin:0;"><i class="fas fa-edit"></i> تعديل</button>
                <button class="btn btn-danger" onclick="deleteEidSchedule(${realIndex})" style="padding:4px 8px; font-size:12px; margin:0;">حذف</button>
              </div>
            </li>`;
          }).join('')
        : '<p style="text-align:center;opacity:0.7">لا توجد تنبيهات راديو عيد. قم بجدولتها من قسم الراديو واختيار وضع العيد.</p>';
    }
  });
}

function deleteEidSchedule(index) {
  apiPost('/api/scheduler/delete', { index }).then(() => {
    toast('تم حذف تنبيه العيد');
    cancelEditEidSchedule();
    loadEidSchedules();
  }).catch((err) => toast(`فشل الحذف: ${err.message}`));
}

function loadEidTakbeerConfig() {
  apiGet('/api/eid/takbeer_config', {}).then((data) => {
    if (!$('eidPrayerConfig')) return;
    $('eidPrayerConfig').innerHTML = prayerNames.map((name, i) => {
      const cfg = data.prayers ? data.prayers[i] : {enabled: i < 5, before: 15, after: 15};
      const enableBefore = cfg.before > 0 ? 'checked' : '';
      const enableAfter = cfg.after > 0 ? 'checked' : '';
      return `<div class="eid-takbeer-row">
        <label class="prayer-label"><input type="checkbox" class="eid-prayer-cb" value="${i}" ${cfg.enabled?'checked':''}> ${name}</label>
        <label><input type="checkbox" class="eid-prayer-cb-before" ${enableBefore}> قبل <input type="number" class="eid-prayer-before" value="${cfg.before>0?cfg.before:15}" min="0" style="width:50px;margin:0 5px"> د</label>
        <label><input type="checkbox" class="eid-prayer-cb-after" ${enableAfter}> بعد <input type="number" class="eid-prayer-after" value="${cfg.after>0?cfg.after:15}" min="0" style="width:50px;margin:0 5px"> د</label>
      </div>`;
    }).join('');
  });
}

function saveEidTakbeerConfig() {
  const takbeerFile = $('eidTakbeerFile')?.value || '';
  if (!takbeerFile) return toast('اختر ملف التكبيرات أولاً');
  const takbeerVolume = $('eidTakbeerVolume')?.value || 15;

  const prayers = [];
  document.querySelectorAll('.eid-prayer-cb').forEach((cb, i) => {
    const cbBefore = document.querySelectorAll('.eid-prayer-cb-before')[i];
    const beforeInput = document.querySelectorAll('.eid-prayer-before')[i];
    const cbAfter = document.querySelectorAll('.eid-prayer-cb-after')[i];
    const afterInput = document.querySelectorAll('.eid-prayer-after')[i];
    prayers.push({
      enabled: cb.checked,
      before: cbBefore?.checked ? parseInt(beforeInput?.value || '0') : 0,
      after: cbAfter?.checked ? parseInt(afterInput?.value || '0') : 0
    });
  });
  apiPost('/api/eid/file', { file: takbeerFile, volume: takbeerVolume })
    .then(() => apiPost('/api/eid/takbeer_config/save', {json: JSON.stringify(prayers)}))
    .then(() => toast('تم حفظ ملف التكبيرات وجدولتها'))
    .catch((err) => toast(`فشل الحفظ: ${err.message}`));
}

function toggleStartupAlert() {
  saveStartupSettings();
}

function saveStartupSettings() {
  apiPost('/api/startup/save', {
    enabled: $('startupAlertEnabled')?.checked ? '1' : '0',
    file: $('startupFileSelect')?.value || ''
  }).then(() => toast('تم حفظ إعدادات بدء التشغيل'))
    .catch((err) => toast(`فشل الحفظ: ${err.message}`));
}

function loadStartupSettings() {
  apiGet('/api/startup/status', {}).then((data) => {
    if ($('startupAlertEnabled')) $('startupAlertEnabled').checked = !!data.enabled;
    if ($('startupFileSelect') && data.file) $('startupFileSelect').value = data.file;
  });
}

function loadSessionTimeout() {
  apiGet('/api/session/timeout', {}).then((data) => {
    const mins = data.timeout || 10;
    if ($('sessionTimeout')) $('sessionTimeout').value = mins;
    localStorage.setItem('vivoSessionTimeout', String(mins));
  });
}

function saveSessionTimeout() {
  const mins = parseInt($('sessionTimeout')?.value || '10');
  if (mins < 1) return toast('المدة يجب أن تكون دقيقة واحدة على الأقل');
  apiPost('/api/session/timeout/save', { timeout: mins })
    .then(() => {
      localStorage.setItem('vivoSessionTimeout', String(mins));
      toast(`تم حفظ مدة الجلسة: ${mins} دقائق`);
    })
    .catch((err) => toast(`فشل الحفظ: ${err.message}`));
}

function loadManualTimeStatus() {
  apiGet('/api/time/manual_status', {}).then((data) => {
    if ($('manualTimeToggle')) $('manualTimeToggle').checked = !!data.enabled;
    if ($('manualYear')) $('manualYear').value = data.year || 2026;
    if ($('manualMonth')) $('manualMonth').value = data.month || 1;
    if ($('manualDay')) $('manualDay').value = data.day || 1;
    
    let h = data.hour || 0;
    let ampm = 'am';
    if (h >= 12) {
      ampm = 'pm';
      if (h > 12) h -= 12;
    } else if (h === 0) {
      h = 12;
    }
    if ($('manualHour')) $('manualHour').value = h;
    if ($('manualAmPm')) $('manualAmPm').value = ampm;
    
    if ($('manualMinute')) $('manualMinute').value = data.minute || 0;
    if ($('manualTimeFields')) $('manualTimeFields').style.display = data.enabled ? 'block' : 'none';
  });
}

function saveManualTime() {
  const enabled = $('manualTimeToggle')?.checked || false;
  
  let hour = parseInt($('manualHour')?.value || '12');
  const ampm = $('manualAmPm')?.value || 'am';
  if (ampm === 'pm' && hour < 12) hour += 12;
  if (ampm === 'am' && hour === 12) hour = 0;
  
  apiPost('/api/time/manual_save', {
    enabled: enabled ? '1' : '0',
    year: $('manualYear')?.value || '2026',
    month: $('manualMonth')?.value || '1',
    day: $('manualDay')?.value || '1',
    hour: hour.toString(),
    minute: $('manualMinute')?.value || '0'
  }).then(() => {
    toast('تم حفظ الوقت والتاريخ');
    if (enabled) toast('تم تطبيق الوقت اليدوي الآن');
    updateClock();
    fetchPrayerTimes();
  }).catch((err) => toast(`فشل الحفظ: ${err.message}`));
}

function toggleManualTime() {
  if ($('manualTimeFields')) $('manualTimeFields').style.display = $('manualTimeToggle')?.checked ? 'block' : 'none';
}

function checkSessionTimeout() {
  const sessionTime = parseInt(localStorage.getItem('vivoSessionTime') || '0');
  const timeoutMinutes = parseInt(localStorage.getItem('vivoSessionTimeout') || '10');
  if (sessionTime > 0 && (Date.now() - sessionTime) > (timeoutMinutes * 60000)) {
    doLogout();
  }
}

function changePassword() {
  const oldPassword = $('oldPassword')?.value || '';
  const newPassword = $('newPassword')?.value || '';
  const confirmPassword = $('confirmPassword')?.value || '';
  if (newPassword.length < 4) return toast('كلمة المرور قصيرة');
  if (newPassword !== confirmPassword) return toast('تأكيد كلمة المرور غير مطابق');
  apiPost('/api/password/change', { old: oldPassword, password: newPassword, token: appState.sessionToken })
    .then((data) => {
      if (!data.ok) return toast('كلمة المرور القديمة غير صحيحة');
      appState.sessionToken = data.token || appState.sessionToken;
      localStorage.setItem('vivoSessionToken', appState.sessionToken);
      toast('تم تغيير كلمة المرور');
    })
    .catch((err) => toast(`فشل التغيير: ${err.message}`));
}

function checkResponsive() {
  if (window.innerWidth <= 992) {
    document.body.classList.add('is-mobile');
  } else {
    document.body.classList.remove('is-mobile');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    const menuBtnIcon = document.querySelector('#menuToggleBtn i');
    if (sidebar) sidebar.classList.remove('open');
    if (overlay) overlay.style.display = 'none';
    if (menuBtnIcon) {
      menuBtnIcon.classList.remove('fa-times');
      menuBtnIcon.classList.add('fa-bars');
    }
  }
}

document.addEventListener('DOMContentLoaded', () => {
  checkResponsive();
  window.addEventListener('resize', checkResponsive);

  const resetSessionTimer = () => {
    if (appState.sessionToken) {
      localStorage.setItem('vivoSessionTime', Date.now().toString());
      appState.lastUserInteraction = Date.now();
    }
  };
  window.addEventListener('mousedown', resetSessionTimer);
  window.addEventListener('keydown', resetSessionTimer);
  window.addEventListener('touchstart', resetSessionTimer);
  window.addEventListener('scroll', resetSessionTimer);

  toggleDHCP();
  toggleScheduleFields();
  toggleLoopFields();
  toggleEidScheduleFields();
  toggleEidLoopFields();
  toggleAlertSourceType();
  populateGpioPins();
  if ($('scheduleVolume')) {
    $('scheduleVolume').addEventListener('input', () => {
      if ($('scheduleVolumeValue')) $('scheduleVolumeValue').textContent = $('scheduleVolume').value;
    });
  }
  const sessionTime = parseInt(localStorage.getItem('vivoSessionTime') || '0');
  let timeoutMinutes = parseInt(localStorage.getItem('vivoSessionTimeout') || '10');
  const sessionValid = (Date.now() - sessionTime) < (timeoutMinutes * 60000);
  const hasToken = appState.sessionToken || localStorage.getItem('vivoPassword');

  if (sessionValid && hasToken) {
      document.body.classList.add('logged-in');
      const overlay = $('loginOverlay');
      if (overlay) overlay.style.display = 'none';
      const main = $('mainContent');
      if (main) main.style.display = 'block';
      initDashboard();
  }

  if ($('eidScheduleVolume')) {
    $('eidScheduleVolume').addEventListener('input', () => {
      if ($('eidScheduleVolumeValue')) $('eidScheduleVolumeValue').textContent = $('eidScheduleVolume').value;
    });
  }
  if ($('eidTakbeerVolume')) {
    $('eidTakbeerVolume').addEventListener('input', () => {
      if ($('eidTakbeerVolumeValue')) $('eidTakbeerVolumeValue').textContent = $('eidTakbeerVolume').value;
    });
  }

  let prayerFetchCounter = 0;
  setInterval(() => {
    // Performance optimization: skip polling if tab is hidden/backgrounded
    if (document.hidden) return;
    
    if ($('mainContent')?.style.display !== 'none') {
      fetchStatus(); // fetchStatus now updates clock and conditional track info internally
      checkSessionTimeout();
      prayerFetchCounter++;
      if (!calendarDownloadActive && prayerFetchCounter % 6 === 0 && appState.activeTab === 'dashboard') fetchPrayerTimes();
    }
  }, 3000);
});

function togglePasswordVisibility(inputId, iconId) {
  const input = $(inputId);
  const icon = $(iconId);
  if (!input || !icon) return;
  if (input.type === 'password') {
    input.type = 'text';
    icon.classList.remove('fa-eye');
    icon.classList.add('fa-eye-slash');
  } else {
    input.type = 'password';
    icon.classList.remove('fa-eye-slash');
    icon.classList.add('fa-eye');
  }
}

// Event Log Management Logic
let allLogs = [];

function fetchLogs() {
  const tbody = $('logsTableBody');
  if (tbody) {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 20px; font-weight: bold; color: var(--primary-blue);">جاري تحميل سجل الأحداث...</td></tr>';
  }
  
  fetch('/api/logs?limit=200')
    .then(res => res.json())
    .then(data => {
      allLogs = Array.isArray(data) ? data : [];
      filterLogs();
    })
    .catch(err => {
      console.error('Error fetching logs:', err);
      if (tbody) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; color: var(--color-danger); padding: 20px; font-weight: bold;">فشل في تحميل السجلات. تأكد من اتصالك بالشبكة.</td></tr>';
      }
    });
}

function filterLogs() {
  const searchQuery = ($('logSearchInput')?.value || '').toLowerCase().trim();
  const levelFilter = $('logLevelFilter')?.value || 'ALL';
  const tbody = $('logsTableBody');
  const noData = $('logsNoData');
  
  if (!tbody) return;
  
  const filtered = allLogs.filter(log => {
    // Level filter
    if (levelFilter !== 'ALL' && log.level.toUpperCase() !== levelFilter.toUpperCase()) {
      return false;
    }
    // Search query filter
    if (searchQuery) {
      const msgMatch = (log.message || '').toLowerCase().includes(searchQuery);
      const catMatch = (log.category || '').toLowerCase().includes(searchQuery);
      const tsMatch = (log.timestamp || '').toLowerCase().includes(searchQuery);
      return msgMatch || catMatch || tsMatch;
    }
    return true;
  });
  
  // Sort in reverse chronological order (newest first)
  filtered.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
  
  tbody.innerHTML = '';
  if (filtered.length === 0) {
    if (noData) noData.style.display = 'block';
    return;
  }
  if (noData) noData.style.display = 'none';
  
  filtered.forEach(log => {
    const tr = document.createElement('tr');
    
    const tdTs = document.createElement('td');
    tdTs.textContent = log.timestamp;
    tdTs.style.padding = '12px 10px';
    tr.appendChild(tdTs);
    
    const tdLvl = document.createElement('td');
    tdLvl.style.textAlign = 'center';
    tdLvl.style.padding = '12px 10px';
    const badge = document.createElement('span');
    badge.className = `log-level-badge log-level-${log.level.toLowerCase()}`;
    badge.textContent = log.level;
    tdLvl.appendChild(badge);
    tr.appendChild(tdLvl);
    
    const tdCat = document.createElement('td');
    tdCat.textContent = log.category;
    tdCat.style.padding = '12px 10px';
    tr.appendChild(tdCat);
    
    const tdMsg = document.createElement('td');
    tdMsg.textContent = log.message;
    tdMsg.style.padding = '12px 10px';
    tdMsg.style.whiteSpace = 'normal';
    tdMsg.style.wordBreak = 'break-all';
    tr.appendChild(tdMsg);
    
    const tdHeap = document.createElement('td');
    tdHeap.textContent = Number(log.freeHeap).toLocaleString();
    tdHeap.style.padding = '12px 10px';
    tdHeap.style.textAlign = 'left';
    tr.appendChild(tdHeap);
    
    const tdUptime = document.createElement('td');
    tdUptime.textContent = Number(log.uptime).toLocaleString();
    tdUptime.style.padding = '12px 10px';
    tdUptime.style.textAlign = 'left';
    tr.appendChild(tdUptime);
    
    tbody.appendChild(tr);
  });
}

function clearLogs() {
  const pass = prompt('الرجاء إدخال كلمة مرور الإدارة لمسح جميع السجلات:');
  if (pass === null) return;
  if (!pass.trim()) {
    alert('كلمة المرور فارغة!');
    return;
  }
  
  const formData = new FormData();
  formData.append('password', pass);
  
  fetch('/api/logs', {
    method: 'DELETE',
    body: formData
  })
  .then(res => res.json())
  .then(data => {
    if (data.ok) {
      alert('تم مسح جميع السجلات بنجاح.');
      allLogs = [];
      filterLogs();
    } else {
      alert('فشل المسح: ' + (data.error || 'كلمة المرور غير صحيحة'));
    }
  })
  .catch(err => {
    console.error('Error clearing logs:', err);
    alert('حدث خطأ أثناء محاولة مسح السجلات.');
  });
}

function exportLogs(format) {
  if (allLogs.length === 0) {
    alert('لا توجد سجلات لتصديرها!');
    return;
  }
  
  let output = '';
  let filename = `system_logs_${new Date().toISOString().split('T')[0]}`;
  let mimeType = 'text/plain';
  
  const searchQuery = ($('logSearchInput')?.value || '').toLowerCase().trim();
  const levelFilter = $('logLevelFilter')?.value || 'ALL';
  const filtered = allLogs.filter(log => {
    if (levelFilter !== 'ALL' && log.level.toUpperCase() !== levelFilter.toUpperCase()) return false;
    if (searchQuery) {
      const msgMatch = (log.message || '').toLowerCase().includes(searchQuery);
      const catMatch = (log.category || '').toLowerCase().includes(searchQuery);
      const tsMatch = (log.timestamp || '').toLowerCase().includes(searchQuery);
      return msgMatch || catMatch || tsMatch;
    }
    return true;
  });
  
  filtered.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
  
  if (format === 'csv') {
    filename += '.csv';
    mimeType = 'text/csv';
    output = '\uFEFF'; // Excel Arabic support BOM
    output += 'Timestamp,Level,Category,Message,Free Heap (Bytes),Uptime (Seconds)\n';
    filtered.forEach(log => {
      const escapedMsg = `"${(log.message || '').replace(/"/g, '""')}"`;
      const escapedCat = `"${(log.category || '').replace(/"/g, '""')}"`;
      output += `${log.timestamp},${log.level},${escapedCat},${escapedMsg},${log.freeHeap},${log.uptime}\n`;
    });
  } else {
    filename += '.txt';
    filtered.forEach(log => {
      output += `[${log.timestamp}] [${log.level}] [${log.category}] ${log.message} (Heap: ${log.freeHeap}, Uptime: ${log.uptime}s)\r\n`;
    });
  }
  
  const blob = new Blob([output], { type: `${mimeType};charset=utf-8;` });
  const link = document.createElement('a');
  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}

function downloadRawLogFile() {
  const link = document.createElement('a');
  link.href = '/api/logs/download';
  link.download = '';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// ==========================================
// MP3QURAN LIVE RADIO INTEGRATION
// ==========================================

let radioLanguage = 'ar';
let allRadiosList = [
  {
    "id": 99999,
    "name": "إذاعة القرآن الكريم من القاهرة",
    "url": "http://stream.radiojar.com/8s5u5tpdtwzuv"
  },
  {
    "id": 1,
    "name": "إبراهيم الأخضر",
    "url": "https://backup.qurango.net/radio/ibrahim_alakdar",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 2,
    "name": "شيخ أبو بكر الشاطري",
    "url": "https://backup.qurango.net/radio/shaik_abu_bakr_al_shatri",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 3,
    "name": "أحمد العجمي",
    "url": "https://backup.qurango.net/radio/ahmad_alajmy",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 4,
    "name": "أحمد الحواشي",
    "url": "https://backup.qurango.net/radio/ahmad_alhawashi",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 5,
    "name": "أحمد صابر",
    "url": "https://backup.qurango.net/radio/ahmad_saber",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 6,
    "name": "أحمد نعينع",
    "url": "https://backup.qurango.net/radio/ahmad_nauina",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 7,
    "name": "أكرم العلاقمي",
    "url": "https://backup.qurango.net/radio/akram_alalaqmi",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 8,
    "name": "إدريس أبكر",
    "url": "https://backup.qurango.net/radio/idrees_abkr",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 9,
    "name": "الزين محمد أحمد",
    "url": "https://backup.qurango.net/radio/alzain_mohammad_ahmad",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 10,
    "name": "القارئ ياسين",
    "url": "https://backup.qurango.net/radio/alqaria_yassen",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 11,
    "name": "العيون الكوشي",
    "url": "https://backup.qurango.net/radio/aloyoon_alkoshi",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 12,
    "name": "توفيق الصايغ",
    "url": "https://backup.qurango.net/radio/tawfeeq_assayegh",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 13,
    "name": "جمال شاكر عبدالله",
    "url": "https://backup.qurango.net/radio/jamal_shaker_abdullah",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 14,
    "name": "خالد القحطاني",
    "url": "https://backup.qurango.net/radio/khaled_alqahtani",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 15,
    "name": "خالد عبدالكافي",
    "url": "https://backup.qurango.net/radio/khalid_abdulkafi",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 16,
    "name": "خليفة الطنيجي",
    "url": "https://backup.qurango.net/radio/khalifa_altunaiji",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 17,
    "name": "سعد الغامدي",
    "url": "https://backup.qurango.net/radio/saad_alghamdi",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 18,
    "name": "سعود الشريم",
    "url": "https://backup.qurango.net/radio/saud_alshuraim",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 19,
    "name": "سهل ياسين",
    "url": "https://backup.qurango.net/radio/sahl_yassin",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 20,
    "name": "زكي داغستاني",
    "url": "https://backup.qurango.net/radio/zaki_daghistani",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 21,
    "name": "سيد رمضان",
    "url": "https://backup.qurango.net/radio/sayeed_ramadan",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 22,
    "name": "شيرزاد عبدالرحمن طاهر",
    "url": "https://backup.qurango.net/radio/shirazad_taher",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 23,
    "name": "صابر عبدالحكم",
    "url": "https://backup.qurango.net/radio/saber_abdulhakm",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 24,
    "name": "صلاح البدير",
    "url": "https://backup.qurango.net/radio/salah_albudair",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 25,
    "name": "صلاح الهاشم",
    "url": "https://backup.qurango.net/radio/salah_alhashim",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 26,
    "name": "صلاح بو خاطر",
    "url": "https://backup.qurango.net/radio/slaah_bukhatir",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 27,
    "name": "عادل ريان",
    "url": "https://backup.qurango.net/radio/adel_ryyan",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 28,
    "name": "عبدالبارئ الثبيتي",
    "url": "https://backup.qurango.net/radio/abdelbari_altoubayti",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 29,
    "name": "عبدالبارئ محمد",
    "url": "https://backup.qurango.net/radio/abdulbari_mohammad",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 30,
    "name": "عبدالباسط عبدالصمد",
    "url": "https://backup.qurango.net/radio/abdulbasit_abdulsamad_mojawwad",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 31,
    "name": "عبدالباسط عبدالصمد",
    "url": "https://backup.qurango.net/radio/abdulbasit_abdulsamad_warsh",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 32,
    "name": "عبدالباسط عبدالصمد",
    "url": "https://backup.qurango.net/radio/abdulbasit_abdulsamad",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 33,
    "name": "عبدالرحمن السديس",
    "url": "https://backup.qurango.net/radio/abdulrahman_alsudaes",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 34,
    "name": "عبدالعزيز الأحمد",
    "url": "https://backup.qurango.net/radio/abdul_aziz_alahmad",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 35,
    "name": "عبدالله المطرود",
    "url": "https://backup.qurango.net/radio/abdullah_almattrod",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 36,
    "name": "عبدالله بصفر",
    "url": "https://backup.qurango.net/radio/abdullah_basfer",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 37,
    "name": "عبدالله خياط",
    "url": "https://backup.qurango.net/radio/abdullah_khayyat",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 38,
    "name": "عبدالله عواد الجهني",
    "url": "https://backup.qurango.net/radio/abdullah_aljohany",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 39,
    "name": "عبدالرشيد صوفي",
    "url": "https://backup.qurango.net/radio/abdulrasheed_soufi_khalaf",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 40,
    "name": "عبدالرشيد صوفي",
    "url": "https://backup.qurango.net/radio/abdulrasheed_soufi_assosi",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 41,
    "name": "عبدالمحسن الحارثي",
    "url": "https://backup.qurango.net/radio/abdulmohsin_alharthy",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 42,
    "name": "عبدالمحسن القاسم",
    "url": "https://backup.qurango.net/radio/abdulmohsen_alqasim",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 43,
    "name": "عبدالمحسن العبيكان",
    "url": "https://backup.qurango.net/radio/abdulmohsin_alobaikan",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 44,
    "name": "عبدالهادي أحمد كناكري",
    "url": "https://backup.qurango.net/radio/abdulhadi_kanakeri",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 45,
    "name": "عبدالودود حنيف",
    "url": "https://backup.qurango.net/radio/abdulwadood_haneef",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 46,
    "name": "علي بن عبدالرحمن الحذيفي",
    "url": "https://backup.qurango.net/radio/ali_alhuthaifi",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 47,
    "name": "علي الحذيفي",
    "url": "https://backup.qurango.net/radio/ali_alhuthaifi_qalon",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 48,
    "name": "علي جابر",
    "url": "https://backup.qurango.net/radio/ali_jaber",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 49,
    "name": "علي حجاج السويسي",
    "url": "https://backup.qurango.net/radio/ali_hajjaj_alsouasi",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 50,
    "name": "عماد زهير حافظ",
    "url": "https://backup.qurango.net/radio/emad_hafez",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 51,
    "name": "عمر القزابري",
    "url": "https://backup.qurango.net/radio/omar_alqazabri",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 52,
    "name": "فارس عباد",
    "url": "https://backup.qurango.net/radio/fares_abbad",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 53,
    "name": "ناصر القطامي",
    "url": "https://backup.qurango.net/radio/nasser_alqatami",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 54,
    "name": "نبيل الرفاعي",
    "url": "https://backup.qurango.net/radio/nabil_al_rifay",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 55,
    "name": "نعمة الحسان",
    "url": "https://backup.qurango.net/radio/neamah_alhassan",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 56,
    "name": "هاني الرفاعي",
    "url": "https://backup.qurango.net/radio/hani_arrifai",
    "recent_date": "2020-04-25 22:04:04"
  },
  {
    "id": 57,
    "name": "وليد النائحي",
    "url": "https://backup.qurango.net/radio/waleed_alnaehi",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 58,
    "name": "ياسر الدوسري",
    "url": "https://backup.qurango.net/radio/yasser_aldosari",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 59,
    "name": "ياسر القرشي",
    "url": "https://backup.qurango.net/radio/yasser_alqurashi",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 60,
    "name": "ياسر المزروعي",
    "url": "https://backup.qurango.net/radio/yasser_almazroyee",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 61,
    "name": "يحيى حوا",
    "url": "https://backup.qurango.net/radio/yahya_hawwa",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 62,
    "name": "يوسف الشويعي",
    "url": "https://backup.qurango.net/radio/yousef_alshoaey",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 63,
    "name": "ماهر المعيقلي",
    "url": "https://backup.qurango.net/radio/maher",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 64,
    "name": "محمد الطبلاوي",
    "url": "https://backup.qurango.net/radio/mohammad_altablaway",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 65,
    "name": "محمد اللحيدان",
    "url": "https://backup.qurango.net/radio/mohammed_allohaidan",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 66,
    "name": "محمد أيوب",
    "url": "https://backup.qurango.net/radio/mohammed_ayyub",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 67,
    "name": "محمد صالح عالم شاه",
    "url": "https://backup.qurango.net/radio/mohammad_saleh_alim_shah",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 68,
    "name": "محمد جبريل",
    "url": "https://backup.qurango.net/radio/mohammed_jibreel",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 69,
    "name": "محمد صديق المنشاوي",
    "url": "https://backup.qurango.net/radio/mohammed_siddiq_alminshawi",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 70,
    "name": "محمد صديق المنشاوي",
    "url": "https://backup.qurango.net/radio/mohammed_siddiq_alminshawi_mojawwad",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 71,
    "name": "محمد عبدالكريم",
    "url": "https://backup.qurango.net/radio/mohammad_abdullkarem",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 72,
    "name": "محمد عبدالحكيم سعيد العبدالله",
    "url": "https://backup.qurango.net/radio/mohammad_alabdullah_albizi",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 73,
    "name": "محمد عبدالحكيم سعيد العبدالله",
    "url": "https://backup.qurango.net/radio/mohammad_alabdullah_aldorai",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 74,
    "name": "محمود خليل الحصري",
    "url": "https://backup.qurango.net/radio/mahmoud_khalil_alhussary",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 75,
    "name": "محمود خليل الحصري",
    "url": "https://backup.qurango.net/radio/mahmoud_khalil_alhussary_mojawwad",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 76,
    "name": "محمود خليل الحصري",
    "url": "https://backup.qurango.net/radio/mahmoud_khalil_alhussary_warsh",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 77,
    "name": "محمود علي البنا",
    "url": "https://backup.qurango.net/radio/mahmoud_ali__albanna",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 78,
    "name": "محمود علي البنا",
    "url": "https://backup.qurango.net/radio/mahmoud_ali__albanna_mojawwad",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 79,
    "name": "مشاري العفاسي",
    "url": "https://backup.qurango.net/radio/mishary_alafasi",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 80,
    "name": "مصطفى إسماعيل",
    "url": "https://backup.qurango.net/radio/mustafa_ismail",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 81,
    "name": "مصطفى اللاهوني",
    "url": "https://backup.qurango.net/radio/mustafa_allahoni",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 82,
    "name": "مصطفى رعد العزاوي",
    "url": "https://backup.qurango.net/radio/mustafa_raad_alazawy",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 83,
    "name": "مفتاح السلطني",
    "url": "https://backup.qurango.net/radio/muftah_alsaltany_aldori_an_abi_amr",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 84,
    "name": "ماهر شخاشيرو",
    "url": "https://backup.qurango.net/radio/maher_shakhashero",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 85,
    "name": "محمود الشيمي",
    "url": "https://backup.qurango.net/radio/mahmood_alsheimy",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 86,
    "name": "خالد المهنا",
    "url": "https://backup.qurango.net/radio/khalid_almohana",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 87,
    "name": "عادل الكلباني",
    "url": "https://backup.qurango.net/radio/adel_alkhalbany",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 88,
    "name": "موسى بلال",
    "url": "https://backup.qurango.net/radio/mousa_bilal",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 89,
    "name": "حاتم فريد الواعر",
    "url": "https://backup.qurango.net/radio/hatem_fareed_alwaer",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 90,
    "name": "محمود الرفاعي",
    "url": "https://backup.qurango.net/radio/mahmood_al_rifai",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 91,
    "name": "ابراهيم الدوسري",
    "url": "https://backup.qurango.net/radio/ibrahim_aldosari",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 92,
    "name": "مفتاح السلطني",
    "url": "https://backup.qurango.net/radio/muftah_alsaltany_aldorai",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 93,
    "name": "جمعان العصيمي",
    "url": "https://backup.qurango.net/radio/jamaan_alosaimi",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 94,
    "name": "مفتاح السلطني",
    "url": "https://backup.qurango.net/radio/muftah_alsaltany",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 95,
    "name": "يوسف بن نوح أحمد",
    "url": "https://backup.qurango.net/radio/yousef_bin_noah_ahmad",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 96,
    "name": "مفتاح السلطني",
    "url": "https://backup.qurango.net/radio/muftah_alsaltany_ibn_thakwan_an_ibn_amr",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 97,
    "name": "معيض الحارثي",
    "url": "https://backup.qurango.net/radio/moeedh_alharthi",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 98,
    "name": "محمد رشاد الشريف",
    "url": "https://backup.qurango.net/radio/mohammad_rashad_alshareef",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 99,
    "name": "أحمد خضر الطرابلسي",
    "url": "https://backup.qurango.net/radio/ahmad_khader_altarabulsi",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 100,
    "name": "أحمد الطرابلسي",
    "url": "https://backup.qurango.net/radio/ahmed_altrabulsi",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 101,
    "name": "عبدالله الكندري",
    "url": "https://backup.qurango.net/radio/abdullah_alkandari",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 102,
    "name": "أحمد عامر",
    "url": "https://backup.qurango.net/radio/ahmed_amer",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 103,
    "name": "محمد عثمان خان",
    "url": "https://backup.qurango.net/radio/mohammed_osman_khan",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 104,
    "name": "الدوكالي محمد العالم",
    "url": "https://backup.qurango.net/radio/addokali_mohammad_alalim",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 105,
    "name": "محمد عبدالكريم",
    "url": "https://backup.qurango.net/radio/mohammad_abdullkarem_alasbahani",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 106,
    "name": "الفاتح محمد الزبير",
    "url": "https://backup.qurango.net/radio/alfateh_alzubair",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 107,
    "name": "طارق عبدالغني دعوب",
    "url": "https://backup.qurango.net/radio/tareq_abdulgani_daawob",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 108,
    "name": "العامة - متنوعة لمختلف القراء",
    "url": "https://backup.qurango.net/radio/mix",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 109,
    "name": "تلاوات خاشعة-",
    "url": "https://backup.qurango.net/radio/salma",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 110,
    "name": "تكبيرات العيد",
    "url": "https://backup.qurango.net/radio/eid",
    "recent_date": "2020-06-27 02:41:26"
  },
  {
    "id": 111,
    "name": "عبدالرحمن الماجد",
    "url": "https://backup.qurango.net/radio/abdulrahman_almajed",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 113,
    "name": "الفتاوى العامة",
    "url": "https://backup.qurango.net/radio/fatwa",
    "recent_date": "2020-06-27 02:39:55"
  },
  {
    "id": 114,
    "name": "الرقية الشرعية",
    "url": "https://backup.qurango.net/radio/roqiah",
    "recent_date": "2020-06-27 02:38:21"
  },
  {
    "id": 115,
    "name": "سورة البقرة - لعدد من القراء---",
    "url": "https://backup.qurango.net/radio/albaqarah",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 116,
    "name": "تفسير القران الكريم--",
    "url": "https://backup.qurango.net/radio/tafseer",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 117,
    "name": "خالد الجليل",
    "url": "https://backup.qurango.net/radio/khalid_aljileel",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 118,
    "name": "ناصر الماجد",
    "url": "https://backup.qurango.net/radio/nasser_almajed",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 119,
    "name": "هيثم الجدعاني",
    "url": "https://backup.qurango.net/radio/hitham_aljadani",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 120,
    "name": "أحمد خليل شاهين",
    "url": "https://backup.qurango.net/radio/ahmad_shaheen",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 121,
    "name": "عبدالله الموسى",
    "url": "https://backup.qurango.net/radio/abdullah_almousa",
    "recent_date": "2020-06-27 02:46:31"
  },
  {
    "id": 122,
    "name": "عبدالله الخلف",
    "url": "https://backup.qurango.net/radio/abdullah_alkhalaf",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 123,
    "name": "تراتيل قصيرة متميزة-",
    "url": "https://backup.qurango.net/radio/tarateel",
    "recent_date": "2020-04-25 22:04:05"
  },
  {
    "id": 139,
    "name": "ماجد الزامل",
    "url": "https://backup.qurango.net/radio/majed_alzamel",
    "recent_date": "2020-06-27 01:43:46"
  },
  {
    "id": 217,
    "name": "بندر بليلة",
    "url": "https://backup.qurango.net/radio/bandar_balilah",
    "recent_date": "2021-09-06 22:14:27"
  },
  {
    "id": 248,
    "name": "ناصر العصفور",
    "url": "https://backup.qurango.net/radio/nasser_alosfor",
    "recent_date": "2020-05-05 02:27:02"
  },
  {
    "id": 261,
    "name": "محمد أيوب - قراءة مميزة-",
    "url": "https://backup.qurango.net/radio/ayyoub2",
    "recent_date": "2020-06-27 02:35:33"
  },
  {
    "id": 265,
    "name": "أحمد ديبان",
    "url": "https://backup.qurango.net/radio/ahmad_deban",
    "recent_date": "2020-06-27 01:46:13"
  },
  {
    "id": 274,
    "name": "أذاعة محمد أبوسنينة",
    "url": "https://backup.qurango.net/radio/sneineh",
    "recent_date": "2022-08-17 16:40:49"
  },
  {
    "id": 275,
    "name": "محمد الأمين قنيوة",
    "url": "https://backup.qurango.net/radio/qeniwa",
    "recent_date": "2022-08-17 16:44:08"
  },
  {
    "id": 287,
    "name": "عبدالرحمن الشحات",
    "url": "https://backup.qurango.net/radio/a_alshahhat",
    "recent_date": "2022-09-20 17:28:01"
  },
  {
    "id": 307,
    "name": "عبدالعزيز سحيم",
    "url": "https://backup.qurango.net/radio/a_sheim",
    "recent_date": "2023-10-11 04:18:00"
  },
  {
    "id": 10902,
    "name": "آيات السكينة",
    "url": "https://backup.qurango.net/radio/sakeenah",
    "recent_date": "2020-07-17 14:39:15"
  },
  {
    "id": 10903,
    "name": "صور من حياة الصحابة والتابعين رضوان الله عليهم---",
    "url": "https://backup.qurango.net/radio/sahabah",
    "recent_date": "2020-07-17 14:40:45"
  },
  {
    "id": 10904,
    "name": "المختصر في تفسير القرآن الكريم",
    "url": "https://backup.qurango.net/radio/mukhtasartafsir",
    "recent_date": "2021-03-25 17:28:18"
  },
  {
    "id": 10906,
    "name": "أذكار الصباح",
    "url": "https://backup.qurango.net/radio/athkar_sabah",
    "recent_date": "2021-08-27 12:48:42"
  },
  {
    "id": 10907,
    "name": "أذكار المساء",
    "url": "https://backup.qurango.net/radio/athkar_masa",
    "recent_date": "2021-08-27 12:49:07"
  },
  {
    "id": 21114,
    "name": "في ظلال السيرة النبوية - 400 حلقة عن سيرة نبينا محمد صلى الله عليه وسلم",
    "url": "https://backup.qurango.net/radio/fi_zilal_alsiyra",
    "recent_date": "2021-09-27 01:36:41"
  },
  {
    "id": 21115,
    "name": "المختصر في السيرة النبوية",
    "url": "https://backup.qurango.net/radio/almukhtasar_fi_alsiyra",
    "recent_date": "2025-05-30 11:38:35"
  },
  {
    "id": 21116,
    "name": "كتاب الاختيارات الفقهية في مسائل العبادات والمعاملات",
    "url": "https://backup.qurango.net/radio/alaikhtiarat_alfiqhayh_bin_baz",
    "recent_date": "2022-02-13 23:48:06"
  },
  {
    "id": 21117,
    "name": "تفسير القران الكريم-الخلاصة من تفسير الطبري",
    "url": "https://backup.qurango.net/radio/tabri",
    "recent_date": "2023-12-02 20:42:00"
  },
  {
    "id": 109038,
    "name": "صالح الهبدان",
    "url": "https://backup.qurango.net/radio/saleh_alhabdan",
    "recent_date": "2020-06-27 01:47:04"
  },
  {
    "id": 109039,
    "name": "ترجمة معاني القرآن باللغة الأوردية - عبدالباسط عبدالصمد",
    "url": "https://backup.qurango.net/radio/translation_quran_urdu_basit",
    "recent_date": "2024-04-13 04:18:10"
  },
  {
    "id": 109040,
    "name": "ترجمة معاني القرآن باللغة الأسبانية",
    "url": "https://backup.qurango.net/radio/translation_quran_spanish_afs",
    "recent_date": "2024-04-13 04:21:03"
  },
  {
    "id": 109041,
    "name": "ترجمة معاني القرآن باللغة الألبانية",
    "url": "https://backup.qurango.net/radio/translation_quran_albanian",
    "recent_date": "2024-04-13 04:22:03"
  },
  {
    "id": 109042,
    "name": "ترجمة معاني القرآن باللغة الألمانية",
    "url": "https://backup.qurango.net/radio/translation_quran_german",
    "recent_date": "2024-04-13 04:23:33"
  },
  {
    "id": 109043,
    "name": "ترجمة معاني القرآن باللغة الأمازيغية",
    "url": "https://backup.qurango.net/radio/translation_quran_tamazight",
    "recent_date": "2024-04-13 04:25:33"
  },
  {
    "id": 109044,
    "name": "ترجمة معاني القرآن باللغة الأوردية",
    "url": "https://backup.qurango.net/radio/translation_quran_urdu_sds_shur",
    "recent_date": "2024-04-13 04:26:22"
  },
  {
    "id": 109045,
    "name": "ترجمة معاني القرآن باللغة الأوردية",
    "url": "https://backup.qurango.net/radio/translation_quran_urdu_minsh",
    "recent_date": "2024-04-13 04:27:09"
  },
  {
    "id": 109046,
    "name": "ترجمة معاني القرآن باللغة الإنجليزية",
    "url": "https://backup.qurango.net/radio/translation_quran_english_basit",
    "recent_date": "2024-04-13 04:28:32"
  },
  {
    "id": 109047,
    "name": "ترجمة معاني القرآن باللغة الإنجليزية",
    "url": "https://backup.qurango.net/radio/translation_quran_english_bsfr",
    "recent_date": "2024-04-13 04:29:17"
  },
  {
    "id": 109048,
    "name": "ترجمة معاني القرآن باللغة الإنجليزية -ترجمة والك-",
    "url": "https://backup.qurango.net/radio/translation_quran_english_walk_basit",
    "recent_date": "2024-04-13 04:30:25"
  },
  {
    "id": 109049,
    "name": "ترجمة معاني القرآن باللغة البرتغالية",
    "url": "https://backup.qurango.net/radio/translation_quran_portuguese",
    "recent_date": "2024-04-13 04:31:18"
  },
  {
    "id": 109050,
    "name": "ترجمة معاني القرآن باللغة البوسنية",
    "url": "https://backup.qurango.net/radio/translation_quran_bosnia",
    "recent_date": "2024-04-13 04:32:27"
  },
  {
    "id": 109051,
    "name": "ترجمة معاني القرآن باللغة التركية",
    "url": "https://backup.qurango.net/radio/translation_quran_turkish",
    "recent_date": "2024-04-13 04:33:38"
  },
  {
    "id": 109052,
    "name": "ترجمة معاني القرآن باللغة الروسية",
    "url": "https://backup.qurango.net/radio/translation_quran_Russia",
    "recent_date": "2024-04-13 04:35:33"
  },
  {
    "id": 109053,
    "name": "ترجمة معاني القرآن باللغة الصينية",
    "url": "https://backup.qurango.net/radio/translation_quran_chinese",
    "recent_date": "2024-04-13 04:36:48"
  },
  {
    "id": 109054,
    "name": "ترجمة معاني القرآن باللغة الفارسية",
    "url": "https://backup.qurango.net/radio/translation_quran_farsi",
    "recent_date": "2024-04-13 05:07:34"
  },
  {
    "id": 109055,
    "name": "ترجمة معاني القرآن باللغة الفرنسية",
    "url": "https://backup.qurango.net/radio/translation_quran_french",
    "recent_date": "2024-04-13 05:08:08"
  },
  {
    "id": 109056,
    "name": "ترجمة معاني القرآن باللغة الكردية",
    "url": "https://backup.qurango.net/radio/translation_quran_kurdish",
    "recent_date": "2024-04-13 05:10:28"
  },
  {
    "id": 109057,
    "name": "ترجمة معاني القرآن باللغة الكورية",
    "url": "https://backup.qurango.net/radio/translation_quran_Korean",
    "recent_date": "2024-04-13 05:10:52"
  },
  {
    "id": 109058,
    "name": "ترجمة معاني القرآن باللغة المجرية",
    "url": "https://backup.qurango.net/radio/translation_quran_hungarian",
    "recent_date": "2024-04-13 05:16:54"
  },
  {
    "id": 109059,
    "name": "ترجمة معاني القرآن باللغة اليونانية",
    "url": "https://backup.qurango.net/radio/translation_quran_greek",
    "recent_date": "2024-04-13 05:17:34"
  },
  {
    "id": 109060,
    "name": "سورة الملك",
    "url": "https://backup.qurango.net/radio/Surah_Al-Mulk",
    "recent_date": "2024-04-13 05:32:01"
  },
  {
    "id": 109061,
    "name": "فضل شهر رمضان",
    "url": "https://backup.qurango.net/radio/ramadan",
    "recent_date": "2024-04-13 05:33:01"
  },
  {
    "id": 109062,
    "name": "ترجمة معاني القرآن باللغة الهوسا",
    "url": "https://backup.qurango.net/radio/Translation_Quran_Hausa",
    "recent_date": "2024-09-26 00:18:57"
  },
  {
    "id": 109066,
    "name": "صحيح مسلم",
    "url": "https://backup.qurango.net/radio/saheh-muslim",
    "recent_date": "2025-05-20 18:30:06"
  },
  {
    "id": 109067,
    "name": "صحيح البخاري",
    "url": "https://backup.qurango.net/radio/saheh-bokharee",
    "recent_date": "2025-05-20 18:34:32"
  },
  {
    "id": 109069,
    "name": "***قصص الأنبياء***",
    "url": "https://backup.qurango.net/radio/alanbiya",
    "recent_date": "2025-07-04 18:34:32"
  },
  {
    "id": 109073,
    "name": "رياض الصالحين",
    "url": "https://backup.qurango.net/radio/riyad",
    "recent_date": "2025-07-20 13:36:55"
  },
  {
    "id": 109074,
    "name": "عبدالله البعيجان",
    "url": "https://backup.qurango.net/radio/buajan",
    "recent_date": "2025-07-20 19:47:08"
  },
  {
    "id": 109075,
    "name": "أحمد طالب بن حميد",
    "url": "https://backup.qurango.net/radio/a_binhameed",
    "recent_date": "2025-07-20 19:54:30"
  },
  {
    "id": 109076,
    "name": "تفسير غريب القرآن",
    "url": "https://backup.qurango.net/radio/gareeb-quran",
    "recent_date": "2025-09-06 11:00:48"
  },
  {
    "id": 109077,
    "name": "بدر التركي",
    "url": "https://backup.qurango.net/radio/bader",
    "recent_date": "2025-09-12 19:09:35"
  },
  {
    "id": 109078,
    "name": "هزاع البلوشي",
    "url": "https://backup.qurango.net/radio/hazza",
    "recent_date": "2025-09-12 19:22:27"
  },
  {
    "id": 109082,
    "name": "إذاعة القرآن الكريم - السعودية",
    "url": "https://stream.radiojar.com/0tpy1h0kxtzuv",
    "recent_date": "2026-02-13 17:41:50"
  },
  {
    "id": 109083,
    "name": "الشمائل المحمدية",
    "url": "https://backup.qurango.net/radio/shmaeel",
    "recent_date": "2026-04-08 10:58:22"
  },
  {
    "id": 109084,
    "name": "نورين محمد صديق",
    "url": "https://backup.qurango.net/radio/nourin_siddig",
    "recent_date": "2026-06-12 15:14:52"
  }
];
let hasLoadedLiveRadios = false;

const defaultOfflineRadios = {
  ar: allRadiosList,
  eng: [
    { id: 99999, name: "Holy Quran Radio from Cairo", url: "http://stream.radiojar.com/8s5u5tpdtwzuv" },
    { id: 109082, name: "Holy Quran Radio from Saudi Arabia", url: "https://stream.radiojar.com/0tpy1h0kxtzuv" },
    { id: 108, name: "General Radio - Various Recitations", url: "https://backup.qurango.net/radio/mix" },
    { id: 110, name: "Eid Takbeer", url: "https://backup.qurango.net/radio/eid" },
    { id: 114, name: "Sharia Ruqyah", url: "https://backup.qurango.net/radio/roqiah" },
    { id: 116, name: "Quran Tafseer", url: "https://backup.qurango.net/radio/tafseer" },
    { id: 10902, name: "Verses of Serenity", url: "https://backup.qurango.net/radio/sakeenah" },
    { id: 10906, name: "Athkar Morning", url: "https://backup.qurango.net/radio/athkar_sabah" },
    { id: 10907, name: "Athkar Evening", url: "https://backup.qurango.net/radio/athkar_masa" },
    { id: 79, name: "Radio Mishary Alafasi", url: "https://backup.qurango.net/radio/mishary_alafasi" },
    { id: 33, name: "Radio Abdulrahman Alsudaes", url: "https://backup.qurango.net/radio/abdulrahman_alsudaes" },
    { id: 63, name: "Radio Maher Al Meaqli", url: "https://backup.qurango.net/radio/maher" },
    { id: 30, name: "Radio Abdulbasit Abdulsamad", url: "https://backup.qurango.net/radio/abdulbasit_abdulsamad_mojawwad" }
  ]
};

function toggleAlertSourceType() {
  const sourceType = document.querySelector('input[name="singleAlertSourceType"]:checked')?.value || 'local';
  if (sourceType === 'radio') {
    if ($('singleAlertLocalFileContainer')) $('singleAlertLocalFileContainer').style.display = 'none';
    if ($('singleAlertRadioContainer')) $('singleAlertRadioContainer').style.display = 'block';
    if (allRadiosList.length === 0) {
      allRadiosList = defaultOfflineRadios[radioLanguage] || defaultOfflineRadios.ar;
    }
    populateRadioDropdowns();
    if (!hasLoadedLiveRadios) {
      fetchRadiosFromApi();
    }
  } else {
    if ($('singleAlertLocalFileContainer')) $('singleAlertLocalFileContainer').style.display = 'block';
    if ($('singleAlertRadioContainer')) $('singleAlertRadioContainer').style.display = 'none';
  }
  updateRadioPrayerOverrideVisibility();
}

function updateRadioPrayerOverrideVisibility() {
  const isRadioSource = document.querySelector('input[name="singleAlertSourceType"]:checked')?.value === 'radio';
  const type = $('singleAlertType')?.value || 'daily';
  const overrideContainer = $('singleAlertRadioPrayerOverrideContainer');
  if (overrideContainer) {
    if (isRadioSource && type === 'prayer_relative') {
      overrideContainer.style.display = 'block';
    } else {
      overrideContainer.style.display = 'none';
      if ($('singleAlertSkipAdhan')) $('singleAlertSkipAdhan').checked = false;
      if ($('singleAlertSkipIqama')) $('singleAlertSkipIqama').checked = false;
    }
  }
}

function loadRadioList() {
  if (allRadiosList.length === 0) {
    fetchRadiosFromApi();
  } else {
    renderRadioList(allRadiosList);
  }
}

function fetchRadiosFromApi(force = false) {
  const statusTxt = $('radioStatusText');
  if (statusTxt) statusTxt.textContent = "جاري تحميل الإذاعات...";

  if (!force && hasLoadedLiveRadios && allRadiosList.length > 20) {
    renderRadioList(allRadiosList);
    return;
  }

  const url = `https://www.mp3quran.net/api/v3/radios?language=${radioLanguage}`;
  fetch(url)
    .then(response => {
      if (!response.ok) throw new Error("HTTP error " + response.status);
      return response.json();
    })
    .then(data => {
      if (data && data.radios) {
        const cairoRadio = {
          id: 99999,
          name: radioLanguage === 'ar' ? "إذاعة القرآن الكريم من القاهرة" : "Holy Quran Radio from Cairo",
          url: "http://stream.radiojar.com/8s5u5tpdtwzuv"
        };
        allRadiosList = [cairoRadio, ...data.radios];
        hasLoadedLiveRadios = true;
        if (statusTxt) statusTxt.textContent = `تم تحميل ${allRadiosList.length} إذاعة من الإنترنت.`;
        populateRadioDropdowns();
        renderRadioList(allRadiosList);
      } else {
        throw new Error("Invalid API response format");
      }
    })
    .catch(err => {
      console.warn("Failed to fetch radios, falling back to offline list:", err);
      allRadiosList = defaultOfflineRadios[radioLanguage] || defaultOfflineRadios.ar;
      if (statusTxt) statusTxt.textContent = `فشل الاتصال بالإنترنت. تم تحميل القائمة الافتراضية (${allRadiosList.length} إذاعات أوفلاين).`;
      populateRadioDropdowns();
      renderRadioList(allRadiosList);
    });
}

function changeRadioLanguage(lang) {
  radioLanguage = lang;
  allRadiosList = [];
  fetchRadiosFromApi(true);
}

function renderRadioList(radios) {
  const container = $('radioListContainer');
  if (!container) return;

  container.innerHTML = '';
  if (radios.length === 0) {
    container.innerHTML = '<div style="text-align:center; padding:20px; color:rgba(255,255,255,0.5);">لا توجد إذاعات تطابق البحث.</div>';
    return;
  }

  radios.forEach(radio => {
    const item = document.createElement('div');
    item.className = 'glass-card';
    item.style.margin = '8px 0';
    item.style.padding = '10px 15px';
    item.style.display = 'flex';
    item.style.justifyContent = 'space-between';
    item.style.alignItems = 'center';
    item.style.background = 'rgba(255,255,255,0.03)';
    item.style.borderRadius = '8px';
    item.style.border = '1px solid rgba(255,255,255,0.05)';

    const details = document.createElement('div');
    details.style.display = 'flex';
    details.style.flexDirection = 'column';
    details.style.gap = '3px';

    const nameSpan = document.createElement('span');
    nameSpan.style.fontWeight = 'bold';
    nameSpan.style.fontSize = '14px';
    nameSpan.textContent = radio.name;

    const urlSpan = document.createElement('span');
    urlSpan.style.fontSize = '11px';
    urlSpan.style.color = 'rgba(255,255,255,0.4)';
    urlSpan.style.wordBreak = 'break-all';
    urlSpan.textContent = radio.url;

    details.appendChild(nameSpan);
    details.appendChild(urlSpan);

    const actions = document.createElement('div');
    actions.style.display = 'flex';
    actions.style.gap = '8px';

    const playBtn = document.createElement('button');
    playBtn.className = 'btn';
    playBtn.style.margin = '0';
    playBtn.style.padding = '5px 12px';
    playBtn.style.fontSize = '12px';
    playBtn.innerHTML = '<i class="fas fa-play"></i> تشغيل';
    playBtn.onclick = () => playRadioStream(radio.url, radio.name);

    const schedBtn = document.createElement('button');
    schedBtn.className = 'btn btn-secondary';
    schedBtn.style.margin = '0';
    schedBtn.style.padding = '5px 12px';
    schedBtn.style.fontSize = '12px';
    schedBtn.style.background = 'rgba(255,255,255,0.1)';
    schedBtn.innerHTML = '<i class="fas fa-calendar-plus"></i> جدولة';
    schedBtn.onclick = () => scheduleRadioStream(radio.url, radio.name);

    actions.appendChild(playBtn);
    actions.appendChild(schedBtn);

    item.appendChild(details);
    item.appendChild(actions);
    container.appendChild(item);
  });
}

function filterRadioList() {
  const searchVal = ($('radioSearchInput')?.value || '').toLowerCase().trim();
  const countryVal = $('radioCountryFilter')?.value || '';

  const filtered = allRadiosList.filter(radio => {
    const matchesSearch = radio.name.toLowerCase().includes(searchVal) || radio.url.toLowerCase().includes(searchVal);
    
    let matchesCountry = true;
    if (countryVal) {
      // Custom mapping for popular countries in names
      const countryKeywords = {
        "السعودية": [
          "السعودية", "saudi", "المملكة", "الرياض", "مكة", "المدينة", "حرم", "saudia",
          "السديس", "sudaes", "الشريم", "shuraim", "المعيقلي", "muaiqly", "meaqli",
          "الدوسري", "dossari", "القطامي", "qatami", "الحذيفي", "huthaify", "الغامدي", "ghamdi",
          "البدير", "budair", "الجهني", "juhany", "العجمي", "ajmy"
        ],
        "مصر": [
          "مصر", "egypt", "القاهرة", "cairo", "طنطا", "المنصورة",
          "عبد الباسط", "abdulsamad", "abdul_basit", "الحصري", "hussary", "hosary",
          "المنشاوي", "minshawi", "مصطفى إسماعيل", "mustafa ismail", "البنا", "banna",
          "رفعت", "rifat", "rifaat"
        ],
        "الكويت": ["الكويت", "kuwait", "العفاسي", "alafasi"],
        "الإمارات": ["الإمارات", "دبي", "أبوظبي", "dubai", "uae", "sharjah", "الشارقة"],
        "فلسطين": ["فلسطين", "القدس", "palestine", "gaza", "غزة"],
        "الجزائر": ["الجزائر", "algeria", "algerie"],
        "المغرب": ["المغرب", "morocco", "maroc", "الرباط", "الدار البيضاء"],
        "الأردن": ["الأردن", "jordan", "عمان"],
        "اليمن": ["اليمن", "yemen", "صنعاء", "عباد", "abbad"],
        "عمان": ["عمان", "oman", "مسقط"],
        "البحرين": ["البحرين", "bahrain", "المنامة"],
        "قطر": ["قطر", "qatar", "الدوحة"],
        "ليبيا": ["ليبيا", "libya", "طرابلس"]
      };

      const keywords = countryKeywords[countryVal] || [countryVal];
      matchesCountry = keywords.some(kw => radio.name.toLowerCase().includes(kw.toLowerCase()));
    }

    return matchesSearch && matchesCountry;
  });

  renderRadioList(filtered);
}

function playRadioStream(url, name) {
  const vol = Number($('radioVolumeSlider')?.value || $('volumeSlider')?.value || 15);
  apiPost('/api/audio/play', { file: url, name: name || url, volume: vol, priority: 0 })
    .then(() => {
      toast(`جاري تشغيل: ${name || url}`);
      fetchStatus();
    })
    .catch(err => toast(`فشل التشغيل: ${err.message}`));
}

function playCustomRadioStream() {
  const url = ($('customRadioUrlInput')?.value || '').trim();
  const name = ($('customRadioNameInput')?.value || '').trim() || 'محطة مخصصة';
  if (!url || (!url.startsWith('http://') && !url.startsWith('https://'))) {
    return toast('يرجى إدخال رابط بث صحيح يبدأ بـ http:// أو https://');
  }
  playRadioStream(url, name);
}

function scheduleCustomRadioStream() {
  const url = ($('customRadioUrlInput')?.value || '').trim();
  const name = ($('customRadioNameInput')?.value || '').trim() || 'محطة مخصصة';
  if (!url || (!url.startsWith('http://') && !url.startsWith('https://'))) {
    return toast('يرجى إدخال رابط بث صحيح يبدأ بـ http:// أو https://');
  }
  scheduleRadioStream(url, name);
}

function scheduleRadioStream(url, name) {
  showTab('scheduler');
  showSubTab('tab-scheduler', 'sub-sched-add');
  
  const radioEl = document.querySelector('input[name="singleAlertSourceType"][value="radio"]');
  if (radioEl) {
    radioEl.checked = true;
    toggleAlertSourceType();
  }

  if ($('singleAlertName')) $('singleAlertName').value = `راديو ${name}`;
  if ($('singleAlertRadioFile')) {
    // Check if the URL already exists in dropdown, if not add it dynamically
    let exists = false;
    for (let i = 0; i < $('singleAlertRadioFile').options.length; i++) {
      if ($('singleAlertRadioFile').options[i].value === url) {
        exists = true;
        break;
      }
    }
    if (!exists) {
      const opt = document.createElement('option');
      opt.value = url;
      opt.textContent = name;
      $('singleAlertRadioFile').appendChild(opt);
    }
    $('singleAlertRadioFile').value = url;
  }
  
  // Scroll to singleAlertName to focus user's attention
  $('singleAlertName')?.scrollIntoView({ behavior: 'smooth' });
}

function populateRadioDropdowns() {
  const select = $('singleAlertRadioFile');
  if (!select) return;

  const previousVal = select.value;
  const previousText = select.selectedIndex >= 0 ? select.options[select.selectedIndex].textContent : '';
  select.innerHTML = '';
  const list = allRadiosList.length > 0 ? allRadiosList : (defaultOfflineRadios[radioLanguage] || defaultOfflineRadios.ar);
  
  list.forEach(radio => {
    const opt = document.createElement('option');
    opt.value = radio.url;
    opt.textContent = radio.name;
    opt.style.padding = '5px 8px';
    opt.style.borderBottom = '1px solid rgba(255,255,255,0.04)';
    select.appendChild(opt);
  });

  if (previousVal) {
    let found = false;
    for (let i = 0; i < select.options.length; i++) {
      if (select.options[i].value === previousVal) {
        select.options[i].selected = true;
        found = true;
        break;
      }
    }
    if (!found) {
      const opt = document.createElement('option');
      opt.value = previousVal;
      opt.textContent = previousText || previousVal;
      opt.selected = true;
      select.appendChild(opt);
    }
    select.value = previousVal;
  } else if (select.options.length > 0) {
    select.selectedIndex = 0;
  }

  const countBadge = $('singleAlertRadioCount');
  if (countBadge) countBadge.textContent = list.length;
  onSingleAlertRadioChange();
}

function filterSingleAlertRadioDropdown() {
  const query = ($('singleAlertRadioSearch')?.value || '').toLowerCase().trim();
  const select = $('singleAlertRadioFile');
  if (!select) return;
  const currentVal = select.value;
  select.innerHTML = '';

  const list = allRadiosList.length > 0 ? allRadiosList : (defaultOfflineRadios[radioLanguage] || defaultOfflineRadios.ar);
  let count = 0;
  list.forEach(radio => {
    if (!query || radio.name.toLowerCase().includes(query)) {
      const opt = document.createElement('option');
      opt.value = radio.url;
      opt.textContent = radio.name;
      opt.style.padding = '5px 8px';
      opt.style.borderBottom = '1px solid rgba(255,255,255,0.04)';
      if (radio.url === currentVal) opt.selected = true;
      select.appendChild(opt);
      count++;
    }
  });

  if (count === 0) {
    const opt = document.createElement('option');
    opt.disabled = true;
    opt.textContent = '⚠️ لا توجد إذاعة تطابق البحث';
    select.appendChild(opt);
  } else if (!select.value && select.options.length > 0) {
    select.selectedIndex = 0;
  }

  const countBadge = $('singleAlertRadioCount');
  if (countBadge) countBadge.textContent = count;
  onSingleAlertRadioChange();
}

function onSingleAlertRadioChange() {
  const sel = $('singleAlertRadioFile');
  const badge = $('singleAlertRadioSelectedBadge');
  if (sel && badge) {
    if (sel.selectedIndex >= 0 && sel.options[sel.selectedIndex] && !sel.options[sel.selectedIndex].disabled) {
      badge.textContent = `المختارة: ${sel.options[sel.selectedIndex].textContent}`;
    } else {
      badge.textContent = '';
    }
  }
}

function testPlayCurrentRadio() {
  const sel = $('singleAlertRadioFile');
  if (!sel || !sel.value) return toast('يرجى اختيار إذاعة أولاً');
  const name = sel.options[sel.selectedIndex]?.textContent || 'البث المباشر';
  playRadioStream(sel.value, name);
}

// ==================== Smart Presence & Welcome (Multi-device) ====================
let presenceSavedConfig = { devices: [] };

function togglePresenceFields() {
  const en = $('presenceEnabled')?.checked;
  const container = $('presenceFieldsContainer');
  if (container) {
    container.style.opacity = en ? '1' : '0.4';
    container.style.pointerEvents = en ? 'auto' : 'none';
  }
}

function onPresenceModeChange() {
  const mode = parseInt($('presenceMode')?.value || '0', 10);
  const rssiCol = $('presenceRssiCol');

  if (mode === 2) { // WiFi only
    if (rssiCol) rssiCol.style.display = 'none';
  } else { // Hybrid or BLE
    if (rssiCol) rssiCol.style.display = 'block';
  }
}

function loadPresenceConfig() {
  apiGet('/api/presence/config').then((cfg) => {
    if (!cfg) return;
    presenceSavedConfig = cfg;
    if ($('presenceEnabled')) $('presenceEnabled').checked = !!cfg.enabled;
    if ($('presenceMode')) $('presenceMode').value = cfg.mode !== undefined ? cfg.mode : 0;
    if ($('presenceRssi')) $('presenceRssi').value = cfg.rssiThresh !== undefined ? cfg.rssiThresh : -65;
    if ($('presenceVolume')) $('presenceVolume').value = cfg.volume !== undefined ? cfg.volume : 20;
    if ($('presenceVolValue')) $('presenceVolValue').textContent = cfg.volume !== undefined ? cfg.volume : 20;
    if ($('presenceCooldown')) $('presenceCooldown').value = cfg.cooldownMinutes !== undefined ? cfg.cooldownMinutes : 30;
    if ($('presenceVacate')) $('presenceVacate').value = cfg.vacateMinutes !== undefined ? cfg.vacateMinutes : 10;
    if ($('presenceQuietEn')) $('presenceQuietEn').checked = !!cfg.quietEn;
    
    const pad = (n) => String(n).padStart(2, '0');
    if ($('presenceQuietStart')) {
      $('presenceQuietStart').value = `${pad(cfg.qStartH !== undefined ? cfg.qStartH : 23)}:${pad(cfg.qStartM !== undefined ? cfg.qStartM : 0)}`;
    }
    if ($('presenceQuietEnd')) {
      $('presenceQuietEnd').value = `${pad(cfg.qEndH !== undefined ? cfg.qEndH : 7)}:${pad(cfg.qEndM !== undefined ? cfg.qEndM : 0)}`;
    }

    renderPresenceDevicesList(cfg.devices || []);
    togglePresenceFields();
    onPresenceModeChange();
  }).catch((err) => {
    console.warn("Failed to load presence config:", err);
  });
}

function renderPresenceDevicesList(devices) {
  const container = $('presenceDevicesList');
  if (!container) return;

  if (!Array.isArray(devices) || devices.length === 0) {
    container.innerHTML = `
      <div style="text-align:center; padding:25px; background:rgba(255,255,255,0.02); border:1px dashed rgba(255,255,255,0.15); border-radius:10px;">
        <i class="fas fa-user-slash" style="font-size:32px; color:rgba(255,255,255,0.3); margin-bottom:10px; display:block;"></i>
        <div style="font-size:15px; font-weight:bold; color:rgba(255,255,255,0.8);">لا توجد أجهزة مسجلة للترحيب حتى الآن</div>
        <div style="font-size:13px; color:rgba(255,255,255,0.5); margin:6px 0 15px 0;">أضف هواتفك وهواتف أصدقائك أو أفراد العائلة لتخصيص ترحيب لكل هاتف عند دخوله.</div>
        <button class="btn" type="button" onclick="openAddPresenceDeviceModal()" style="background:linear-gradient(135deg, #00f2fe, #4facfe); color:#000; font-weight:bold; padding:8px 18px;">
          <i class="fas fa-plus"></i> إضافة أول جهاز الآن
        </button>
      </div>
    `;
    return;
  }

  let html = '';
  devices.forEach((dev) => {
    const isEn = dev.enabled !== false;
    let badgeHtml = '';
    if (dev.state === 'present') {
      badgeHtml = '<span class="dev-status-badge" style="background:rgba(46,204,113,0.2); color:#2ecc71; border:1px solid rgba(46,204,113,0.5); padding:2px 8px; border-radius:10px; font-size:11px;"><i class="fas fa-circle"></i> متواجد الآن</span>';
    } else if (dev.state === 'cooldown') {
      badgeHtml = '<span class="dev-status-badge" style="background:rgba(241,196,15,0.2); color:#f1c40f; border:1px solid rgba(241,196,15,0.5); padding:2px 8px; border-radius:10px; font-size:11px;"><i class="fas fa-hourglass-half"></i> فترة انتظار</span>';
    } else {
      badgeHtml = '<span class="dev-status-badge" style="background:rgba(255,255,255,0.08); color:#aaa; border:1px solid rgba(255,255,255,0.15); padding:2px 8px; border-radius:10px; font-size:11px;"><i class="fas fa-walking"></i> غير متواجد</span>';
    }

    html += `
      <div class="glass-card" id="pres-dev-row-${dev.id}" style="margin:0; padding:12px 16px; background:rgba(255,255,255,0.04); border-radius:10px; border:1px solid ${isEn ? 'rgba(0,242,254,0.15)' : 'rgba(255,255,255,0.05)'}; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px; ${!isEn ? 'opacity:0.6;' : ''}">
        <div style="min-width:200px; flex:1;">
          <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
            <i class="fas fa-mobile-alt" style="color:#00f2fe; font-size:16px;"></i>
            <strong style="font-size:15px; color:#fff;">${safeText(dev.name || ('هاتف ' + (dev.id + 1)))}</strong>
            ${badgeHtml}
          </div>
          <div style="font-size:12px; color:rgba(255,255,255,0.7); font-family:monospace; margin-top:4px;">
            <i class="fas fa-fingerprint" style="color:#f39c12;"></i> <span style="color:#00f2fe; font-weight:bold;">${safeText(dev.mac)}</span>
            ${dev.lastIp ? ` <span style="color:rgba(255,255,255,0.5);">|</span> IP: ${safeText(dev.lastIp)}` : ''}
            ${dev.lastRssi && dev.lastRssi > -99 ? ` <span style="color:rgba(255,255,255,0.5);">|</span> <span style="color:#2ecc71;">${dev.lastRssi} dBm</span>` : ''}
          </div>
          <div style="font-size:12px; color:rgba(255,255,255,0.85); margin-top:4px;">
            <i class="fas fa-music" style="color:#e056fd;"></i> ملف الترحيب: <span style="color:#00f2fe; font-family:monospace;">${safeText(dev.welcomeFile || 'افتراضي')}</span>
          </div>
        </div>
        
        <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
          <button type="button" class="pres-action-btn pres-btn-play" onclick="testDeviceAudio('${safeAttr(dev.welcomeFile || '')}')" title="تجربة تشغيل الصوت">
            <i class="fas fa-play"></i> تجربة
          </button>
          <button type="button" class="pres-action-btn pres-btn-edit" onclick="editPresenceDevice(${dev.id})" title="تعديل الجهاز">
            <i class="fas fa-edit"></i> تعديل
          </button>
          <button type="button" class="pres-action-btn pres-btn-delete" onclick="deletePresenceDevice(${dev.id}, '${safeAttr(dev.name || '')}')" title="حذف الجهاز">
            <i class="fas fa-trash-alt"></i> حذف
          </button>
        </div>
      </div>
    `;
  });

  container.innerHTML = html;
}

function savePresenceConfig() {
  const qStart = ($('presenceQuietStart')?.value || '23:00').split(':');
  const qEnd = ($('presenceQuietEnd')?.value || '07:00').split(':');

  const payload = {
    enabled: $('presenceEnabled')?.checked ? '1' : '0',
    mode: $('presenceMode')?.value || '0',
    rssiThresh: $('presenceRssi')?.value || '-65',
    volume: $('presenceVolume')?.value || '20',
    cooldownMinutes: $('presenceCooldown')?.value || '30',
    vacateMinutes: $('presenceVacate')?.value || '10',
    quietEn: $('presenceQuietEn')?.checked ? '1' : '0',
    qStartH: qStart[0] || '23',
    qStartM: qStart[1] || '0',
    qEndH: qEnd[0] || '7',
    qEndM: qEnd[1] || '0'
  };

  apiPost('/api/presence/config', payload).then(() => {
    toast('تم حفظ إعدادات الترحيب الذكي العامة بنجاح');
    refreshPresenceStatus();
  }).catch((err) => {
    toast(`فشل الحفظ: ${err.message}`);
  });
}

function refreshPresenceStatus() {
  apiGet('/api/presence/status').then((st) => {
    const badge = $('presenceLiveStateBadge');
    const rssiTxt = $('presenceRssiText');
    if (!badge) return;

    if (st.state === 'present') {
      badge.style.background = 'rgba(46, 204, 113, 0.2)';
      badge.style.border = '1px solid rgba(46, 204, 113, 0.6)';
      badge.style.color = '#2ecc71';
      badge.innerHTML = '<i class="fas fa-check-circle"></i> متواجد بالقرب (جلسة نشطة)';
    } else if (st.state === 'cooldown') {
      badge.style.background = 'rgba(241, 196, 15, 0.2)';
      badge.style.border = '1px solid rgba(241, 196, 15, 0.6)';
      badge.style.color = '#f1c40f';
      badge.innerHTML = '<i class="fas fa-hourglass-half"></i> فترة الهدوء (Cooldown نشط)';
    } else {
      badge.style.background = 'rgba(255, 255, 255, 0.08)';
      badge.style.border = '1px solid rgba(255, 255, 255, 0.15)';
      badge.style.color = '#bbb';
      badge.innerHTML = '<i class="fas fa-walking"></i> غير متواجد (بانتظار الاقتراب)';
    }

    if (rssiTxt) {
      let extra = [];
      if (Array.isArray(st.devices) && st.devices.length > 0) {
        extra.push(`الأجهزة المسجلة: ${st.devices.length}`);
        const activeCount = st.devices.filter(d => d.state === 'present').length;
        if (activeCount > 0) extra.push(`المتواجدون حالياً: ${activeCount}`);
      }
      if (st.lastRssi && st.lastRssi > -99) extra.push(`آخر إشارة: ${st.lastRssi} dBm`);
      rssiTxt.textContent = extra.join(' | ');
    }

    if (Array.isArray(st.devices) && presenceSavedConfig.devices) {
      st.devices.forEach((d) => {
        const found = presenceSavedConfig.devices.find(x => x.id === d.id);
        if (found) {
          found.state = d.state;
          found.lastRssi = d.lastRssi;
          found.lastIp = d.lastIp;
        }
      });
      renderPresenceDevicesList(presenceSavedConfig.devices);
    }
  }).catch(() => {});
}

// ---- Modal Handlers for Multi-Device ----
function ensurePresenceAudioOptions(selectedFile) {
  const sel = $('presenceDevAudioFile');
  if (!sel) return;

  const audioFiles = (appState.files || []).filter((f) =>
    !f.isDirectory &&
    !String(f.name || '').startsWith('prayer_csv/') &&
    /\.(mp3|wav)$/i.test(f.name || '')
  );

  let html = '';
  if (audioFiles.length === 0) {
    html += '<option value="">⏳ جاري جلب قائمة الملفات من الذاكرة...</option>';
  } else {
    audioFiles.forEach((f) => {
      html += `<option value="${safeAttr(f.name)}">${safeText(f.name)}</option>`;
    });
  }
  sel.innerHTML = html;

  if (selectedFile) {
    const target = selectedFile;
    const noSlash = target.startsWith('/') ? target.slice(1) : target;
    const withSlash = '/' + noSlash;
    let matched = false;
    for (const opt of sel.options) {
      if (opt.value === target || opt.value === noSlash || opt.value === withSlash) {
        sel.value = opt.value;
        matched = true;
        break;
      }
    }
    if (!matched && target) {
      const opt = document.createElement('option');
      opt.value = target;
      opt.textContent = target;
      sel.appendChild(opt);
      sel.value = target;
    }
  }

  // If audio files list not yet in memory, fetch it directly from device!
  if (audioFiles.length === 0) {
    apiGet('/api/files/list').then((data) => {
      const files = Array.isArray(data) ? data : (data.files || []);
      appState.files = files;
      ensurePresenceAudioOptions(selectedFile || sel.value);
    }).catch(() => {});
  }
}

function openAddPresenceDeviceModal() {
  if (presenceSavedConfig.devices && presenceSavedConfig.devices.length >= 8) {
    toast('تم الوصول للحد الأقصى المسموح (8 أجهزة). احذف جهازاً قديماً للإضافة.');
    return;
  }
  if ($('presenceDeviceModalTitle')) $('presenceDeviceModalTitle').innerHTML = '<i class="fas fa-user-plus"></i> إضافة جهاز ترحيب جديد';
  if ($('presenceDevId')) $('presenceDevId').value = '-1';
  if ($('presenceDevName')) $('presenceDevName').value = '';
  if ($('presenceDevMac')) $('presenceDevMac').value = '';
  if ($('presenceDevEnabled')) $('presenceDevEnabled').checked = true;
  
  ensurePresenceAudioOptions('');
  const modal = $('presenceDeviceModal');
  if (modal) modal.style.display = 'flex';
}

function editPresenceDevice(id) {
  const devs = presenceSavedConfig.devices || [];
  const dev = devs.find(d => d.id === id);
  if (!dev) return;

  if ($('presenceDeviceModalTitle')) $('presenceDeviceModalTitle').innerHTML = `<i class="fas fa-edit"></i> تعديل: ${safeText(dev.name)}`;
  if ($('presenceDevId')) $('presenceDevId').value = String(dev.id);
  if ($('presenceDevName')) $('presenceDevName').value = dev.name || '';
  if ($('presenceDevMac')) $('presenceDevMac').value = dev.mac || '';
  if ($('presenceDevEnabled')) $('presenceDevEnabled').checked = dev.enabled !== false;

  ensurePresenceAudioOptions(dev.welcomeFile || '');

  const modal = $('presenceDeviceModal');
  if (modal) modal.style.display = 'flex';
}

function closePresenceDeviceModal() {
  const modal = $('presenceDeviceModal');
  if (modal) modal.style.display = 'none';
}

function savePresenceDeviceFromModal() {
  const id = parseInt($('presenceDevId')?.value || '-1', 10);
  const name = ($('presenceDevName')?.value || '').trim();
  const mac = ($('presenceDevMac')?.value || '').trim().toLowerCase();
  const welcomeFile = $('presenceDevAudioFile')?.value || '/Azan/welcome.mp3';
  const enabled = $('presenceDevEnabled')?.checked ? '1' : '0';

  if (!mac || mac.length < 11) {
    toast('يرجى إدخال عنوان ماك (MAC) صحيح للجهاز');
    return;
  }

  const payload = {
    id: String(id),
    name: name || ('هاتف ' + mac.slice(-5)),
    mac: mac,
    welcomeFile: welcomeFile,
    enabled: enabled
  };

  apiPost('/api/presence/device/save', payload).then(() => {
    toast(`تم حفظ الجهاز [${payload.name}] بنجاح`);
    closePresenceDeviceModal();
    loadPresenceConfig();
    refreshPresenceStatus();
  }).catch((err) => {
    toast(`فشل حفظ الجهاز: ${err.message}`);
  });
}

function deletePresenceDevice(id, name) {
  if (!confirm(`هل أنت متأكد من حذف جهاز [${name || 'المحدد'}] من قائمة الترحيب؟`)) {
    return;
  }
  apiPost('/api/presence/device/delete', { id: String(id) }).then(() => {
    toast('تم حذف الجهاز بنجاح');
    loadPresenceConfig();
    refreshPresenceStatus();
  }).catch((err) => {
    toast(`فشل الحذف: ${err.message}`);
  });
}

function testDeviceAudio(file) {
  if (!file) {
    toast('الملف الصوتي غير محدد');
    return;
  }
  const volume = $('presenceVolume')?.value || '20';
  const playPath = file.startsWith('/') ? file : ('/' + file);
  apiPost('/api/presence/test', { file: playPath, volume: volume }).then(() => {
    toast(`جاري تجربة تشغيل: ${file}`);
  }).catch((err) => {
    toast(`فشل التشغيل: ${err.message}`);
  });
}

function testDeviceModalAudio() {
  const file = $('presenceDevAudioFile')?.value;
  if (!file) {
    toast('يرجى اختيار ملف صوتي أولاً');
    return;
  }
  testDeviceAudio(file);
}

function testPresenceAudio() {
  const vol = $('presenceVolume')?.value || '20';
  apiPost('/api/presence/test', { volume: vol }).then(() => {
    toast('جاري تجربة تشغيل ملف الترحيب...');
  }).catch((err) => {
    toast(`فشل التشغيل: ${err.message}`);
  });
}

// ---- Wi-Fi Network Devices Scanner ----
function openWifiScanModal() {
  const modal = $('wifiScanModal');
  if (modal) {
    modal.style.display = 'flex';
    startWifiScan();
  }
}

function closeWifiScanModal() {
  const modal = $('wifiScanModal');
  if (modal) modal.style.display = 'none';
}

function startWifiScan() {
  const loading = $('wifiScanLoading');
  const list = $('wifiScanResultsList');
  if (loading) loading.style.display = 'block';
  if (list) list.innerHTML = '';

  apiGet('/api/presence/scan-wifi').then((devices) => {
    if (loading) loading.style.display = 'none';
    if (!list) return;

    if (!Array.isArray(devices) || devices.length === 0) {
      list.innerHTML = '<div style="text-align:center; padding:15px; color:rgba(255,255,255,0.5);">لم يتم العثور على أجهزة على الشبكة المحلية حالياً.</div>';
      return;
    }

    let html = '<div style="display:flex; flex-direction:column; gap:8px;">';
    devices.forEach((dev) => {
      const isSelf = dev.type === 'self';
      const isGw = dev.type === 'gateway';
      const badgeColor = isGw ? '#f39c12' : (isSelf ? '#3498db' : '#2ecc71');
      const icon = isGw ? 'fa-broadcast-tower' : (isSelf ? 'fa-microchip' : 'fa-mobile-alt');
      
      html += `
        <div class="glass-card" style="margin:0; padding:10px 14px; display:flex; justify-content:space-between; align-items:center; background:rgba(255,255,255,0.04); border-radius:8px;">
          <div>
            <div style="font-weight:bold; font-size:14px; color:${badgeColor};">
              <i class="fas ${icon}"></i> ${safeText(dev.name || 'جهاز شبكة')}
            </div>
            <div style="font-size:12px; color:rgba(255,255,255,0.7); margin-top:3px; font-family:monospace;">
              <span style="color:#00f2fe; font-weight:bold;">${safeText(dev.mac)}</span> ${dev.ip ? `| IP: ${safeText(dev.ip)}` : ''}
            </div>
          </div>
          ${!isSelf ? `
            <button class="btn" type="button" style="margin:0; padding:5px 14px; font-size:12px; background:linear-gradient(135deg, #2ecc71, #27ae60); color:#fff; font-weight:bold;"
                    onclick="selectWifiDevice('${safeAttr(dev.mac)}', '${safeAttr(dev.name || '')}', '${safeAttr(dev.ip || '')}')">
              <i class="fas fa-check"></i> اختيار هذا الجهاز
            </button>
          ` : `<span style="font-size:11px; opacity:0.6;">(هذا الجهاز)</span>`}
        </div>
      `;
    });
    html += '</div>';
    list.innerHTML = html;
  }).catch((err) => {
    if (loading) loading.style.display = 'none';
    if (list) list.innerHTML = `<div style="color:#e74c3c; text-align:center; padding:10px;">فشل فحص الشبكة: ${err.message}</div>`;
  });
}

function selectWifiDevice(mac, name, ip) {
  const modal = $('presenceDeviceModal');
  if (modal && modal.style.display !== 'none') {
    if ($('presenceDevMac')) $('presenceDevMac').value = mac;
    if ($('presenceDevName') && !$('presenceDevName').value) $('presenceDevName').value = name || 'هاتف شبكة';
  } else {
    openAddPresenceDeviceModal();
    if ($('presenceDevMac')) $('presenceDevMac').value = mac;
    if ($('presenceDevName')) $('presenceDevName').value = name || 'هاتف شبكة';
  }
  closeWifiScanModal();
  toast(`تم اختيار الماك: ${mac}`);
}

// ---- BLE Devices Scanner ----
function openBleScanModal() {
  const modal = $('bleScanModal');
  if (modal) {
    modal.style.display = 'flex';
    startBleScan();
  }
}

function closeBleScanModal() {
  const modal = $('bleScanModal');
  if (modal) modal.style.display = 'none';
}

function startBleScan() {
  const loading = $('bleScanLoading');
  const list = $('bleScanResultsList');
  if (loading) loading.style.display = 'block';
  if (list) list.innerHTML = '';

  apiGet('/api/presence/scan-ble?start=1').then(() => {
    setTimeout(() => {
      apiGet('/api/presence/scan-ble').then((devices) => {
        if (loading) loading.style.display = 'none';
        if (!list) return;

        if (!Array.isArray(devices) || devices.length === 0) {
          list.innerHTML = '<div style="text-align:center; padding:15px; color:rgba(255,255,255,0.6);">لم يتم العثور على أجهزة بلوتوث تبث حالياً. تأكد من فتح شاشة البلوتوث بهاتفك ليصبح مرئياً، أو استخدم <strong>"فحص أجهزة شبكة الواي فاي"</strong> بدلاً منه.</div>';
          return;
        }

        let html = '<div style="display:flex; flex-direction:column; gap:8px;">';
        devices.forEach((dev) => {
          const isKnown = dev.name && dev.name !== 'Unknown Device';
          const nameDisp = isKnown ? safeText(dev.name) : 'جهاز بلوتوث';
          html += `
            <div class="glass-card" style="margin:0; padding:10px 14px; display:flex; justify-content:space-between; align-items:center; background:rgba(255,255,255,0.04); border-radius:8px;">
              <div>
                <div style="font-weight:bold; font-size:14px; color:${isKnown ? '#00f2fe' : '#ddd'};">
                  <i class="fab fa-bluetooth"></i> ${nameDisp}
                </div>
                <div style="font-size:12px; color:rgba(255,255,255,0.7); font-family:monospace; margin-top:2px;">
                  <span style="color:#00f2fe; font-weight:bold;">${safeText(dev.mac)}</span> | <span style="color:#2ecc71;">${dev.rssi} dBm</span>
                </div>
              </div>
              <button class="btn" type="button" style="margin:0; padding:5px 14px; font-size:12px; background:linear-gradient(135deg, #00f2fe, #4facfe); color:#000; font-weight:bold;"
                      onclick="selectBleDevice('${safeAttr(dev.mac)}', '${safeAttr(dev.name)}')">
                <i class="fas fa-check"></i> اختيار هذا الجهاز
              </button>
            </div>
          `;
        });
        html += '</div>';
        list.innerHTML = html;
      }).catch((err) => {
        if (loading) loading.style.display = 'none';
        if (list) list.innerHTML = `<div style="color:#e74c3c; text-align:center; padding:10px;">فشل قراءة النتائج: ${err.message}</div>`;
      });
    }, 2200);
  }).catch((err) => {
    if (loading) loading.style.display = 'none';
    if (list) list.innerHTML = `<div style="color:#e74c3c; text-align:center; padding:10px;">فشل الفحص: ${err.message}</div>`;
  });
}

function selectBleDevice(mac, name) {
  const modal = $('presenceDeviceModal');
  if (modal && modal.style.display !== 'none') {
    if ($('presenceDevMac')) $('presenceDevMac').value = mac;
    if ($('presenceDevName') && !$('presenceDevName').value) $('presenceDevName').value = (name && name !== 'Unknown Device') ? name : 'هاتف بلوتوث';
  } else {
    openAddPresenceDeviceModal();
    if ($('presenceDevMac')) $('presenceDevMac').value = mac;
    if ($('presenceDevName')) $('presenceDevName').value = (name && name !== 'Unknown Device') ? name : 'هاتف بلوتوث';
  }
  closeBleScanModal();
  toast(`تم اختيار الجهاز: ${name || mac}`);
}



